import React, { useState } from 'react';
import { useSalon } from '../../context/SalonContext';
import { formatCurrency, generateWhatsAppMessage } from '../../lib/calculations';
import { MessageSquare } from 'lucide-react';

export const StaffCommissionScreen: React.FC = () => {
  const { triggerWhatsAppSim, language } = useSalon();
  const isUrdu = language === 'roman_urdu';

  const [timeFilter, setTimeFilter] = useState<'aaj' | 'hafta' | 'mahina'>('aaj');
  const [sentSuccess, setSentSuccess] = useState<boolean>(false);

  const staffData = [
    {
      id: 'raju',
      name: 'Raju',
      letter: 'R',
      color: 'bg-rose-500',
      customers: timeFilter === 'aaj' ? 12 : timeFilter === 'hafta' ? 74 : 290,
      workAmount: timeFilter === 'aaj' ? 4300 : timeFilter === 'hafta' ? 26800 : 105000,
      rate: 0.40,
    },
    {
      id: 'sameer',
      name: 'Sameer',
      letter: 'S',
      color: 'bg-blue-500',
      customers: timeFilter === 'aaj' ? 10 : timeFilter === 'hafta' ? 62 : 245,
      workAmount: timeFilter === 'aaj' ? 3100 : timeFilter === 'hafta' ? 19400 : 78000,
      rate: 0.40,
    },
    {
      id: 'imran',
      name: 'Imran',
      letter: 'I',
      color: 'bg-amber-500',
      customers: timeFilter === 'aaj' ? 9 : timeFilter === 'hafta' ? 55 : 210,
      workAmount: timeFilter === 'aaj' ? 2800 : timeFilter === 'hafta' ? 17200 : 69000,
      rate: 0.40,
    },
    {
      id: 'pooja',
      name: 'Pooja',
      letter: 'P',
      color: 'bg-emerald-500',
      customers: timeFilter === 'aaj' ? 9 : timeFilter === 'hafta' ? 58 : 230,
      workAmount: timeFilter === 'aaj' ? 4400 : timeFilter === 'hafta' ? 27500 : 110000,
      rate: 0.40,
    },
  ];

  const totalCommission = staffData.reduce(
    (sum, s) => sum + Math.round(s.workAmount * s.rate),
    0
  );

  const handleSendToWhatsApp = (staffItem?: typeof staffData[0]) => {
    const target = staffItem || staffData[0];
    const commissionAmt = Math.round(target.workAmount * target.rate);

    const waMsg = generateWhatsAppMessage(
      'staff_commission',
      {
        stylistName: target.name,
        customerCount: target.customers,
        totalWorkAmount: target.workAmount,
        commissionRate: target.rate,
        commissionAmount: commissionAmt,
      },
      language
    );

    triggerWhatsAppSim('staff_commission', target.name, '+92 300 9876543', waMsg);
    setSentSuccess(true);
    setTimeout(() => setSentSuccess(false), 3000);
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 text-slate-900 pb-28">
      {/* Top Header */}
      <div className="pt-2 px-5 pb-2">
        <div className="flex items-center justify-between text-[11px] font-bold tracking-wider text-purple-700 uppercase">
          <span>{isUrdu ? 'AAPKA SALON · MALIK / OWNER' : 'AAPKA SALON · OWNER'}</span>
          <span className="px-2 py-0.5 rounded bg-purple-100 text-purple-800 text-[10px]">DEMO</span>
        </div>
        <div className="mt-1">
          <h1 className="text-2xl font-extrabold text-slate-900">
            {isUrdu ? 'Staff Ka Commission' : 'Staff Commission'}
          </h1>
          <p className="text-xs text-slate-500 font-medium mt-0.5">
            {isUrdu
              ? 'Khud-kaar hisaab aur rozana commission ledger'
              : 'Auto-calculated daily commission ledger'}
          </p>
        </div>
      </div>

      <div className="flex-1 px-5 space-y-3.5 overflow-y-auto">
        {/* Time Tabs */}
        <div className="grid grid-cols-3 gap-2 bg-slate-200/60 p-1 rounded-2xl">
          <button
            type="button"
            onClick={() => setTimeFilter('aaj')}
            className={`py-1.5 rounded-xl text-xs font-bold transition-all ${
              timeFilter === 'aaj'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {isUrdu ? 'Aaj' : 'Today'}
          </button>
          <button
            type="button"
            onClick={() => setTimeFilter('hafta')}
            className={`py-1.5 rounded-xl text-xs font-bold transition-all ${
              timeFilter === 'hafta'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {isUrdu ? 'Is Hafte' : 'This Week'}
          </button>
          <button
            type="button"
            onClick={() => setTimeFilter('mahina')}
            className={`py-1.5 rounded-xl text-xs font-bold transition-all ${
              timeFilter === 'mahina'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {isUrdu ? 'Is Mahine' : 'Month'}
          </button>
        </div>

        {/* Staff List Cards */}
        <div className="space-y-2.5">
          {staffData.map((staff) => {
            const commAmount = Math.round(staff.workAmount * staff.rate);
            return (
              <div
                key={staff.id}
                className="p-3.5 bg-white rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-9 h-9 rounded-full ${staff.color} text-white font-extrabold text-sm flex items-center justify-center shrink-0 shadow-xs`}
                  >
                    {staff.letter}
                  </div>
                  <div>
                    <div className="font-extrabold text-xs text-slate-900">{staff.name}</div>
                    <div className="text-[11px] text-slate-500 font-medium">
                      {isUrdu
                        ? `${staff.customers} grahak · ${formatCurrency(staff.workAmount)}`
                        : `${staff.customers} customers · ${formatCurrency(staff.workAmount)}`}
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-[10px] font-bold text-slate-400">
                    {Math.round(staff.rate * 100)}%
                  </div>
                  <div className="font-mono font-extrabold text-emerald-700 text-sm">
                    {formatCurrency(commAmount)}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Total Commission Box */}
        <div className="p-4 bg-white rounded-3xl border border-slate-200 shadow-sm flex items-center justify-between">
          <span className="text-sm font-bold text-slate-700">
            {isUrdu ? 'Total Commission' : 'Total commission'}
          </span>
          <span className="text-2xl font-black text-emerald-600 font-mono">
            {formatCurrency(totalCommission)}
          </span>
        </div>

        {/* Send to WhatsApp action */}
        <button
          type="button"
          onClick={() => handleSendToWhatsApp()}
          className="w-full py-3.5 bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-700 hover:opacity-95 text-white font-extrabold text-sm rounded-2xl shadow-lg shadow-purple-600/30 flex items-center justify-center gap-2 transition-transform active:scale-[0.99]"
        >
          <MessageSquare className="w-4 h-4" />
          <span>
            {isUrdu
              ? 'Staff Ko WhatsApp Par Hisaab Bhejein'
              : 'Send Statement to Staff via WhatsApp'}
          </span>
        </button>

        {sentSuccess && (
          <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200 text-xs text-emerald-800 text-center font-bold">
            {isUrdu
              ? '✓ WhatsApp par hisaab staff ko bhej diya gaya!'
              : '✓ WhatsApp statement sent to staff!'}
          </div>
        )}

        {/* Blueprint callout */}
        <div className="p-3 bg-purple-50 rounded-xl border border-purple-100 text-purple-900 text-[11px] leading-relaxed">
          💼 <strong>{isUrdu ? 'Khas Baat:' : 'Functionality:'}</strong>{' '}
          {isUrdu
            ? 'Roz sham ko register aur hisaab ki diary banane ki zaroorat nahi. Har stylist ka commission khud calculate ho kar WhatsApp par chala jata hai!'
            : 'Automatic commission calculations eliminate manual registry books at day-end!'}
        </div>
      </div>
    </div>
  );
};
