import React, { useState } from 'react';
import { useSalon } from '../../context/SalonContext';
import { Search, Plus, CreditCard, CheckCircle2, Clock, PlayCircle } from 'lucide-react';
import { BookingStatus } from '../../lib/types';

export const AajKiBookingsScreen: React.FC = () => {
  const { bookings, stylists, updateBookingStatus, setActiveScreenId, language } = useSalon();
  const isUrdu = language === 'roman_urdu';

  const [filterType, setFilterType] = useState<'all' | 'booking' | 'walkin'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Total customers count
  const totalCustomers = bookings.length;
  const bookingCount = bookings.filter((b) => b.type === 'booking').length;
  const walkinCount = bookings.filter((b) => b.type === 'walkin').length;

  const filteredBookings = bookings.filter((b) => {
    if (filterType !== 'all' && b.type !== filterType) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        b.customerName.toLowerCase().includes(q) ||
        b.stylistName.toLowerCase().includes(q) ||
        b.services.some((s) => s.name.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const getStatusBadge = (b: typeof bookings[0]) => {
    switch (b.status) {
      case 'ho_gaya':
        return (
          <span className="px-2.5 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold text-[10px] rounded-full flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            {isUrdu ? 'Mukammal' : 'Completed'}
          </span>
        );
      case 'chal_raha':
        return (
          <span className="px-2.5 py-1 bg-purple-50 text-purple-700 border border-purple-200 font-bold text-[10px] rounded-full flex items-center gap-1">
            <PlayCircle className="w-3 h-3 text-purple-600 animate-pulse" />
            {isUrdu ? 'Chal Raha Hai' : 'In Service'}
          </span>
        );
      case 'aane_wala':
      default:
        return (
          <span className="px-2.5 py-1 bg-amber-50 text-amber-700 border border-amber-200 font-bold text-[10px] rounded-full flex items-center gap-1">
            <Clock className="w-3 h-3 text-amber-600" />
            {isUrdu ? 'Aane Wala' : 'Upcoming'}
          </span>
        );
    }
  };

  const handleCycleStatus = (id: string, current: BookingStatus) => {
    if (current === 'aane_wala') updateBookingStatus(id, 'chal_raha');
    else if (current === 'chal_raha') updateBookingStatus(id, 'ho_gaya');
    else updateBookingStatus(id, 'aane_wala');
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 text-slate-900 pb-28">
      {/* Top Header */}
      <div className="pt-2 px-5 pb-2">
        <div className="flex items-center justify-between text-[11px] font-bold tracking-wider text-purple-700 uppercase">
          <span>{isUrdu ? 'AAPKA SALON · RECEPTION' : 'AAPKA SALON · RECEPTION'}</span>
          <span className="px-2 py-0.5 rounded bg-purple-100 text-purple-800 text-[10px]">DEMO</span>
        </div>
        <div className="flex items-center justify-between mt-1">
          <div>
            <h1 className="text-2xl font-extrabold text-slate-900">
              {isUrdu ? 'Aaj Ki Bookings' : "Today's Bookings"}
            </h1>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              {isUrdu ? 'Itwar, 2 Nov · Tamam bookings ek jagah' : 'Sun, Nov 2 · All appointments in one place'}
            </p>
          </div>
          <button
            type="button"
            onClick={() => setActiveScreenId(5)} // Jump to Screen 5 (Walk-in Entry)
            className="flex items-center gap-1 px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold shadow-sm transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>{isUrdu ? '+ Walk-in Line' : '+ Walk-in'}</span>
          </button>
        </div>
      </div>

      <div className="flex-1 px-5 space-y-3 overflow-y-auto">
        {/* TODAY'S CUSTOMERS Hero Metric Box */}
        <div className="p-4 bg-white rounded-3xl border border-slate-200 shadow-sm">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
            {isUrdu ? 'AAJ KE TOTAL GRAHAK / CUSTOMERS' : "TODAY'S CUSTOMERS"}
          </div>
          <div className="flex items-baseline justify-between">
            <div className="text-4xl font-black text-slate-900">
              {totalCustomers}
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setFilterType(filterType === 'booking' ? 'all' : 'booking')}
                className={`px-3 py-1 rounded-xl text-center border transition-all ${
                  filterType === 'booking'
                    ? 'bg-purple-600 text-white border-purple-600 shadow-sm'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div className="text-sm font-black">{bookingCount}</div>
                <div className="text-[9px] font-bold uppercase opacity-80">
                  {isUrdu ? 'Bookings' : 'Bookings'}
                </div>
              </button>

              <button
                type="button"
                onClick={() => setFilterType(filterType === 'walkin' ? 'all' : 'walkin')}
                className={`px-3 py-1 rounded-xl text-center border transition-all ${
                  filterType === 'walkin'
                    ? 'bg-purple-600 text-white border-purple-600 shadow-sm'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div className="text-sm font-black">{walkinCount}</div>
                <div className="text-[9px] font-bold uppercase opacity-80">
                  {isUrdu ? 'Walk-in' : 'Walk-ins'}
                </div>
              </button>
            </div>
          </div>
        </div>

        {/* Stylist Live Status Pills */}
        <div className="grid grid-cols-4 gap-2">
          {stylists.map((st) => {
            const isBusy = st.status === 'busy';
            return (
              <div
                key={st.id}
                className="p-2 bg-white rounded-2xl border border-slate-200 text-center shadow-xs"
              >
                <div className="text-xs font-bold text-slate-900 truncate">{st.name}</div>
                <div className="flex items-center justify-center gap-1 mt-1">
                  <span
                    className={`w-2 h-2 rounded-full ${
                      isBusy ? 'bg-rose-500 animate-pulse' : 'bg-emerald-500'
                    }`}
                  />
                  <span
                    className={`text-[10px] font-bold uppercase ${
                      isBusy ? 'text-rose-600' : 'text-emerald-600'
                    }`}
                  >
                    {isBusy ? (isUrdu ? 'Masroof' : 'Busy') : (isUrdu ? 'Free' : 'Free')}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Search bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isUrdu ? "Customer, stylist ya service dhoondein..." : "Search by customer, stylist or service..."}
            className="w-full pl-9 pr-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-purple-600"
          />
        </div>

        {/* Bookings List */}
        <div className="space-y-2">
          {filteredBookings.map((b) => (
            <div
              key={b.id}
              className="p-3 bg-white rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between gap-3 hover:border-purple-200 transition-colors"
            >
              <div className="flex items-start gap-2.5 min-w-0">
                <div className="text-xs font-black text-slate-400 font-mono pt-0.5 shrink-0">
                  {b.slotTime}
                </div>
                <div className="min-w-0">
                  <div className="font-extrabold text-xs text-slate-900 flex items-center gap-1.5 truncate">
                    <span>{b.customerName}</span>
                    <span className="text-[10px] text-slate-400 font-mono">#{b.tokenNumber}</span>
                  </div>
                  <div className="text-[11px] text-slate-500 truncate mt-0.5">
                    {b.services.map((s) => s.name).join(' + ')} · <span className="font-semibold text-purple-700">{b.stylistName}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  title="Click to toggle status"
                  onClick={() => handleCycleStatus(b.id, b.status)}
                  className="transition-transform active:scale-95"
                >
                  {getStatusBadge(b)}
                </button>

                {b.status === 'chal_raha' && (
                  <button
                    type="button"
                    title="Bill Customer"
                    onClick={() => setActiveScreenId(6)} // Screen 6 Billing
                    className="p-1.5 bg-purple-50 text-purple-700 hover:bg-purple-100 rounded-lg text-xs font-semibold"
                  >
                    <CreditCard className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
