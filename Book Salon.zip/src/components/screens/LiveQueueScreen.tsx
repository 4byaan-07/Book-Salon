import React from 'react';
import { useSalon } from '../../context/SalonContext';
import { calculateQueueWaitTime } from '../../lib/calculations';
import { BellRing, RefreshCw } from 'lucide-react';
import { motion } from 'motion/react';

export const LiveQueueScreen: React.FC = () => {
  const { bookings, simulateNextCustomerInQueue, sendWhatsAppAlertToOneLeft, language } = useSalon();
  const isUrdu = language === 'roman_urdu';

  const userBooking = bookings.find((b) => b.isCurrentUser) || bookings.find((b) => b.tokenNumber === 17) || bookings[2];
  const userTokenNum = userBooking?.tokenNumber || 17;

  const activeBookings = bookings.filter((b) => b.status === 'chal_raha');

  const peopleAhead = bookings.filter(
    (b) => b.status === 'aane_wala' && b.tokenNumber < userTokenNum
  );

  const totalAhead = peopleAhead.length;
  const estimatedWait = calculateQueueWaitTime(totalAhead, Math.max(1, activeBookings.length), 15);

  const isUserTurn = userBooking?.status === 'chal_raha';
  const isUserDone = userBooking?.status === 'ho_gaya';

  const chair1Booking = activeBookings.find((b) => b.chair === 1) || bookings.find((b) => b.stylistId === 'raju');
  const chair2Booking = activeBookings.find((b) => b.chair === 2) || bookings.find((b) => b.stylistId === 'sameer');

  return (
    <div className="flex flex-col h-full bg-slate-50 text-slate-900 pb-28">
      {/* Top Header */}
      <div className="pt-2 px-5 pb-2">
        <div className="flex items-center justify-between text-[11px] font-bold tracking-wider text-purple-700 uppercase">
          <span>AAPKA SALON · CUSTOMER</span>
          <span className="px-2 py-0.5 rounded bg-purple-100 text-purple-800 text-[10px]">DEMO</span>
        </div>
        <div className="flex items-center justify-between mt-1">
          <div>
            <h1 className="text-2xl font-extrabold text-slate-900">
              Live Queue
            </h1>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              {isUrdu ? 'Ghar se dekhein, sahi waqt pe aayein' : 'Track from home, arrive right on time'}
            </p>
          </div>
          <button
            type="button"
            title="Advance Queue Simulation"
            onClick={simulateNextCustomerInQueue}
            className="flex items-center gap-1 px-2.5 py-1.5 bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 rounded-lg text-[11px] font-bold shadow-sm transition-colors active:scale-95"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>{isUrdu ? 'Agla Banda' : 'Simulate Next'}</span>
          </button>
        </div>
      </div>

      <div className="flex-1 px-5 space-y-3.5 overflow-y-auto">
        {/* Gradient Hero Card */}
        <div className="relative overflow-hidden rounded-3xl p-5 bg-gradient-to-br from-indigo-700 via-purple-700 to-pink-600 text-white shadow-lg shadow-purple-600/20">
          <div className="flex items-start justify-between">
            <div>
              <div className="text-[11px] font-bold tracking-wider text-purple-200 uppercase">
                {isUrdu ? 'AAPSE PEHLE' : 'AHEAD OF YOU'}
              </div>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-5xl font-black tracking-tight leading-none">
                  {isUserDone ? 0 : isUserTurn ? 0 : totalAhead}
                </span>
                <span className="text-xl font-bold opacity-90">
                  {isUrdu ? 'log' : 'people'}
                </span>
              </div>
            </div>

            {/* Estimated Wait Bubble */}
            <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-md border border-white/30 flex flex-col items-center justify-center shadow-inner">
              <span className="text-base font-black leading-tight">
                {isUserDone ? 'Done' : isUserTurn ? (isUrdu ? 'Abhi' : 'Now') : `~${estimatedWait}`}
              </span>
              <span className="text-[10px] font-semibold opacity-90">
                {isUserDone ? '✓' : isUserTurn ? (isUrdu ? 'Kursi' : 'Seat') : 'min'}
              </span>
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-white/20 flex items-center justify-between text-xs font-medium text-purple-100">
            <span className="truncate">
              {isUrdu ? 'Aapka token' : 'Your token'} #{userTokenNum} · {userBooking?.services.map((s) => s.name).join(' + ') || 'Haircut + Beard'}
            </span>
            <span className="font-bold bg-white/20 px-2 py-0.5 rounded-full text-[10px]">
              {userBooking?.stylistName || 'Raju'}
            </span>
          </div>
        </div>

        {/* Section: CURRENTLY IN SERVICE */}
        <div>
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
            {isUrdu ? 'ABHI KURSI PAR CHAL RAHA HAI' : 'CURRENTLY IN SERVICE'}
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            {/* Chair 1 */}
            <div className="p-3 bg-white rounded-2xl border border-slate-200 shadow-sm flex items-start gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-purple-600 text-white font-black flex items-center justify-center shrink-0 text-sm">
                R
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-slate-900 truncate">Raju</span>
                  <span className="text-[10px] text-purple-700 font-semibold bg-purple-50 px-1.5 py-0.5 rounded">
                    Chair 1
                  </span>
                </div>
                <div className="text-[11px] text-slate-500 font-medium truncate mt-0.5">
                  #{chair1Booking?.tokenNumber || 15} · {chair1Booking?.services[0]?.name || 'Haircut'}
                </div>
              </div>
            </div>

            {/* Chair 2 */}
            <div className="p-3 bg-white rounded-2xl border border-slate-200 shadow-sm flex items-start gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-blue-600 text-white font-black flex items-center justify-center shrink-0 text-sm">
                S
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-slate-900 truncate">Sameer</span>
                  <span className="text-[10px] text-blue-700 font-semibold bg-blue-50 px-1.5 py-0.5 rounded">
                    Chair 2
                  </span>
                </div>
                <div className="text-[11px] text-slate-500 font-medium truncate mt-0.5">
                  #{chair2Booking?.tokenNumber || 16} · {chair2Booking?.services[0]?.name || 'Beard'}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Section: Queue Multi-Boxes with Dark Grey & Dark Orange Crossing Lines 3D Texture */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-[11px] font-bold text-[#8892B0] uppercase tracking-wider px-1">
            <span>{isUrdu ? 'LIVE QUEUE BOXES' : 'LIVE QUEUE BOXES'}</span>
            <span>{isUrdu ? 'Status' : 'Status'}</span>
          </div>

          <div className="grid grid-cols-2 gap-2.5 perspective-900">
            {bookings.slice(0, 8).map((b) => {
              const isSelf = b.id === userBooking?.id || b.tokenNumber === userTokenNum;
              const isChalRaha = b.status === 'chal_raha';
              const isDone = b.status === 'ho_gaya';

              return (
                <motion.div
                  key={b.id}
                  whileHover={{ rotateX: 5, rotateY: -5, scale: 1.02 }}
                  transition={{ type: 'spring', stiffness: 280, damping: 22 }}
                  className={`p-3 rounded-2xl border bg-[#172A45]/75 backdrop-blur-md transition-all preserve-3d shadow-[0_8px_20px_rgba(10,25,47,0.5)] ${
                    isSelf
                      ? 'border-[#64FFDA]/80 ring-1 ring-[#64FFDA]/40'
                      : 'border-[#8892B0]/25 hover:border-[#64FFDA]/50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-black text-blue-400 text-xs">
                      #{b.tokenNumber}
                    </span>
                    {isSelf && !isChalRaha && !isDone ? (
                      <span className="px-2 py-0.5 bg-blue-600/30 text-blue-300 font-bold text-[10px] rounded-full border border-blue-400/50">
                        {isUrdu ? 'Agla' : 'Next'}
                      </span>
                    ) : isChalRaha ? (
                      <span className="px-2 py-0.5 bg-cyan-500/20 text-cyan-300 font-semibold text-[10px] rounded-full border border-cyan-400/40">
                        {isUrdu ? 'Active' : 'Active'}
                      </span>
                    ) : isDone ? (
                      <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 font-semibold text-[10px] rounded-full border border-emerald-500/40">
                        {isUrdu ? 'Done' : 'Done'}
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 bg-slate-800/90 text-slate-300 font-medium text-[10px] rounded-full border border-slate-700">
                        {isUrdu ? 'Line' : 'Queue'}
                      </span>
                    )}
                  </div>
                  <div className="font-bold text-xs text-[#E6F1FF] truncate mt-1.5">
                    {isSelf ? (isUrdu ? 'Aap (You)' : 'You (Current)') : b.customerName}
                  </div>
                  <div className="text-[10px] text-slate-400 truncate mt-0.5">
                    {b.stylistName}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Bottom Alert Banner */}
        <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200 flex items-center gap-2.5 text-xs text-amber-900 font-semibold shadow-xs">
          <div className="w-8 h-8 rounded-full bg-amber-200/80 text-amber-800 flex items-center justify-center shrink-0">
            <BellRing className="w-4 h-4 animate-bounce" />
          </div>
          <div className="flex-1">
            {isUrdu
              ? 'Jab sirf 1 banda reh jayega toh WhatsApp par alert bhejenge'
              : 'We will alert you on WhatsApp when only 1 person is left'}
          </div>
          <button
            type="button"
            onClick={() => userBooking && sendWhatsAppAlertToOneLeft(userBooking.id)}
            className="text-[10px] bg-amber-200 hover:bg-amber-300 px-2 py-1 rounded-md text-amber-900 font-bold"
          >
            {isUrdu ? 'Alert Check' : 'Test Alert'}
          </button>
        </div>
      </div>
    </div>
  );
};
