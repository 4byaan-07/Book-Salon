import React, { useState } from 'react';
import { useSalon } from '../../context/SalonContext';
import { DATABASE_SCHEMA_TABLES } from '../../lib/seedData';
import {
  X,
  Database,
  Layers,
  ArrowRight,
  Copy,
} from 'lucide-react';

export const BlueprintFlowModal: React.FC = () => {
  const {
    showSchemaModal,
    setShowSchemaModal,
    showBlueprintModal,
    setShowBlueprintModal,
    setActiveScreenId,
    setCurrentRole,
  } = useSalon();

  const [activeTab, setActiveTab] = useState<'flow' | 'schema' | 'journey' | 'problems'>(
    showSchemaModal ? 'schema' : 'flow'
  );
  const [copiedSql, setCopiedSql] = useState(false);

  if (!showSchemaModal && !showBlueprintModal) return null;

  const handleClose = () => {
    setShowSchemaModal(false);
    setShowBlueprintModal(false);
  };

  const screens = [
    { id: 1, role: 'customer', title: '1. Slot Booking', desc: 'Services list, stylist select, day & time slot, booking confirmation' },
    { id: 2, role: 'customer', title: '2. Live Queue', desc: 'Real-time wait estimation, current chair statuses, WhatsApp 1-left alert' },
    { id: 3, role: 'customer', title: '3. Smart Reminder', desc: '30-day auto retention notice, previous haircut specs, 1-tap re-booking' },
    { id: 4, role: 'reception', title: '4. Today\'s Bookings', desc: 'Daily total customer metrics, booking vs walk-in split, stylist free/busy' },
    { id: 5, role: 'reception', title: '5. Walk-in Entry', desc: '10-sec walk-in registration, customer phone lookup, earliest stylist auto-pick' },
    { id: 6, role: 'reception', title: '6. Billing & Checkout', desc: 'Itemized billing, Cash / JazzCash / Easypaisa toggle, dynamic QR code generation, WhatsApp invoice' },
    { id: 7, role: 'staff', title: '7. Today\'s Customers', desc: 'Stylist queue list, today work earned, highlighted ACTIVE NOW customer with cut notes' },
    { id: 8, role: 'staff', title: '8. Customer History', desc: 'Visit frequency, favorite stylist, permanent haircut instructions, visit log' },
    { id: 9, role: 'malik', title: '9. Daily Revenue', desc: 'Gross revenue, Cash vs JazzCash vs Easypaisa split, service-wise breakdown, 7-day weekly bar chart' },
    { id: 10, role: 'malik', title: '10. Staff Commission', desc: 'Auto-calculated 40% commission per stylist, daily/weekly/monthly tabs, WhatsApp dispatch' },
    { id: 11, role: 'sab', title: '11. Login & OTP', desc: 'Phone OTP authentication, role-based boundary separation (Customer/Reception/Staff/Owner)' },
  ];

  const journeySteps = [
    { step: 1, title: 'Customer books a slot from home', desc: 'Selects desired service, favorite stylist, and convenient time slot without standing in lines.', icon: '📱' },
    { step: 2, title: 'Arrives right on time using live queue tracker', desc: 'Tracks remaining customers ahead directly from phone. No more wasting 45 minutes in waiting chairs.', icon: '⏳' },
    { step: 3, title: 'Stylist knows previous cut specifications', desc: 'Permanent cut notes: "#2 on sides, trim top lightly. Beard: short box shape". Complete customer delight.', icon: '✂️' },
    { step: 4, title: 'Mobile wallet checkout with instant WhatsApp receipt', desc: 'Dynamic QR generated on tablet for JazzCash & Easypaisa, instant payment receipt dispatched, commission calculated automatically.', icon: '💳' },
    { step: 5, title: 'Automated 30-day reminder', desc: 'The app automatically reminds the customer when it is time for a trim, enabling instant 1-tap re-booking.', icon: '🔔' },
  ];

  const generatePostgresSql = () => {
    return `-- ====================================================
-- AAPKA SALON - COMPLETE POSTGRESQL RELATIONAL SCHEMA
-- ====================================================

CREATE TABLE customers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phone VARCHAR(15) UNIQUE NOT NULL,
  name VARCHAR(100) NOT NULL,
  is_regular BOOLEAN DEFAULT FALSE,
  visits_count INTEGER DEFAULT 1,
  avg_frequency_days INTEGER DEFAULT 30,
  favorite_stylist_id VARCHAR(50),
  permanent_notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE stylists (
  id VARCHAR(50) PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  chair_number INTEGER NOT NULL,
  chair_name VARCHAR(50) NOT NULL,
  status VARCHAR(20) DEFAULT 'free', -- 'busy' | 'free'
  commission_rate NUMERIC(4,2) DEFAULT 0.40,
  phone VARCHAR(15) NOT NULL
);

CREATE TABLE services (
  id VARCHAR(50) PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  price NUMERIC(10,2) NOT NULL,
  duration_min INTEGER NOT NULL,
  category VARCHAR(50) NOT NULL
);

CREATE TABLE bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  token_number INTEGER NOT NULL,
  customer_id UUID REFERENCES customers(id),
  customer_name VARCHAR(100) NOT NULL,
  customer_phone VARCHAR(15) NOT NULL,
  stylist_id VARCHAR(50) REFERENCES stylists(id),
  slot_time VARCHAR(20) NOT NULL,
  date DATE NOT NULL,
  type VARCHAR(20) NOT NULL, -- 'booking' | 'walkin'
  status VARCHAR(20) NOT NULL, -- 'aane_wala' | 'chal_raha' | 'ho_gaya' | 'cancelled'
  total_amount NUMERIC(10,2) NOT NULL,
  payment_mode VARCHAR(20), -- 'cash' | 'upi'
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE billing_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id UUID REFERENCES bookings(id),
  customer_id UUID REFERENCES customers(id),
  stylist_id VARCHAR(50) REFERENCES stylists(id),
  total_amount NUMERIC(10,2) NOT NULL,
  payment_mode VARCHAR(10) NOT NULL, -- 'cash' | 'upi'
  upi_reference VARCHAR(100),
  whatsapp_receipt_sent BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE staff_commissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  stylist_id VARCHAR(50) REFERENCES stylists(id),
  date DATE NOT NULL,
  customers_served INTEGER NOT NULL,
  total_gross_work NUMERIC(10,2) NOT NULL,
  commission_rate NUMERIC(4,2) DEFAULT 0.40,
  net_payout NUMERIC(10,2) NOT NULL,
  whatsapp_summary_sent BOOLEAN DEFAULT FALSE
);

CREATE TABLE reminders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID REFERENCES customers(id),
  last_visit_date DATE NOT NULL,
  due_date DATE NOT NULL,
  preferred_stylist_id VARCHAR(50) REFERENCES stylists(id),
  status VARCHAR(20) DEFAULT 'pending',
  one_tap_booked_at TIMESTAMPTZ
);`;
  };

  const handleCopySql = () => {
    navigator.clipboard.writeText(generatePostgresSql());
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2000);
  };

  const jumpToScreen = (screenId: number, role: string) => {
    if (role === 'customer' || role === 'reception' || role === 'staff' || role === 'malik') {
      setCurrentRole(role as any);
    }
    setActiveScreenId(screenId);
    handleClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-md flex items-center justify-center p-3 md:p-6">
      <div className="bg-white rounded-3xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl border border-slate-200">
        {/* Header */}
        <div className="p-4 md:p-5 border-b border-slate-200 flex items-center justify-between bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900 text-white">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-purple-500/30 border border-purple-400/40 flex items-center justify-center">
              <Layers className="w-5 h-5 text-purple-300" />
            </div>
            <div>
              <h2 className="text-base md:text-lg font-black text-white">
                Aapka Salon · Blueprint & Architecture
              </h2>
              <p className="text-xs text-purple-200">
                11 Screens Navigation Flow, 5-Step Customer Journey & Relational Schema
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleClose}
            className="p-1.5 rounded-full text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab navigation */}
        <div className="flex items-center gap-1 p-2 bg-slate-100 border-b border-slate-200 text-xs font-bold overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('flow')}
            className={`px-3 py-1.5 rounded-xl transition-all ${
              activeTab === 'flow'
                ? 'bg-purple-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white'
            }`}
          >
            11 Screens Flow Map
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('journey')}
            className={`px-3 py-1.5 rounded-xl transition-all ${
              activeTab === 'journey'
                ? 'bg-purple-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white'
            }`}
          >
            Customer Journey (5 Steps)
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('schema')}
            className={`px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 ${
              activeTab === 'schema'
                ? 'bg-purple-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>Database Schema Details</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('problems')}
            className={`px-3 py-1.5 rounded-xl transition-all ${
              activeTab === 'problems'
                ? 'bg-purple-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white'
            }`}
          >
            3 Problems & Solutions
          </button>
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 text-slate-800">
          {/* TAB 1: 11 SCREENS FLOW */}
          {activeTab === 'flow' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-extrabold text-slate-900">
                    1 App · 4 Parts · 11 Screens Navigation Map
                  </h3>
                  <p className="text-xs text-slate-500">
                    Tap any screen card to launch its interactive live view.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {screens.map((scr) => (
                  <button
                    key={scr.id}
                    type="button"
                    onClick={() => jumpToScreen(scr.id, scr.role)}
                    className="p-3.5 rounded-2xl border border-slate-200 bg-white hover:border-purple-500 hover:shadow-md text-left transition-all duration-150 flex flex-col justify-between group"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-extrabold text-xs text-slate-900 group-hover:text-purple-700">
                          {scr.title}
                        </span>
                        <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                          {scr.role}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 font-medium leading-relaxed">
                        {scr.desc}
                      </p>
                    </div>

                    <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] font-bold text-purple-600">
                      <span>Launch Screen</span>
                      <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: CUSTOMER JOURNEY */}
          {activeTab === 'journey' && (
            <div className="space-y-4 max-w-2xl mx-auto">
              <div className="text-center pb-2">
                <span className="text-[11px] font-bold tracking-widest text-purple-700 uppercase">
                  HOW IT WORKS
                </span>
                <h3 className="text-xl font-black text-slate-900 mt-0.5">
                  The Complete Customer Journey
                </h3>
              </div>

              <div className="space-y-3">
                {journeySteps.map((j) => (
                  <div
                    key={j.step}
                    className="p-4 bg-white rounded-2xl border border-slate-200 shadow-sm flex items-start gap-4 hover:border-purple-300 transition-colors"
                  >
                    <div className="w-10 h-10 rounded-2xl bg-purple-600 text-white font-black text-base flex items-center justify-center shrink-0 shadow-sm">
                      {j.step}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="font-extrabold text-sm text-slate-900">
                        {j.title}
                      </div>
                      <div className="text-xs text-slate-500 font-medium mt-0.5">
                        {j.desc}
                      </div>
                    </div>
                    <div className="text-2xl">{j.icon}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: DATABASE SCHEMA DETAILS */}
          {activeTab === 'schema' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-200">
                <div>
                  <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                    <Database className="w-4 h-4 text-purple-600" />
                    <span>Relational Database Schema Details</span>
                  </h3>
                  <p className="text-xs text-slate-500">
                    Engineered for PostgreSQL or Firebase Firestore with full referential integrity.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleCopySql}
                  className="self-start sm:self-auto flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-colors"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copiedSql ? 'SQL Copied!' : 'Copy SQL DDL'}</span>
                </button>
              </div>

              {/* Table Schema Cards */}
              <div className="space-y-4">
                {DATABASE_SCHEMA_TABLES.map((tbl) => (
                  <div
                    key={tbl.tableName}
                    className="p-4 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-2.5"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-black text-purple-700 text-sm">
                          {tbl.tableName}
                        </span>
                        <span className="text-[10px] bg-purple-50 text-purple-800 px-2 py-0.5 rounded font-bold uppercase">
                          TABLE
                        </span>
                      </div>
                    </div>
                    <p className="text-xs text-slate-600 font-medium">{tbl.description}</p>

                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead>
                          <tr className="border-b border-slate-100 text-slate-400 font-bold text-[10px] uppercase">
                            <th className="py-1 px-2">Column</th>
                            <th className="py-1 px-2">Type</th>
                            <th className="py-1 px-2">Attributes</th>
                            <th className="py-1 px-2">Description</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-50 font-medium">
                          {tbl.columns.map((col) => (
                            <tr key={col.name} className="hover:bg-slate-50">
                              <td className="py-1.5 px-2 font-mono font-bold text-slate-900">
                                {col.name}
                              </td>
                              <td className="py-1.5 px-2 font-mono text-[11px] text-purple-700">
                                {col.type}
                              </td>
                              <td className="py-1.5 px-2 text-[10px]">
                                {col.isPrimary && (
                                  <span className="bg-amber-100 text-amber-900 px-1.5 py-0.2 rounded font-bold mr-1">
                                    PK
                                  </span>
                                )}
                                {col.isForeign && (
                                  <span className="bg-blue-100 text-blue-900 px-1.5 py-0.2 rounded font-bold mr-1">
                                    FK
                                  </span>
                                )}
                                {!col.nullable && (
                                  <span className="text-slate-400 font-mono">NOT NULL</span>
                                )}
                              </td>
                              <td className="py-1.5 px-2 text-slate-600 text-[11px]">
                                {col.description}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: 3 PROBLEMS & SOLUTION */}
          {activeTab === 'problems' && (
            <div className="space-y-4 max-w-2xl mx-auto">
              <div className="text-center pb-2">
                <span className="text-[11px] font-bold tracking-widest text-rose-600 uppercase">
                  OFFLINE VS ONLINE
                </span>
                <h3 className="text-xl font-black text-slate-900 mt-0.5">
                  3 Critical Salon Problems Solved
                </h3>
              </div>

              <div className="space-y-3">
                <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-1">
                  <div className="text-[10px] font-bold text-rose-600 uppercase">PROBLEM 1</div>
                  <div className="font-extrabold text-base text-slate-900">Uncertain Wait Times (Intezaar)</div>
                  <p className="text-xs text-slate-600">
                    "How long will it take?" "Just 2 more people." Half an hour later, still 2 people. The customer walks away frustrated.
                  </p>
                  <div className="pt-2 text-xs font-bold text-purple-700">
                    ✓ Solution: Live queue link on customer's smartphone with token tracker and real-time wait estimation!
                  </div>
                </div>

                <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-1">
                  <div className="text-[10px] font-bold text-rose-600 uppercase">PROBLEM 2</div>
                  <div className="font-extrabold text-base text-slate-900">Staff Commission Accounting</div>
                  <p className="text-xs text-slate-600">
                    4 staff members, 40 customers daily. Calculating who served whom and reconciling commission amounts late at night in physical paper registers.
                  </p>
                  <div className="pt-2 text-xs font-bold text-purple-700">
                    ✓ Solution: Automatic 40% commission split per checkout with 1-tap WhatsApp summary dispatch to staff!
                  </div>
                </div>

                <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-1">
                  <div className="text-[10px] font-bold text-rose-600 uppercase">PROBLEM 3</div>
                  <div className="font-extrabold text-base text-slate-900">Customer Retention & Return Frequency</div>
                  <p className="text-xs text-slate-600">
                    A month passes since their haircut, but nobody reminds them. Next time they inadvertently walk into a competitor's salon.
                  </p>
                  <div className="pt-2 text-xs font-bold text-purple-700">
                    ✓ Solution: Automated 30-day retention notification with past haircut specs and 1-tap instant booking!
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
