import React, { useState } from 'react';
import { useSalon } from '../../context/SalonContext';
import { findEarliestAvailableStylist, formatCurrency } from '../../lib/calculations';
import { Check, MessageCircle, ArrowRight } from 'lucide-react';

export const WalkInEntryScreen: React.FC = () => {
  const { customers, services, stylists, bookings, createWalkIn, setActiveScreenId, language } = useSalon();
  const isUrdu = language === 'roman_urdu';

  const [mobileNumber, setMobileNumber] = useState<string>('3009876543');
  const [customerName, setCustomerName] = useState<string>('Imran Qureshi');
  const [selectedServices, setSelectedServices] = useState<string[]>(['s1', 's2']); // Haircut + Beard
  const [selectedStylistId, setSelectedStylistId] = useState<string>('imran');
  const [addedToken, setAddedToken] = useState<number | null>(null);

  // Auto-detect existing customer based on entered phone
  const matchedCustomer = customers.find((c) =>
    c.phone.replace(/\D/g, '').endsWith(mobileNumber.replace(/\D/g, '').slice(-6))
  );

  // Smart suggestion for earliest available stylist
  const earliest = findEarliestAvailableStylist(stylists, bookings);

  const toggleService = (id: string) => {
    if (selectedServices.includes(id)) {
      if (selectedServices.length > 1) {
        setSelectedServices(selectedServices.filter((s) => s !== id));
      }
    } else {
      setSelectedServices([...selectedServices, id]);
    }
  };

  const chosenServices = services.filter((s) => selectedServices.includes(s.id));
  const totalAmount = chosenServices.reduce((sum, s) => sum + s.price, 0);

  const handleQuickCustomerSelect = (phone: string, name: string) => {
    setMobileNumber(phone);
    setCustomerName(name);
  };

  const handleAddToQueue = () => {
    const { tokenNumber } = createWalkIn({
      customerPhone: `+92 ${mobileNumber}`,
      customerName: matchedCustomer?.name || customerName || 'Walk-in Guest',
      serviceIds: selectedServices,
      preferredStylistId: selectedStylistId || earliest.stylist.id,
    });
    setAddedToken(tokenNumber);
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 text-slate-900 pb-28">
      {/* Top Header */}
      <div className="pt-2 px-5 pb-2">
        <div className="flex items-center justify-between text-[11px] font-bold tracking-wider text-purple-700 uppercase">
          <span>{isUrdu ? 'AAPKA SALON · RECEPTION' : 'AAPKA SALON · RECEPTION'}</span>
          <span className="px-2 py-0.5 rounded bg-purple-100 text-purple-800 text-[10px]">DEMO</span>
        </div>
        <div className="mt-1">
          <h1 className="text-2xl font-extrabold text-slate-900">
            {isUrdu ? 'Walk-in Entry' : 'Walk-in Entry'}
          </h1>
          <p className="text-xs text-slate-500 font-medium mt-0.5">
            {isUrdu
              ? 'Naya customer aaya? 10 seconds mein live line mein daalein'
              : 'Customer arrived? Add to queue in 10 seconds'}
          </p>
        </div>
      </div>

      <div className="flex-1 px-5 space-y-3.5 overflow-y-auto">
        {/* Mobile Input with Returning customer status */}
        <div className="p-3.5 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              {isUrdu ? 'MOBILE NUMBER' : 'MOBILE NUMBER'}
            </span>
            {matchedCustomer && (
              <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-full text-[10px] font-bold flex items-center gap-1">
                <span>✓</span>
                <span>{isUrdu ? 'Purana Customer' : 'Returning Customer'}</span>
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-500">+92</span>
            <input
              type="text"
              value={mobileNumber}
              onChange={(e) => setMobileNumber(e.target.value)}
              placeholder="300 9876543"
              className="flex-1 font-mono font-bold text-sm text-slate-900 focus:outline-none"
            />
          </div>

          {/* Matched Customer Profile Card if exists */}
          {matchedCustomer && (
            <div className="pt-2 border-t border-slate-100 flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-emerald-600 text-white font-extrabold text-xs flex items-center justify-center shrink-0">
                {matchedCustomer.name.slice(0, 2).toUpperCase()}
              </div>
              <div className="min-w-0 flex-1">
                <div className="font-extrabold text-xs text-slate-900 truncate">
                  {matchedCustomer.name}
                </div>
                <div className="text-[11px] text-slate-500 truncate">
                  {isUrdu ? 'Pichla visit:' : 'Last visit:'} {matchedCustomer.lastVisit}
                </div>
              </div>
            </div>
          )}

          {!matchedCustomer && (
            <div className="pt-2 border-t border-slate-100">
              <input
                type="text"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder={isUrdu ? "Customer Ka Naam (Naya Grahak)" : "Customer Name (New Guest)"}
                className="w-full text-xs font-medium text-slate-800 placeholder:text-slate-400 focus:outline-none"
              />
            </div>
          )}
        </div>

        {/* Quick select demo buttons */}
        <div className="flex items-center gap-1.5 text-[10px] text-slate-500">
          <span>{isUrdu ? 'Demo Grahak:' : 'Quick Demo:'}</span>
          <button
            type="button"
            onClick={() => handleQuickCustomerSelect('3009876543', 'Imran Q.')}
            className="px-2 py-0.5 rounded bg-slate-200 hover:bg-purple-100 text-slate-700 font-semibold"
          >
            Imran Q.
          </button>
          <button
            type="button"
            onClick={() => handleQuickCustomerSelect('3339876543', 'Bilal Ahmed')}
            className="px-2 py-0.5 rounded bg-slate-200 hover:bg-purple-100 text-slate-700 font-semibold"
          >
            Bilal A.
          </button>
          <button
            type="button"
            onClick={() => handleQuickCustomerSelect('3459876543', 'Rohan Malik')}
            className="px-2 py-0.5 rounded bg-slate-200 hover:bg-purple-100 text-slate-700 font-semibold"
          >
            {isUrdu ? '+ Naya Grahak' : '+ New Guest'}
          </button>
        </div>

        {/* SERVICES Selection Chips */}
        <div>
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
            {isUrdu ? 'SERVICES CHUNEIN' : 'SELECT SERVICES'}
          </div>
          <div className="flex flex-wrap gap-2">
            {services.map((s) => {
              const isSelected = selectedServices.includes(s.id);
              return (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => toggleService(s.id)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                    isSelected
                      ? 'bg-purple-600 text-white shadow-sm ring-2 ring-purple-300'
                      : 'bg-white border border-slate-200 text-slate-700 hover:border-slate-300'
                  }`}
                >
                  {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                  <span>{s.name}</span>
                  <span className="opacity-80 text-[11px] font-normal">{formatCurrency(s.price)}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* EARLIEST AVAILABLE Stylist Box */}
        <div>
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
            {isUrdu ? 'SABSE JALDI FREE HONE WALA STYLIST' : 'EARLIEST AVAILABLE STYLIST'}
          </div>
          <div className="p-3 bg-blue-50/80 rounded-2xl border border-blue-200 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center justify-center">
                {earliest.stylist.avatarLetter}
              </div>
              <div>
                <div className="text-xs font-extrabold text-blue-950">
                  {earliest.stylist.name} · {earliest.stylist.chairName}
                </div>
                <div className="text-[11px] text-blue-700 font-medium">
                  {earliest.waitMinutes === 0
                    ? (isUrdu ? 'Abhi bilkul free hai' : 'Free right now')
                    : (isUrdu ? `~${earliest.waitMinutes} min intezar` : `~${earliest.waitMinutes} min wait`)}
                </div>
              </div>
            </div>

            <div className="text-xs font-black text-blue-800 bg-white px-2.5 py-1 rounded-xl shadow-xs border border-blue-100">
              {earliest.waitMinutes === 0
                ? (isUrdu ? 'Fauri' : 'Instant')
                : `~${earliest.waitMinutes} min`}
            </div>
          </div>
        </div>

        {/* Token Preview / Result Box */}
        <div className="p-4 bg-slate-900 rounded-3xl text-white shadow-md flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="text-2xl font-black text-amber-400 font-mono">
              #{addedToken || bookings[bookings.length - 1]?.tokenNumber + 1 || 18}
            </div>
            <div>
              <div className="text-xs font-bold text-white">
                {isUrdu ? 'Token Number Mila' : 'Token Assigned'}
              </div>
              <div className="text-[11px] text-slate-300 flex items-center gap-1">
                <MessageCircle className="w-3 h-3 text-emerald-400" />
                <span>
                  {isUrdu ? 'WhatsApp par live line ka link bhej diya' : 'Live queue link sent via WhatsApp'}
                </span>
              </div>
            </div>
          </div>
          <div className="text-xs font-bold text-purple-300">
            {formatCurrency(totalAmount)}
          </div>
        </div>

        {/* Primary Action Button */}
        <button
          type="button"
          onClick={handleAddToQueue}
          className="w-full py-3.5 bg-gradient-to-r from-pink-500 via-purple-600 to-indigo-600 hover:opacity-95 text-white font-extrabold text-sm rounded-2xl shadow-lg shadow-purple-600/30 flex items-center justify-center gap-2 transition-transform active:scale-[0.99]"
        >
          <span>{isUrdu ? 'Line Mein Daalein' : 'Add to Live Queue'}</span>
          <ArrowRight className="w-4 h-4 stroke-[3]" />
        </button>

        {addedToken && (
          <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200 text-xs text-emerald-900 flex items-center justify-between">
            <span>
              {isUrdu
                ? `Customer #${addedToken} line mein kamyabi se shamil ho gaya!`
                : `Customer #${addedToken} successfully added to queue!`}
            </span>
            <button
              type="button"
              onClick={() => setActiveScreenId(4)}
              className="text-purple-700 font-bold underline text-[11px]"
            >
              {isUrdu ? 'Bookings dekhein →' : 'View bookings →'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
