export type UserRole = 'customer' | 'reception' | 'staff' | 'malik';

export type BookingStatus = 'aane_wala' | 'chal_raha' | 'ho_gaya' | 'cancelled';
export type BookingType = 'booking' | 'walkin';
export type PaymentMode = 'cash' | 'jazzcash' | 'easypaisa';
export type AppLanguage = 'english' | 'roman_urdu';
export type AppTheme = 'light' | 'dark';

export interface ServiceItem {
  id: string;
  name: string;
  romanUrduName?: string;
  price: number;
  durationMin: number;
  category: 'hair' | 'beard' | 'facial' | 'spa' | 'colour';
  icon?: string;
}

export interface Stylist {
  id: string;
  name: string;
  chair: number;
  chairName: string;
  status: 'busy' | 'free';
  avatarLetter: string;
  avatarColor: string;
  commissionRate: number; // e.g. 0.40 for 40%
  phone: string;
}

export interface Booking {
  id: string;
  tokenNumber: number;
  customerName: string;
  customerPhone: string;
  stylistId: string;
  stylistName: string;
  chair: number;
  services: ServiceItem[];
  totalAmount: number;
  slotTime: string;
  date: string;
  type: BookingType;
  status: BookingStatus;
  notes?: string;
  isCurrentUser?: boolean;
  paymentMode?: PaymentMode;
  paidAt?: string;
}

export interface VisitRecord {
  id: string;
  date: string;
  formattedDate: string;
  service: string;
  stylist: string;
  amount: number;
  cutStyle?: string;
  notes?: string;
}

export interface CustomerProfile {
  id: string;
  name: string;
  phone: string;
  isRegular: boolean;
  lastVisit: string;
  lastService: string;
  visitsCount: number;
  avgFrequencyDays: number;
  favoriteStylist: string;
  permanentNote: string;
  beardNote?: string;
  history: VisitRecord[];
}

export interface StaffCommissionResult {
  stylistId: string;
  stylistName: string;
  chairName: string;
  avatarLetter: string;
  avatarColor: string;
  customerCount: number;
  totalWorkAmount: number;
  commissionRate: number;
  commissionAmount: number;
}

export interface DailyMetrics {
  totalRevenue: number;
  cashAmount: number;
  jazzcashAmount: number;
  easypaisaAmount: number;
  totalCustomers: number;
  bookingCount: number;
  walkinCount: number;
  serviceWiseRevenue: { name: string; amount: number; percentage: number }[];
  weeklyRevenue: { day: string; fullDay: string; amount: number; isSunday?: boolean; isToday?: boolean }[];
}

export interface DatabaseSchemaTable {
  tableName: string;
  description: string;
  columns: {
    name: string;
    type: string;
    isPrimary?: boolean;
    isForeign?: boolean;
    nullable: boolean;
    description: string;
  }[];
}

export interface ReviewItem {
  id: string;
  customerName: string;
  stylistId: string;
  stylistName: string;
  salonRating: number;
  barberRating: number;
  comment: string;
  tags: string[];
  createdAt: string;
}

export interface HairstyleOption {
  id: string;
  name: string;
  romanUrduName: string;
  description: string;
  romanUrduDesc: string;
  price: number;
  durationMin: number;
  badge: string;
  overlayType: 'fade' | 'crop' | 'pompadour' | 'buzz' | 'sidepart' | 'taper';
  accentColor: string;
}
