import React, { createContext, useContext, useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import {
  AppLanguage,
  AppTheme,
  Booking,
  CustomerProfile,
  PaymentMode,
  ReviewItem,
  ServiceItem,
  Stylist,
  UserRole,
} from '../lib/types';
import {
  INITIAL_BOOKINGS,
  INITIAL_CUSTOMERS,
  INITIAL_REVIEWS,
  INITIAL_SERVICES,
  INITIAL_STYLISTS,
} from '../lib/seedData';
import {
  findEarliestAvailableStylist,
  formatCurrency,
  generateWhatsAppMessage,
} from '../lib/calculations';

interface WhatsAppSimState {
  isOpen: boolean;
  type: 'booking' | 'queue_alert' | 'bill' | 'reminder' | 'staff_commission';
  recipientName: string;
  recipientPhone: string;
  messageText: string;
}

interface SalonContextType {
  // Navigation & Role
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
  activeScreenId: number;
  setActiveScreenId: (id: number) => void;
  language: AppLanguage;
  setLanguage: (lang: AppLanguage) => void;
  theme: AppTheme;
  setTheme: (theme: AppTheme) => void;
  isPhoneFrame: boolean;
  setIsPhoneFrame: (val: boolean) => void;
  showSchemaModal: boolean;
  setShowSchemaModal: (val: boolean) => void;
  showBlueprintModal: boolean;
  setShowBlueprintModal: (val: boolean) => void;
  selectedTryOnStyle: string | null;
  setSelectedTryOnStyle: (styleName: string | null) => void;

  // Selected entities
  activeStylistId: string;
  setActiveStylistId: (id: string) => void;
  selectedCustomerId: string;
  setSelectedCustomerId: (id: string) => void;

  // Core Data
  services: ServiceItem[];
  stylists: Stylist[];
  bookings: Booking[];
  customers: CustomerProfile[];
  reviews: ReviewItem[];
  addReview: (review: Omit<ReviewItem, 'id' | 'createdAt'>) => void;

  // WhatsApp simulation modal
  whatsappSim: WhatsAppSimState;
  closeWhatsAppModal: () => void;
  triggerWhatsAppSim: (
    type: 'booking' | 'queue_alert' | 'bill' | 'reminder' | 'staff_commission',
    recipientName: string,
    recipientPhone: string,
    messageText: string
  ) => void;

  // Actions
  createSlotBooking: (params: {
    customerName: string;
    customerPhone: string;
    stylistId: string;
    serviceIds: string[];
    date: string;
    slotTime: string;
    advancePaid?: boolean;
  }) => { booking: Booking; tokenNumber: number };

  createWalkIn: (params: {
    customerPhone: string;
    customerName?: string;
    serviceIds: string[];
    preferredStylistId?: string;
  }) => { booking: Booking; tokenNumber: number };

  updateBookingStatus: (bookingId: string, status: Booking['status']) => void;

  processBilling: (params: {
    bookingId: string;
    services: ServiceItem[];
    paymentMode: PaymentMode;
  }) => void;

  simulateNextCustomerInQueue: () => void;
  resetAllData: () => void;
  sendWhatsAppAlertToOneLeft: (bookingId: string) => void;
}

const SalonContext = createContext<SalonContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'aapka_salon_state_v2_pkr';

export const SalonProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentRole, setCurrentRole] = useState<UserRole>('customer');
  const [activeScreenId, setActiveScreenId] = useState<number>(1);
  const [language, setLanguage] = useState<AppLanguage>('english'); // 'english' | 'roman_urdu'
  const [theme, setTheme] = useState<AppTheme>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_theme`);
    return (saved === 'dark' || saved === 'light') ? saved : 'light';
  });
  const [isPhoneFrame, setIsPhoneFrame] = useState<boolean>(true);
  const [showSchemaModal, setShowSchemaModal] = useState<boolean>(false);
  const [showBlueprintModal, setShowBlueprintModal] = useState<boolean>(false);
  const [selectedTryOnStyle, setSelectedTryOnStyle] = useState<string | null>(null);

  const [activeStylistId, setActiveStylistId] = useState<string>('raju');
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('c1');

  const [services] = useState<ServiceItem[]>(INITIAL_SERVICES);
  const [stylists, setStylists] = useState<Stylist[]>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_stylists`);
    return saved ? JSON.parse(saved) : INITIAL_STYLISTS;
  });

  const [bookings, setBookings] = useState<Booking[]>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_bookings`);
    return saved ? JSON.parse(saved) : INITIAL_BOOKINGS;
  });

  const [customers, setCustomers] = useState<CustomerProfile[]>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_customers`);
    return saved ? JSON.parse(saved) : INITIAL_CUSTOMERS;
  });

  const [reviews, setReviews] = useState<ReviewItem[]>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_reviews`);
    return saved ? JSON.parse(saved) : INITIAL_REVIEWS;
  });

  const [whatsappSim, setWhatsappSim] = useState<WhatsAppSimState>({
    isOpen: false,
    type: 'booking',
    recipientName: '',
    recipientPhone: '',
    messageText: '',
  });

  useEffect(() => {
    try {
      localStorage.setItem(`${LOCAL_STORAGE_KEY}_bookings`, JSON.stringify(bookings));
      localStorage.setItem(`${LOCAL_STORAGE_KEY}_stylists`, JSON.stringify(stylists));
      localStorage.setItem(`${LOCAL_STORAGE_KEY}_customers`, JSON.stringify(customers));
      localStorage.setItem(`${LOCAL_STORAGE_KEY}_reviews`, JSON.stringify(reviews));
      localStorage.setItem(`${LOCAL_STORAGE_KEY}_theme`, theme);
    } catch {
      // Ignore quota errors
    }
  }, [bookings, stylists, customers, reviews, theme]);

  const addReview = (review: Omit<ReviewItem, 'id' | 'createdAt'>) => {
    const newReview: ReviewItem = {
      ...review,
      id: `rev-${Date.now()}`,
      createdAt: 'Just now',
    };
    setReviews((prev) => [newReview, ...prev]);
  };

  const triggerWhatsAppSim = (
    type: 'booking' | 'queue_alert' | 'bill' | 'reminder' | 'staff_commission',
    recipientName: string,
    recipientPhone: string,
    messageText: string
  ) => {
    setWhatsappSim({
      isOpen: true,
      type,
      recipientName,
      recipientPhone,
      messageText,
    });
  };

  const closeWhatsAppModal = () => {
    setWhatsappSim((prev) => ({ ...prev, isOpen: false }));
  };

  const getNextTokenNumber = () => {
    const maxToken = bookings.reduce((max, b) => Math.max(max, b.tokenNumber || 0), 14);
    return maxToken + 1;
  };

  const createSlotBooking = ({
    customerName,
    customerPhone,
    stylistId,
    serviceIds,
    date,
    slotTime,
  }: {
    customerName: string;
    customerPhone: string;
    stylistId: string;
    serviceIds: string[];
    date: string;
    slotTime: string;
    advancePaid?: boolean;
  }) => {
    const chosenStylist =
      stylists.find((s) => s.id === stylistId) ||
      (stylistId === 'any' ? stylists[0] : stylists[0]);

    const chosenServices = services.filter((s) => serviceIds.includes(s.id));
    const totalAmount = chosenServices.reduce((sum, s) => sum + s.price, 0);
    const tokenNumber = getNextTokenNumber();

    const newBooking: Booking = {
      id: `b-${Date.now()}`,
      tokenNumber,
      customerName: customerName || 'Amit Sharma',
      customerPhone: customerPhone || '+92 300 9876210',
      stylistId: chosenStylist.id,
      stylistName: chosenStylist.name,
      chair: chosenStylist.chair,
      services: chosenServices,
      totalAmount,
      slotTime,
      date,
      type: 'booking',
      status: 'aane_wala',
      isCurrentUser: true,
    };

    setBookings((prev) => [...prev, newBooking]);

    try {
      confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });
    } catch {
      // silent
    }

    const waText = generateWhatsAppMessage(
      'booking',
      {
        customerName: newBooking.customerName,
        date,
        slotTime,
        services: chosenServices.map((s) => s.name).join(' + '),
        stylistName: chosenStylist.name,
        tokenNumber,
      },
      language
    );

    triggerWhatsAppSim(
      'booking',
      newBooking.customerName,
      newBooking.customerPhone,
      waText
    );

    return { booking: newBooking, tokenNumber };
  };

  const createWalkIn = ({
    customerPhone,
    customerName,
    serviceIds,
    preferredStylistId,
  }: {
    customerPhone: string;
    customerName?: string;
    serviceIds: string[];
    preferredStylistId?: string;
  }) => {
    const existingCust = customers.find(
      (c) => c.phone.replace(/\D/g, '').endsWith(customerPhone.replace(/\D/g, '').slice(-7))
    );

    const name = customerName || existingCust?.name || (language === 'roman_urdu' ? 'Walk-in Mehman' : 'Walk-in Guest');
    const chosenServices = services.filter((s) => serviceIds.includes(s.id));
    const totalAmount = chosenServices.reduce((sum, s) => sum + s.price, 0);

    let assignedStylist = stylists.find((s) => s.id === preferredStylistId);
    if (!assignedStylist) {
      const { stylist } = findEarliestAvailableStylist(stylists, bookings);
      assignedStylist = stylist;
    }

    const tokenNumber = getNextTokenNumber();

    const newBooking: Booking = {
      id: `b-walkin-${Date.now()}`,
      tokenNumber,
      customerName: name,
      customerPhone,
      stylistId: assignedStylist.id,
      stylistName: assignedStylist.name,
      chair: assignedStylist.chair,
      services: chosenServices,
      totalAmount,
      slotTime: language === 'roman_urdu' ? 'Abhi' : 'Now',
      date: 'Sun, Nov 2',
      type: 'walkin',
      status: 'aane_wala',
    };

    setBookings((prev) => [...prev, newBooking]);

    if (existingCust) {
      setCustomers((prev) =>
        prev.map((c) =>
          c.id === existingCust.id
            ? {
                ...c,
                visitsCount: c.visitsCount + 1,
                lastVisit: `Today · ${chosenServices.map((s) => s.name).join(' + ')}`,
              }
            : c
        )
      );
    } else {
      const newCust: CustomerProfile = {
        id: `c-${Date.now()}`,
        name,
        phone: customerPhone,
        isRegular: false,
        lastVisit: `Today · ${chosenServices.map((s) => s.name).join(' + ')}`,
        lastService: chosenServices[0]?.name || 'Haircut',
        visitsCount: 1,
        avgFrequencyDays: 30,
        favoriteStylist: assignedStylist.name,
        permanentNote: language === 'roman_urdu' ? 'Naya customer' : 'New customer',
        history: [],
      };
      setCustomers((prev) => [...prev, newCust]);
    }

    const waText = language === 'roman_urdu'
      ? `💈 *Aapka Salon - Walk-in Token #${tokenNumber}*\n\nSalam ${name}! Aapka token line mein shamil kar diya gaya hai.\n\n👤 Stylist: ${assignedStylist.name} (${assignedStylist.chairName})\n✂️ Services: ${chosenServices.map((s) => s.name).join(' + ')}\n\nLive queue tracker: https://aapkasalon.app/live-queue?t=${tokenNumber}\nJab sirf 1 banda reh jayega toh aapko WhatsApp alert bhej diya jayega!`
      : `💈 *Aapka Salon - Walk-in Token #${tokenNumber}*\n\nHello ${name}! You have been added to the queue.\n\n👤 Stylist: ${assignedStylist.name} (${assignedStylist.chairName})\n✂️ Services: ${chosenServices.map((s) => s.name).join(' + ')}\n\nLive queue tracker: https://aapkasalon.app/live-queue?t=${tokenNumber}\nWe will alert you via WhatsApp when 1 person is left ahead of you!`;

    triggerWhatsAppSim('queue_alert', name, customerPhone, waText);

    return { booking: newBooking, tokenNumber };
  };

  const updateBookingStatus = (bookingId: string, status: Booking['status']) => {
    setBookings((prev) =>
      prev.map((b) => (b.id === bookingId ? { ...b, status } : b))
    );

    const targetBooking = bookings.find((b) => b.id === bookingId);
    if (targetBooking && status === 'chal_raha') {
      setStylists((prev) =>
        prev.map((s) => (s.id === targetBooking.stylistId ? { ...s, status: 'busy' } : s))
      );
    }
  };

  const processBilling = ({
    bookingId,
    services: billServices,
    paymentMode,
  }: {
    bookingId: string;
    services: ServiceItem[];
    paymentMode: PaymentMode;
  }) => {
    const totalAmount = billServices.reduce((sum, s) => sum + s.price, 0);

    setBookings((prev) =>
      prev.map((b) => {
        if (b.id === bookingId) {
          return {
            ...b,
            services: billServices,
            totalAmount,
            status: 'ho_gaya',
            paymentMode,
            paidAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          };
        }
        return b;
      })
    );

    const b = bookings.find((item) => item.id === bookingId);
    if (b) {
      try {
        confetti({ particleCount: 60, spread: 70, origin: { y: 0.6 } });
      } catch {
        // silent
      }

      const receiptMsg = generateWhatsAppMessage(
        'bill',
        {
          customerName: b.customerName,
          stylistName: b.stylistName,
          chairName: `Chair ${b.chair}`,
          serviceLines: billServices.map((s) => `• ${s.name}: ${formatCurrency(s.price)}`).join('\n'),
          total: totalAmount,
          paymentMode,
        },
        language
      );

      triggerWhatsAppSim('bill', b.customerName, b.customerPhone, receiptMsg);
    }
  };

  const sendWhatsAppAlertToOneLeft = (bookingId: string) => {
    const b = bookings.find((item) => item.id === bookingId);
    if (b) {
      const waText = generateWhatsAppMessage(
        'queue_alert',
        {
          customerName: b.customerName,
          tokenNumber: b.tokenNumber,
          stylistName: b.stylistName,
        },
        language
      );
      triggerWhatsAppSim('queue_alert', b.customerName, b.customerPhone, waText);
    }
  };

  const simulateNextCustomerInQueue = () => {
    const active = bookings.find((b) => b.status === 'chal_raha');
    if (active) {
      updateBookingStatus(active.id, 'ho_gaya');
    }

    const nextWaiting = bookings.find((b) => b.status === 'aane_wala');
    if (nextWaiting) {
      updateBookingStatus(nextWaiting.id, 'chal_raha');
      sendWhatsAppAlertToOneLeft(nextWaiting.id);
    }
  };

  const resetAllData = () => {
    localStorage.removeItem(`${LOCAL_STORAGE_KEY}_bookings`);
    localStorage.removeItem(`${LOCAL_STORAGE_KEY}_stylists`);
    localStorage.removeItem(`${LOCAL_STORAGE_KEY}_customers`);
    localStorage.removeItem(`${LOCAL_STORAGE_KEY}_reviews`);
    setBookings(INITIAL_BOOKINGS);
    setStylists(INITIAL_STYLISTS);
    setCustomers(INITIAL_CUSTOMERS);
    setReviews(INITIAL_REVIEWS);
  };

  return (
    <SalonContext.Provider
      value={{
        currentRole,
        setCurrentRole,
        activeScreenId,
        setActiveScreenId,
        language,
        setLanguage,
        theme,
        setTheme,
        isPhoneFrame,
        setIsPhoneFrame,
        showSchemaModal,
        setShowSchemaModal,
        showBlueprintModal,
        setShowBlueprintModal,
        selectedTryOnStyle,
        setSelectedTryOnStyle,
        activeStylistId,
        setActiveStylistId,
        selectedCustomerId,
        setSelectedCustomerId,
        services,
        stylists,
        bookings,
        customers,
        reviews,
        addReview,
        whatsappSim,
        closeWhatsAppModal,
        triggerWhatsAppSim,
        createSlotBooking,
        createWalkIn,
        updateBookingStatus,
        processBilling,
        simulateNextCustomerInQueue,
        resetAllData,
        sendWhatsAppAlertToOneLeft,
      }}
    >
      {children}
    </SalonContext.Provider>
  );
};

export const useSalon = (): SalonContextType => {
  const context = useContext(SalonContext);
  if (!context) {
    throw new Error('useSalon must be used within a SalonProvider');
  }
  return context;
};
