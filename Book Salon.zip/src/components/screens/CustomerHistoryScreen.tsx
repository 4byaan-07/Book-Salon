import React, { useState } from 'react';
import { useSalon } from '../../context/SalonContext';
import { formatCurrency } from '../../lib/calculations';
import { Edit3, Check } from 'lucide-react';

export const CustomerHistoryScreen: React.FC = () => {
  const { customers, selectedCustomerId, setSelectedCustomerId, language } = useSalon();
  const isUrdu = language === 'roman_urdu';

  const customer = customers.find((c) => c.id === selectedCustomerId) || customers[0];

  const [isEditingNote, setIsEditingNote] = useState<boolean>(false);
  const [noteText, setNoteText] = useState<string>(
    customer?.permanentNote || '#2 on sides, trim top lightly.\nBeard: short box shape.'
  );

  return (
    <div className="flex flex-col h-full bg-slate-50 text-slate-900 pb-28">
      {/* Top Header */}
      <div className="pt-2 px-5 pb-2">
        <div className="flex items-center justify-between text-[11px] font-bold tracking-wider text-purple-700 uppercase">
          <span>{isUrdu ? 'AAPKA SALON · STAFF' : 'AAPKA SALON · STAFF'}</span>
          <span className="px-2 py-0.5 rounded bg-purple-100 text-purple-800 text-[10px]">DEMO</span>
        </div>
        <div className="mt-1">
          <h1 className="text-2xl font-extrabold text-slate-900">
            {isUrdu ? 'Customer Ka Record' : 'Customer History'}
          </h1>
          <p className="text-xs text-slate-500 font-medium mt-0.5">
            {isUrdu
              ? 'Kaun kab aaya, kaunsi service li, sab darj hai'
              : 'Who visited, when, and services performed'}
          </p>
        </div>
      </div>

      <div className="flex-1 px-5 space-y-3 overflow-y-auto">
        {/* Customer Switcher bar */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          <span className="text-[10px] text-slate-400 font-bold uppercase shrink-0">
            {isUrdu ? 'Customers:' : 'Customers:'}
          </span>
          {customers.slice(0, 4).map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => {
                setSelectedCustomerId(c.id);
                setNoteText(c.permanentNote);
              }}
              className={`px-2.5 py-1 rounded-lg font-bold whitespace-nowrap transition-colors ${
                c.id === customer.id
                  ? 'bg-purple-600 text-white shadow-xs'
                  : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              {c.name}
            </button>
          ))}
        </div>

        {/* Customer Profile Card */}
        <div className="p-3.5 bg-white rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-purple-600 text-white font-extrabold text-sm flex items-center justify-center">
              {customer.name.slice(0, 2).toUpperCase()}
            </div>
            <div>
              <div className="font-extrabold text-sm text-slate-900">{customer.name}</div>
              <div className="text-xs text-slate-500 font-medium">
                {isUrdu
                  ? `${customer.visitsCount} visits · har ~${customer.avgFrequencyDays} din baad`
                  : `${customer.visitsCount} visits · every ~${customer.avgFrequencyDays} days`}
              </div>
            </div>
          </div>

          <span className="px-2.5 py-1 bg-purple-50 text-purple-700 border border-purple-200 rounded-full text-[11px] font-bold">
            {isUrdu ? `Khas: ${customer.favoriteStylist}` : `Fav: ${customer.favoriteStylist}`}
          </span>
        </div>

        {/* NOTE Box */}
        <div className="p-3 bg-amber-50/90 rounded-2xl border border-amber-200 text-xs shadow-xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-black text-amber-900 uppercase tracking-wider">
              {isUrdu ? 'HAMESHA KA NOTE (PERMANENT NOTE)' : 'PERMANENT NOTES'}
            </span>
            <button
              type="button"
              onClick={() => setIsEditingNote(!isEditingNote)}
              className="text-amber-800 hover:text-amber-950 font-bold text-[10px] flex items-center gap-1"
            >
              {isEditingNote ? <Check className="w-3 h-3" /> : <Edit3 className="w-3 h-3" />}
              <span>{isEditingNote ? (isUrdu ? 'Mehfooz Karein' : 'Save') : (isUrdu ? 'Badlein' : 'Edit Note')}</span>
            </button>
          </div>

          {isEditingNote ? (
            <textarea
              value={noteText}
              onChange={(e) => setNoteText(e.target.value)}
              rows={2}
              className="w-full p-2 bg-white border border-amber-300 rounded-lg text-xs font-medium text-slate-800 focus:outline-none"
            />
          ) : (
            <div className="text-amber-950 font-medium leading-relaxed whitespace-pre-line">
              {noteText}
            </div>
          )}
        </div>

        {/* VISITS Timeline */}
        <div>
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
            {isUrdu ? 'PICHLE VISITS KA RECORD' : 'PAST VISITS'}
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 divide-y divide-slate-100 shadow-sm overflow-hidden">
            {customer.history.length > 0 ? (
              customer.history.map((visit) => (
                <div key={visit.id} className="p-3 flex items-center justify-between text-xs">
                  <div className="flex items-start gap-3">
                    <div className="text-center shrink-0 w-8">
                      <div className="font-extrabold text-sm text-slate-900 leading-none">
                        {visit.formattedDate.split(' ')[0]}
                      </div>
                      <div className="text-[10px] font-bold text-slate-400 uppercase mt-0.5">
                        {visit.formattedDate.split(' ')[1]}
                      </div>
                    </div>

                    <div>
                      <div className="font-extrabold text-slate-900">{visit.service}</div>
                      <div className="text-[11px] text-slate-500 font-medium">
                        {visit.stylist}
                        {visit.cutStyle && <span className="text-purple-600"> · {visit.cutStyle}</span>}
                      </div>
                    </div>
                  </div>

                  <div className="font-mono font-bold text-slate-900 text-xs">
                    {formatCurrency(visit.amount)}
                  </div>
                </div>
              ))
            ) : (
              <div className="p-4 text-center text-xs text-slate-400">
                {isUrdu ? 'Koi pichla record nahi mila' : 'No past visit records found'}
              </div>
            )}
          </div>
        </div>

        {/* Blueprint callout */}
        <div className="p-3 bg-purple-50 rounded-xl border border-purple-100 text-purple-900 text-[11px] leading-relaxed">
          ✂️ <strong>{isUrdu ? 'Fayeda:' : 'Value:'}</strong>{' '}
          {isUrdu
            ? 'Kabhi ye na poochna pare "Pichli baar kaisa kata tha?". Har visit, haircut ka tareeqa, stylist aur instructions record mein rehte hain!'
            : 'Never ask "How did we cut it last time?" again. Every visit, service, stylist, and custom instruction is permanently logged!'}
        </div>
      </div>
    </div>
  );
};
