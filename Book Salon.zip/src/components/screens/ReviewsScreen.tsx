import React, { useState } from 'react';
import { useSalon } from '../../context/SalonContext';
import { Star, Check, MessageSquarePlus, Award } from 'lucide-react';
import { motion } from 'motion/react';

export const ReviewsScreen: React.FC = () => {
  const { stylists, reviews, addReview, language } = useSalon();
  const isUrdu = language === 'roman_urdu';

  const [selectedStylistId, setSelectedStylistId] = useState<string>('raju');
  const [salonRating, setSalonRating] = useState<number>(5);
  const [barberRating, setBarberRating] = useState<number>(5);
  const [customerName, setCustomerName] = useState<string>('');
  const [comment, setComment] = useState<string>('');
  const [selectedTags, setSelectedTags] = useState<string[]>(['Clean Fade']);
  const [submitted, setSubmitted] = useState<boolean>(false);
  const [filterStylist, setFilterStylist] = useState<string>('all');

  const availableTags = isUrdu
    ? ['Saaf Fade', 'Waqt Par', 'Khush-Akhlaq', 'Safai', 'Munasib Qeemat']
    : ['Clean Fade', 'On Time', 'Friendly', 'Great Hygiene', 'Value for Money'];

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  const getBarberStats = (stylistId: string) => {
    const barberReviews = reviews.filter((r) => r.stylistId === stylistId);
    if (barberReviews.length === 0) return { avg: '5.0', count: 0 };
    const sum = barberReviews.reduce((acc, r) => acc + r.barberRating, 0);
    return {
      avg: (sum / barberReviews.length).toFixed(1),
      count: barberReviews.length,
    };
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const stylist = stylists.find((s) => s.id === selectedStylistId) || stylists[0];
    addReview({
      customerName: customerName.trim() || (isUrdu ? 'Grahak' : 'Verified Guest'),
      stylistId: stylist.id,
      stylistName: stylist.name,
      salonRating,
      barberRating,
      comment:
        comment.trim() ||
        (isUrdu
          ? `${stylist.name} ne bohot umda kaam kiya!`
          : `Great experience with ${stylist.name}!`),
      tags: selectedTags,
    });
    setCustomerName('');
    setComment('');
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
  };

  const filteredReviews =
    filterStylist === 'all'
      ? reviews
      : reviews.filter((r) => r.stylistId === filterStylist);

  return (
    <div className="flex flex-col h-full bg-transparent text-slate-900 dark:text-slate-100 pb-28 transition-colors">
      {/* Header */}
      <div className="pt-3 px-5 pb-3 border-b border-blue-200/70 dark:border-blue-500/20 bg-white/60 dark:bg-slate-950/60 backdrop-blur-md">
        <div className="flex items-center justify-between text-[10px] font-bold tracking-widest text-blue-700/70 dark:text-blue-300/70 uppercase">
          <span>AAPKA SALON · {isUrdu ? 'REVIEWS' : 'REVIEWS'}</span>
          <span className="px-2 py-0.5 rounded-md bg-blue-100/80 dark:bg-blue-950/80 text-blue-700 dark:text-blue-300 border border-blue-200/70 dark:border-blue-500/30">
            {reviews.length} {isUrdu ? 'Reviews' : 'Reviews'}
          </span>
        </div>
        <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white mt-1">
          {isUrdu ? 'Salon & Barber Reviews' : 'Salon & Barber Reviews'}
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          {isUrdu
            ? 'Apne barber aur salon ke baare mein rai dein'
            : 'Rate your barber and share your salon experience'}
        </p>
      </div>

      <div className="flex-1 px-5 py-4 space-y-5 overflow-y-auto scrollbar-none">
        {/* Barber Ratings Strip */}
        <div>
          <div className="text-[10px] font-bold text-blue-700/70 dark:text-blue-300/70 uppercase tracking-widest mb-2">
            {isUrdu ? 'BARBER KI RATING' : 'BARBER RATINGS'}
          </div>
          <div className="grid grid-cols-4 gap-2">
            {stylists.map((st) => {
              const stats = getBarberStats(st.id);
              const isSelected = filterStylist === st.id;
              return (
                <motion.button
                  key={st.id}
                  type="button"
                  whileHover={{ rotateX: 4, rotateY: -4, scale: 1.03 }}
                  whileTap={{ scale: 0.96 }}
                  onClick={() =>
                    setFilterStylist(isSelected ? 'all' : st.id)
                  }
                  className={`p-2.5 rounded-2xl border text-center transition-all cursor-pointer backdrop-blur-xl ${
                    isSelected
                      ? 'bg-blue-700 text-white border-blue-600 shadow-lg shadow-blue-700/25'
                      : 'bg-white/80 dark:bg-slate-900/75 border-blue-200/70 dark:border-blue-500/20 text-slate-900 dark:text-slate-100 hover:border-blue-400 dark:hover:border-blue-500/50'
                  }`}
                >
                  <div className="text-xs font-bold truncate">{st.name}</div>
                  <div className="flex items-center justify-center gap-1 mt-1">
                    <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                    <span className="text-xs font-bold font-mono">{stats.avg}</span>
                  </div>
                  <div className="text-[9px] opacity-70 mt-0.5">
                    ({stats.count})
                  </div>
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* Write a Review Form */}
        <motion.form
          onSubmit={handleSubmit}
          whileHover={{ rotateX: 1.5, rotateY: -1.5 }}
          transition={{ type: 'spring', stiffness: 300, damping: 25 }}
          className="p-4 bg-white/80 dark:bg-slate-900/75 backdrop-blur-xl rounded-2xl border border-blue-200/70 dark:border-blue-500/20 shadow-lg shadow-blue-950/5 space-y-3.5"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <MessageSquarePlus className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <span>{isUrdu ? 'Naya Review Likhein' : 'Write a Review'}</span>
            </span>
          </div>

          {/* Select Barber */}
          <div>
            <label className="text-[10px] font-bold text-blue-700/70 dark:text-blue-300/70 uppercase tracking-wider block mb-1.5">
              {isUrdu ? 'BARBER CHUNEIN' : 'SELECT BARBER'}
            </label>
            <div className="grid grid-cols-4 gap-1.5">
              {stylists.map((st) => {
                const active = selectedStylistId === st.id;
                return (
                  <button
                    key={st.id}
                    type="button"
                    onClick={() => setSelectedStylistId(st.id)}
                    className={`py-1.5 px-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                      active
                        ? 'bg-blue-700 text-white border-blue-600 shadow-md shadow-blue-700/20'
                        : 'bg-white/70 dark:bg-slate-950/70 text-slate-600 dark:text-slate-300 border-blue-200/70 dark:border-blue-500/20 hover:border-blue-400'
                    }`}
                  >
                    {st.name}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Dual Star Ratings: Salon & Barber */}
          <div className="grid grid-cols-2 gap-3 pt-1">
            <div className="p-2.5 rounded-xl bg-blue-50/70 dark:bg-slate-950/70 border border-blue-200/60 dark:border-blue-500/20">
              <div className="text-[10px] font-bold text-blue-700/70 dark:text-blue-300/70 uppercase mb-1">
                {isUrdu ? 'Salon Rating' : 'Salon Rating'}
              </div>
              <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map((num) => (
                  <button
                    key={num}
                    type="button"
                    onClick={() => setSalonRating(num)}
                    className="focus:outline-none cursor-pointer"
                  >
                    <Star
                      className={`w-4 h-4 transition-colors ${
                        num <= salonRating
                          ? 'fill-amber-400 text-amber-400'
                          : 'text-slate-300 dark:text-slate-700'
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>

            <div className="p-2.5 rounded-xl bg-blue-50/70 dark:bg-slate-950/70 border border-blue-200/60 dark:border-blue-500/20">
              <div className="text-[10px] font-bold text-blue-700/70 dark:text-blue-300/70 uppercase mb-1">
                {isUrdu ? 'Barber Rating' : 'Barber Rating'}
              </div>
              <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map((num) => (
                  <button
                    key={num}
                    type="button"
                    onClick={() => setBarberRating(num)}
                    className="focus:outline-none cursor-pointer"
                  >
                    <Star
                      className={`w-4 h-4 transition-colors ${
                        num <= barberRating
                          ? 'fill-amber-400 text-amber-400'
                          : 'text-slate-300 dark:text-slate-700'
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Quick Tags */}
          <div className="flex flex-wrap gap-1.5">
            {availableTags.map((tag) => {
              const active = selectedTags.includes(tag);
              return (
                <button
                  key={tag}
                  type="button"
                  onClick={() => toggleTag(tag)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-medium border transition-colors cursor-pointer ${
                    active
                      ? 'bg-blue-700 text-white border-blue-600 shadow-xs'
                      : 'bg-white/60 dark:bg-slate-950/60 text-slate-600 dark:text-slate-300 border-blue-200/70 dark:border-blue-500/20 hover:border-blue-400'
                  }`}
                >
                  {tag}
                </button>
              );
            })}
          </div>

          {/* Name & Comment */}
          <div className="space-y-2">
            <input
              type="text"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              placeholder={isUrdu ? 'Aapka Naam (Optional)' : 'Your Name (Optional)'}
              className="w-full px-3 py-2 rounded-xl bg-white/80 dark:bg-slate-950/80 border border-blue-200/70 dark:border-blue-500/20 text-xs text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-blue-600"
            />
            <textarea
              rows={2}
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder={
                isUrdu
                  ? 'Barber aur salon ke baare mein apna tajurba likhein...'
                  : 'Share your feedback about the haircut and barber...'
              }
              className="w-full px-3 py-2 rounded-xl bg-white/80 dark:bg-slate-950/80 border border-blue-200/70 dark:border-blue-500/20 text-xs text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-blue-600"
            />
          </div>

          <motion.button
            type="submit"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.97 }}
            className="w-full py-2.5 bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs rounded-xl shadow-md shadow-blue-700/25 transition-colors cursor-pointer"
          >
            {isUrdu ? 'Review Jama Karein' : 'Submit Review'}
          </motion.button>

          {submitted && (
            <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs font-semibold flex items-center justify-center gap-1.5">
              <Check className="w-4 h-4" />
              <span>
                {isUrdu ? 'Shukriya! Aapka review shamil ho gaya.' : 'Thank you! Your review has been posted.'}
              </span>
            </div>
          )}
        </motion.form>

        {/* Reviews List */}
        <div className="space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-blue-700/70 dark:text-blue-300/70 uppercase tracking-widest">
              {isUrdu ? 'HALIYA REVIEWS' : 'RECENT REVIEWS'}
            </span>
            {filterStylist !== 'all' && (
              <button
                type="button"
                onClick={() => setFilterStylist('all')}
                className="text-[11px] font-semibold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
              >
                {isUrdu ? 'Sab Dikhaein' : 'Show All'}
              </button>
            )}
          </div>

          {filteredReviews.map((rev) => (
            <motion.div
              key={rev.id}
              whileHover={{ rotateX: 3, rotateY: -3, scale: 1.01 }}
              transition={{ type: 'spring', stiffness: 300, damping: 24 }}
              className="p-3.5 bg-white/80 dark:bg-slate-900/75 backdrop-blur-xl rounded-2xl border border-blue-200/70 dark:border-blue-500/20 shadow-sm space-y-2"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-xs font-bold text-slate-900 dark:text-white">
                    {rev.customerName}
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1.5 mt-0.5">
                    <Award className="w-3 h-3 text-blue-600 dark:text-blue-400" />
                    <span>
                      {isUrdu ? 'Barber:' : 'Barber:'}{' '}
                      <strong className="text-slate-800 dark:text-slate-200">{rev.stylistName}</strong>
                    </span>
                    <span>·</span>
                    <span>{rev.createdAt}</span>
                  </div>
                </div>

                <div className="text-right space-y-0.5">
                  <div className="flex items-center justify-end gap-1 text-[11px] font-bold font-mono">
                    <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                    <span>{rev.barberRating}.0</span>
                  </div>
                  <div className="text-[9px] text-slate-400">
                    Salon: {rev.salonRating}/5
                  </div>
                </div>
              </div>

              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                {rev.comment}
              </p>

              {rev.tags.length > 0 && (
                <div className="flex flex-wrap gap-1 pt-0.5">
                  {rev.tags.map((t) => (
                    <span
                      key={t}
                      className="px-2 py-0.5 rounded-md bg-blue-50 dark:bg-blue-950/70 text-blue-700 dark:text-blue-300 border border-blue-200/60 dark:border-blue-500/20 text-[10px] font-medium"
                    >
                      {t}
                    </span>
                  ))}
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};
