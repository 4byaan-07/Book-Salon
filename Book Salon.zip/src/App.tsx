import React, { useRef, useState } from 'react';
import { SalonProvider, useSalon } from './context/SalonContext';
import { TopNavDemoBar } from './components/navigation/TopNavDemoBar';
import { BottomNavigation } from './components/navigation/BottomNavigation';
import { WhatsAppModal } from './components/modals/WhatsAppModal';
import { BlueprintFlowModal } from './components/modals/BlueprintFlowModal';
import { ThreeDBackground } from './components/ui/ThreeDBackground';

// 13 Screens
import { SlotBookingScreen } from './components/screens/SlotBookingScreen';
import { LiveQueueScreen } from './components/screens/LiveQueueScreen';
import { ReminderScreen } from './components/screens/ReminderScreen';
import { AajKiBookingsScreen } from './components/screens/AajKiBookingsScreen';
import { WalkInEntryScreen } from './components/screens/WalkInEntryScreen';
import { BillingScreen } from './components/screens/BillingScreen';
import { StaffCustomersScreen } from './components/screens/StaffCustomersScreen';
import { CustomerHistoryScreen } from './components/screens/CustomerHistoryScreen';
import { RozKiKamaiScreen } from './components/screens/RozKiKamaiScreen';
import { StaffCommissionScreen } from './components/screens/StaffCommissionScreen';
import { LoginScreen } from './components/screens/LoginScreen';
import { ReviewsScreen } from './components/screens/ReviewsScreen';
import { HaircutTryOnScreen } from './components/screens/HaircutTryOnScreen';

import { Wifi, Battery, Signal } from 'lucide-react';
import { motion, AnimatePresence, useScroll, useMotionValueEvent } from 'motion/react';

const SalonAppContent: React.FC = () => {
  const { activeScreenId, isPhoneFrame, theme } = useSalon();
  const scrollContainerRef = useRef<HTMLDivElement | null>(null);
  const [scrollDirection, setScrollDirection] = useState<'up' | 'down' | 'idle'>('idle');

  const { scrollY, scrollYProgress } = useScroll({
    container: scrollContainerRef,
  });

  useMotionValueEvent(scrollY, 'change', (latest) => {
    const prev = scrollY.getPrevious() ?? 0;
    if (latest > prev + 2) {
      setScrollDirection('down');
    } else if (latest < prev - 2) {
      setScrollDirection('up');
    }
  });

  const renderActiveScreen = () => {
    switch (activeScreenId) {
      case 1:
        return <SlotBookingScreen />;
      case 2:
        return <LiveQueueScreen />;
      case 3:
        return <ReminderScreen />;
      case 4:
        return <AajKiBookingsScreen />;
      case 5:
        return <WalkInEntryScreen />;
      case 6:
        return <BillingScreen />;
      case 7:
        return <StaffCustomersScreen />;
      case 8:
        return <CustomerHistoryScreen />;
      case 9:
        return <RozKiKamaiScreen />;
      case 10:
        return <StaffCommissionScreen />;
      case 12:
        return <ReviewsScreen />;
      case 13:
        return <HaircutTryOnScreen />;
      case 11:
      default:
        return <LoginScreen />;
    }
  };

  const getScreenTime = () => {
    switch (activeScreenId) {
      case 1:
        return '5:12';
      case 2:
        return '6:05';
      case 3:
        return '11:00';
      case 4:
        return '6:40';
      case 5:
        return '6:42';
      case 6:
        return '7:05';
      case 7:
        return '6:35';
      case 8:
        return '6:31';
      case 9:
        return '10:05';
      case 10:
        return '10:08';
      case 11:
      default:
        return '9:30';
    }
  };

  return (
    <div className={`${theme === 'dark' ? 'dark' : ''} min-h-screen flex flex-col font-sans`}>
      <div className="min-h-screen bg-[#E6F1FF] dark:bg-[#0A192F] flex flex-col text-[#0A192F] dark:text-[#E6F1FF] transition-colors relative overflow-hidden">
        {/* 3D Interactive Background with Scroll Up & Scroll Down Animations */}
        <ThreeDBackground
          scrollYProgress={scrollYProgress}
          scrollDirection={scrollDirection}
        />

        {/* Top Demo Controller Bar */}
        <TopNavDemoBar />

        {/* Main Container with 3D Perspective */}
        <main className="flex-1 flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-hidden perspective-1200 relative z-10">
          {isPhoneFrame ? (
            /* Phone Device Frame (3D Glassmorphic iPhone Mockup) */
            <motion.div
              initial={{ opacity: 0, y: 20, rotateX: 6 }}
              animate={{
                opacity: 1,
                y: 0,
                rotateX: scrollDirection === 'down' ? 2.5 : scrollDirection === 'up' ? -2.5 : 0,
              }}
              transition={{ type: 'spring', stiffness: 200, damping: 22 }}
              className="relative w-full max-w-[400px] h-[820px] max-h-[92vh] bg-[#172A45]/95 backdrop-blur-xl rounded-[50px] p-3.5 shadow-[0_25px_70px_-15px_rgba(10,25,47,0.75)] ring-1 ring-[#64FFDA]/35 border-4 border-[#172A45] flex flex-col overflow-hidden preserve-3d"
            >
              {/* Phone Screen Bezel inner */}
              <div className="relative w-full h-full bg-[#E6F1FF]/90 dark:bg-[#0A192F]/90 backdrop-blur-xl rounded-[38px] overflow-hidden flex flex-col transition-colors">
                {/* iPhone Dynamic Island & Status Bar */}
                <div className="h-10 pt-2 px-6 flex items-center justify-between text-xs font-semibold text-[#0A192F] dark:text-[#E6F1FF] z-30 shrink-0 select-none bg-[#E6F1FF]/80 dark:bg-[#0A192F]/80 backdrop-blur-md transition-colors">
                  <span className="font-mono text-[13px] font-bold text-[#0A192F] dark:text-[#64FFDA]">
                    {getScreenTime()}
                  </span>
                  {/* Dynamic Island pill */}
                  <div className="w-24 h-5 bg-[#0A192F] rounded-full flex items-center justify-center border border-[#64FFDA]/25">
                    <div className="w-2 h-2 rounded-full bg-[#172A45] mr-2" />
                    <div className="w-2.5 h-2.5 rounded-full bg-[#172A45] border border-[#64FFDA]/40" />
                  </div>
                  {/* Icons */}
                  <div className="flex items-center gap-1.5 text-[#0A192F] dark:text-[#64FFDA]">
                    <Signal className="w-3.5 h-3.5 stroke-[2.5]" />
                    <Wifi className="w-3.5 h-3.5 stroke-[2.5]" />
                    <Battery className="w-4 h-4 stroke-[2.5]" />
                  </div>
                </div>

                {/* 3D Scroll Progress Indicator Bar */}
                <motion.div
                  style={{ scaleX: scrollYProgress }}
                  className="h-0.5 bg-gradient-to-r from-[#64FFDA] via-[#8892B0] to-[#64FFDA] origin-left z-30 shrink-0"
                />

                {/* Screen Body with 3D AnimatePresence & Scroll Tracking */}
                <div
                  ref={scrollContainerRef}
                  className="flex-1 overflow-y-auto relative scrollbar-none perspective-1200"
                >
                  <AnimatePresence mode="wait">
                    <motion.div
                      key={activeScreenId}
                      initial={{ opacity: 0, rotateY: 14, scale: 0.96 }}
                      animate={{ opacity: 1, rotateY: 0, scale: 1 }}
                      exit={{ opacity: 0, rotateY: -14, scale: 0.96 }}
                      transition={{ type: 'spring', stiffness: 260, damping: 24 }}
                      className="h-full"
                    >
                      {renderActiveScreen()}
                    </motion.div>
                  </AnimatePresence>
                </div>

                {/* Bottom Role-based Tabs */}
                <BottomNavigation />

                {/* iPhone Home Indicator Bar */}
                <div className="absolute bottom-1 left-1/2 -translate-x-1/2 w-32 h-1 bg-[#0A192F]/30 dark:bg-[#64FFDA]/40 rounded-full z-40 pointer-events-none" />
              </div>
            </motion.div>
          ) : (
            /* Full-Width Responsive Glassmorphic Workspace Mode */
            <motion.div
              initial={{ opacity: 0, y: 16, scale: 0.98 }}
              animate={{
                opacity: 1,
                y: 0,
                scale: 1,
                rotateX: scrollDirection === 'down' ? 1.5 : scrollDirection === 'up' ? -1.5 : 0,
              }}
              transition={{ type: 'spring', stiffness: 220, damping: 24 }}
              className="w-full max-w-4xl h-[840px] max-h-[90vh] bg-[#E6F1FF]/85 dark:bg-[#0A192F]/85 backdrop-blur-xl rounded-3xl shadow-[0_25px_70px_-15px_rgba(10,25,47,0.65)] border border-[#172A45]/20 dark:border-[#64FFDA]/25 flex flex-col overflow-hidden relative transition-colors preserve-3d"
            >
              {/* 3D Scroll Progress Indicator Bar */}
              <motion.div
                style={{ scaleX: scrollYProgress }}
                className="h-0.5 bg-gradient-to-r from-[#64FFDA] via-[#8892B0] to-[#64FFDA] origin-left z-30 shrink-0"
              />
              <div
                ref={scrollContainerRef}
                className="flex-1 overflow-y-auto relative scrollbar-thin perspective-1200"
              >
                <AnimatePresence mode="wait">
                  <motion.div
                    key={activeScreenId}
                    initial={{ opacity: 0, rotateY: 10, scale: 0.97 }}
                    animate={{ opacity: 1, rotateY: 0, scale: 1 }}
                    exit={{ opacity: 0, rotateY: -10, scale: 0.97 }}
                    transition={{ type: 'spring', stiffness: 260, damping: 24 }}
                    className="h-full"
                  >
                    {renderActiveScreen()}
                  </motion.div>
                </AnimatePresence>
              </div>
              <BottomNavigation />
            </motion.div>
          )}
        </main>

        {/* Floating Modals */}
        <WhatsAppModal />
        <BlueprintFlowModal />
      </div>
    </div>
  );
};

export default function App() {
  return (
    <SalonProvider>
      <SalonAppContent />
    </SalonProvider>
  );
}
