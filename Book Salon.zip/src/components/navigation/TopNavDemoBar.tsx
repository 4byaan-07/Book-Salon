import React, { useState } from 'react';
import { useSalon } from '../../context/SalonContext';
import { UserRole } from '../../lib/types';
import {
  Smartphone,
  Maximize2,
  Database,
  Layers,
  RotateCcw,
  Languages,
  Download,
  Check,
  Copy,
  ExternalLink,
  FileText,
  X,
  Sun,
  Moon,
} from 'lucide-react';

export const TopNavDemoBar: React.FC = () => {
  const {
    currentRole,
    setCurrentRole,
    activeScreenId,
    setActiveScreenId,
    language,
    setLanguage,
    theme,
    setTheme,
    isPhoneFrame,
    setIsPhoneFrame,
    setShowSchemaModal,
    setShowBlueprintModal,
    resetAllData,
  } = useSalon();

  const [showExportModal, setShowExportModal] = React.useState(false);
  const [isDownloading, setIsDownloading] = React.useState(false);
  const [copiedLink, setCopiedLink] = React.useState(false);

  const isUrdu = language === 'roman_urdu';

  const roles: { id: UserRole; label: string; defaultScreen: number }[] = [
    { id: 'customer', label: isUrdu ? 'Customer' : 'Customer', defaultScreen: 1 },
    { id: 'reception', label: isUrdu ? 'Reception' : 'Reception', defaultScreen: 4 },
    { id: 'staff', label: isUrdu ? 'Staff' : 'Staff', defaultScreen: 7 },
    { id: 'malik', label: isUrdu ? 'Malik' : 'Owner', defaultScreen: 9 },
  ];

  const screens = [
    { id: 1, label: isUrdu ? 'S1: Slot Booking' : 'S1: Slot Booking', role: 'customer' },
    { id: 2, label: isUrdu ? 'S2: Live Queue' : 'S2: Live Queue', role: 'customer' },
    { id: 3, label: isUrdu ? 'S3: Smart Reminder' : 'S3: Smart Reminder', role: 'customer' },
    { id: 4, label: isUrdu ? 'S4: Aaj ki Bookings' : 'S4: Today\'s Bookings', role: 'reception' },
    { id: 5, label: isUrdu ? 'S5: Walk-in Entry' : 'S5: Walk-in Entry', role: 'reception' },
    { id: 6, label: isUrdu ? 'S6: Billing & Payment' : 'S6: Billing & Checkout', role: 'reception' },
    { id: 7, label: isUrdu ? 'S7: Aaj ke Customers' : 'S7: Today\'s Customers', role: 'staff' },
    { id: 8, label: isUrdu ? 'S8: Customer History' : 'S8: History & Notes', role: 'staff' },
    { id: 9, label: isUrdu ? 'S9: Roz ki Kamai' : 'S9: Daily Revenue', role: 'malik' },
    { id: 10, label: isUrdu ? 'S10: Staff Commission' : 'S10: Staff Commission', role: 'malik' },
    { id: 11, label: isUrdu ? 'S11: Login & OTP' : 'S11: Sign In & OTP', role: 'login' },
    { id: 12, label: isUrdu ? 'S12: Reviews aur Rating' : 'S12: Reviews & Ratings', role: 'customer' },
    { id: 13, label: isUrdu ? 'S13: Haircut Try Karein' : 'S13: Haircut Try-On', role: 'customer' },
  ];

  const handleRoleChange = (role: UserRole, defaultScreen: number) => {
    setCurrentRole(role);
    setActiveScreenId(defaultScreen);
  };

  const handleScreenChange = (screenId: number) => {
    const scr = screens.find((s) => s.id === screenId);
    if (scr && scr.role !== 'login') {
      setCurrentRole(scr.role as UserRole);
    }
    setActiveScreenId(screenId);
  };

  const toggleLanguage = () => {
    setLanguage(language === 'english' ? 'roman_urdu' : 'english');
  };

  const getDirectZipUrl = () => {
    if (typeof window !== 'undefined') {
      return `${window.location.origin}/aapka-salon-all-in-one.zip`;
    }
    return '/aapka-salon-all-in-one.zip';
  };

  const handleDownloadBlob = async () => {
    try {
      setIsDownloading(true);
      const res = await fetch('/aapka-salon-all-in-one.zip');
      if (!res.ok) throw new Error('Failed to fetch zip');
      const blob = await res.blob();
      const blobUrl = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = 'aapka-salon-all-in-one.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(blobUrl);
    } catch (e) {
      console.error(e);
      window.open(getDirectZipUrl(), '_blank');
    } finally {
      setIsDownloading(false);
    }
  };

  const handleCopyLink = () => {
    const url = getDirectZipUrl();
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  return (
    <>
      <header className="bg-[#E6F1FF]/85 dark:bg-[#0A192F]/85 backdrop-blur-xl border-b border-[#172A45]/15 dark:border-[#64FFDA]/20 text-[#0A192F] dark:text-[#E6F1FF] px-3 py-2 z-40 select-none shadow-sm transition-colors">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2 text-xs">
        {/* Left: Branding & Tagline */}
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-[#0A192F] dark:bg-[#64FFDA] text-[#64FFDA] dark:text-[#0A192F] flex items-center justify-center font-black text-xs shadow-md shadow-[#64FFDA]/20 border border-[#64FFDA]/40">
            ✂️
          </div>
          <div>
            <div className="font-extrabold text-sm tracking-tight text-[#0A192F] dark:text-[#E6F1FF] flex items-center gap-1.5">
              <span>Aapka Salon</span>
              <span className="text-[10px] bg-[#172A45] text-[#64FFDA] font-bold px-1.5 py-0.2 rounded border border-[#64FFDA]/35">
                13 SCREENS
              </span>
            </div>
            <div className="text-[10px] text-[#172A45]/75 dark:text-[#8892B0] font-medium hidden sm:block">
              {isUrdu
                ? 'Slot booking, live queue, JazzCash / Easypaisa billing aur staff commission'
                : 'Slot booking, live queue, JazzCash / Easypaisa billing & staff commissions'}
            </div>
          </div>
        </div>

        {/* Center: Role Pills & Screen Picker */}
        <div className="flex items-center gap-1.5 bg-[#172A45]/10 dark:bg-[#172A45]/80 backdrop-blur-md p-1 rounded-xl border border-[#172A45]/15 dark:border-[#64FFDA]/20">
          <span className="text-[10px] text-[#172A45] dark:text-[#8892B0] font-bold px-1.5 uppercase hidden md:inline">
            {isUrdu ? 'Role:' : 'Role:'}
          </span>
          {roles.map((r) => {
            const isActive = currentRole === r.id && activeScreenId !== 11;
            return (
              <button
                key={r.id}
                type="button"
                onClick={() => handleRoleChange(r.id, r.defaultScreen)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#0A192F] dark:bg-[#64FFDA] text-[#64FFDA] dark:text-[#0A192F] shadow-md shadow-[#64FFDA]/20'
                    : 'text-[#172A45] dark:text-[#8892B0] hover:text-[#0A192F] dark:hover:text-[#E6F1FF] hover:bg-white/60 dark:hover:bg-[#0A192F]/60'
                }`}
              >
                {r.label}
              </button>
            );
          })}

          <div className="h-4 w-px bg-[#8892B0]/30 mx-1 hidden sm:block" />

          {/* Screen quick select dropdown */}
          <select
            value={activeScreenId}
            onChange={(e) => handleScreenChange(Number(e.target.value))}
            className="bg-white/90 dark:bg-[#0A192F] border border-[#172A45]/20 dark:border-[#64FFDA]/30 text-[#0A192F] dark:text-[#E6F1FF] text-xs font-bold rounded-lg px-2 py-1 focus:outline-none focus:border-[#64FFDA]"
          >
            {screens.map((s) => (
              <option key={s.id} value={s.id}>
                {s.label}
              </option>
            ))}
          </select>
        </div>

        {/* Right: Theme + Language switch + Tools */}
        <div className="flex items-center gap-1.5">
          {/* Theme Toggle: Light vs Dark */}
          <button
            type="button"
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg border bg-zinc-800 hover:bg-zinc-700 border-zinc-700 text-zinc-200 text-xs font-bold transition-all cursor-pointer"
            title="Switch Theme: Light / Dark"
          >
            {theme === 'dark' ? (
              <>
                <Sun className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">Light</span>
              </>
            ) : (
              <>
                <Moon className="w-3.5 h-3.5 text-zinc-300" />
                <span className="hidden sm:inline">Dark</span>
              </>
            )}
          </button>

          {/* Language Toggle: English vs Roman Urdu */}
          <button
            type="button"
            onClick={toggleLanguage}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg border text-xs font-bold transition-all cursor-pointer ${
              isUrdu
                ? 'bg-emerald-950 border-emerald-600 text-emerald-300'
                : 'bg-zinc-800 hover:bg-zinc-700 border-zinc-700 text-zinc-200'
            }`}
            title="Switch Language: English / Roman Urdu"
          >
            <Languages className="w-3.5 h-3.5 text-zinc-400" />
            <span>{isUrdu ? 'Roman Urdu' : 'English'}</span>
          </button>

          {/* Blueprint & Schema Buttons */}
          <button
            type="button"
            onClick={() => setShowBlueprintModal(true)}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-indigo-950/80 hover:bg-indigo-900 border border-indigo-700/60 text-indigo-300 text-xs font-bold transition-colors"
            title="View 11-Screen Flow & Blueprint"
          >
            <Layers className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Blueprint Flow</span>
          </button>

          <button
            type="button"
            onClick={() => setShowSchemaModal(true)}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-purple-950/80 hover:bg-purple-900 border border-purple-700/60 text-purple-300 text-xs font-bold transition-colors"
            title="Inspect Relational DB Schema"
          >
            <Database className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">DB Schema</span>
          </button>

          {/* Frame Toggle */}
          <button
            type="button"
            onClick={() => setIsPhoneFrame(!isPhoneFrame)}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 transition-colors"
            title={isPhoneFrame ? 'Switch to Full-Width View' : 'Switch to iPhone Mobile Frame'}
          >
            {isPhoneFrame ? <Maximize2 className="w-4 h-4" /> : <Smartphone className="w-4 h-4" />}
          </button>

          {/* Download Zip Export */}
          <button
            type="button"
            onClick={() => {
              setShowExportModal(true);
              handleDownloadBlob();
            }}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-sm transition-colors cursor-pointer"
            title="Download All-in-One Project ZIP (with instructions.txt & schema.sql)"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Export Zip</span>
          </button>

          {/* Reset State */}
          <button
            type="button"
            onClick={resetAllData}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 transition-colors"
            title="Reset to default seed data"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </header>

    {/* EXPORT POPUP MODAL */}
    {showExportModal && (
      <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
        <div className="bg-slate-900 border border-slate-800 text-white rounded-3xl p-6 max-w-lg w-full shadow-2xl relative space-y-4">
          <button
            type="button"
            onClick={() => setShowExportModal(false)}
            className="absolute top-4 right-4 p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shrink-0">
              <Download className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white">
                Export All-in-One Application Package
              </h3>
              <p className="text-xs text-slate-400">
                Includes all 11 screens, PostgreSQL schema & instructions.txt
              </p>
            </div>
          </div>

          {/* Direct Download Action Button */}
          <div className="space-y-2">
            <button
              type="button"
              onClick={handleDownloadBlob}
              disabled={isDownloading}
              className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-extrabold text-sm rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-emerald-900/30 transition-all cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>{isDownloading ? 'Preparing Download...' : 'Download aapka-salon-all-in-one.zip'}</span>
            </button>

            <p className="text-[11px] text-slate-400 text-center">
              Size: ~3.0 MB · 41 files embedded
            </p>
          </div>

          {/* Direct Link Copy Box */}
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5">
            <div className="flex items-center justify-between text-[11px] font-bold text-slate-400">
              <span>DIRECT DOWNLOAD URL:</span>
              <button
                type="button"
                onClick={handleCopyLink}
                className="text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1 transition-colors cursor-pointer"
              >
                {copiedLink ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copiedLink ? 'Copied URL!' : 'Copy Link'}</span>
              </button>
            </div>
            <input
              type="text"
              readOnly
              value={getDirectZipUrl()}
              className="w-full bg-slate-900 border border-slate-700 text-slate-300 text-xs font-mono p-2 rounded-lg select-all focus:outline-none"
            />
            <p className="text-[10px] text-slate-500 leading-tight">
              Tip: If downloading is blocked inside the preview iframe, copy this URL and paste it directly into a new browser tab or download manager.
            </p>
          </div>

          {/* View Documentation & Schema */}
          <div className="grid grid-cols-2 gap-2 pt-1 text-xs">
            <a
              href="/instructions.txt"
              target="_blank"
              rel="noreferrer"
              className="p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700 flex items-center justify-between text-slate-300 hover:text-white transition-colors"
            >
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-purple-400" />
                <span className="font-semibold text-xs">instructions.txt</span>
              </div>
              <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
            </a>

            <a
              href="/salon_database_schema.sql"
              target="_blank"
              rel="noreferrer"
              className="p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700 flex items-center justify-between text-slate-300 hover:text-white transition-colors"
            >
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-blue-400" />
                <span className="font-semibold text-xs">schema.sql</span>
              </div>
              <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
            </a>
          </div>
        </div>
      </div>
    )}
  </>
  );
};
