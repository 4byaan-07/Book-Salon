import React, { useState } from 'react';
import { useSalon } from '../../context/SalonContext';
import { computeDailyMetrics, formatCurrency } from '../../lib/calculations';
import { Download } from 'lucide-react';

export const RozKiKamaiScreen: React.FC = () => {
  const { bookings, language } = useSalon();
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);
  const isUrdu = language === 'roman_urdu';

  const metrics = computeDailyMetrics(bookings);

  const displayTotalRevenue = Math.max(14600, metrics.totalRevenue);
  const displayCash = Math.max(4200, metrics.cashAmount);
  const displayJazzCash = Math.max(6200, metrics.jazzcashAmount || 6200);
  const displayEasypaisa = Math.max(4200, metrics.easypaisaAmount || 4200);
  const displayCustomers = Math.max(40, metrics.totalCustomers);
  const displayBooking = Math.max(24, metrics.bookingCount);
  const displayWalkin = Math.max(16, metrics.walkinCount);

  const serviceWise = [
    { name: isUrdu ? 'Haircut' : 'Haircut', amount: 5200, percentage: 35 },
    { name: isUrdu ? 'Hair Colour' : 'Hair colour', amount: 4200, percentage: 29 },
    { name: isUrdu ? 'Facial' : 'Facial', amount: 3600, percentage: 25 },
    { name: isUrdu ? 'Beard Setting' : 'Beard', amount: 1600, percentage: 11 },
  ];

  const handleDownloadReport = () => {
    const reportData = `Aapka Salon - Daily Revenue Report\nDate: Sun, Nov 2, 2026\nTotal Revenue: ${formatCurrency(displayTotalRevenue)}\nCash: ${formatCurrency(displayCash)}\nJazzCash: ${formatCurrency(displayJazzCash)}\nEasypaisa: ${formatCurrency(displayEasypaisa)}\nTotal Customers: ${displayCustomers} (Bookings: ${displayBooking}, Walk-ins: ${displayWalkin})\n\nService Breakdown:\n` +
      serviceWise.map((s) => `${s.name}: ${formatCurrency(s.amount)} (${s.percentage}%)`).join('\n');

    const blob = new Blob([reportData], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Aapka_Salon_Revenue_Report_${new Date().toISOString().slice(0, 10)}.txt`;
    a.click();
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 text-slate-900 pb-28">
      {/* Top Header */}
      <div className="pt-2 px-5 pb-2">
        <div className="flex items-center justify-between text-[11px] font-bold tracking-wider text-purple-700 uppercase">
          <span>AAPKA SALON · {isUrdu ? 'MALIK (OWNER)' : 'OWNER'}</span>
          <span className="px-2 py-0.5 rounded bg-purple-100 text-purple-800 text-[10px]">DEMO</span>
        </div>
        <div className="flex items-center justify-between mt-1">
          <div>
            <h1 className="text-2xl font-extrabold text-slate-900">
              {isUrdu ? 'Roz ki Kamai' : 'Daily Revenue'}
            </h1>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              {isUrdu ? 'Aaj · Salon band hone ke baad ka hisaab' : 'Today · End of day register closing'}
            </p>
          </div>
          <button
            type="button"
            onClick={handleDownloadReport}
            className="flex items-center gap-1 px-2.5 py-1.5 bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 rounded-xl text-xs font-bold transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isUrdu ? 'Report' : 'Report'}</span>
          </button>
        </div>
      </div>

      <div className="flex-1 px-5 space-y-3.5 overflow-y-auto">
        {/* TODAY'S REVENUE Hero Box */}
        <div className="p-5 rounded-3xl bg-gradient-to-br from-purple-700 via-indigo-700 to-pink-600 text-white shadow-lg shadow-purple-600/25 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-purple-200 uppercase tracking-wider">
              {isUrdu ? 'AAJ KI KUL KAMAI' : "TODAY'S REVENUE"}
            </span>
            <span className="px-2.5 py-0.5 bg-white/20 backdrop-blur-md rounded-full text-[10px] font-extrabold text-white">
              {displayCustomers} {isUrdu ? 'customers' : 'customers'}
            </span>
          </div>

          <div className="text-4xl font-black tracking-tight leading-none">
            {formatCurrency(displayTotalRevenue)}
          </div>

          {/* Payment Split across Cash, JazzCash & Easypaisa */}
          <div className="pt-2 border-t border-white/20 text-xs font-semibold text-purple-100 flex flex-wrap items-center justify-between gap-1">
            <span>Cash: {formatCurrency(displayCash)}</span>
            <span>·</span>
            <span className="text-amber-200">JazzCash: {formatCurrency(displayJazzCash)}</span>
            <span>·</span>
            <span className="text-emerald-200">Easypaisa: {formatCurrency(displayEasypaisa)}</span>
          </div>
        </div>

        {/* Triple Split Numbers Box */}
        <div className="grid grid-cols-3 gap-2">
          <div className="p-3 bg-white rounded-2xl border border-slate-200 text-center shadow-xs">
            <div className="text-xl font-black text-slate-900">{displayCustomers}</div>
            <div className="text-[10px] font-bold text-slate-400 uppercase mt-0.5">
              {isUrdu ? 'Customers' : 'Customers'}
            </div>
          </div>
          <div className="p-3 bg-white rounded-2xl border border-slate-200 text-center shadow-xs">
            <div className="text-xl font-black text-purple-700">{displayBooking}</div>
            <div className="text-[10px] font-bold text-slate-400 uppercase mt-0.5">
              {isUrdu ? 'Bookings' : 'Bookings'}
            </div>
          </div>
          <div className="p-3 bg-white rounded-2xl border border-slate-200 text-center shadow-xs">
            <div className="text-xl font-black text-blue-700">{displayWalkin}</div>
            <div className="text-[10px] font-bold text-slate-400 uppercase mt-0.5">
              {isUrdu ? 'Walk-ins' : 'Walk-ins'}
            </div>
          </div>
        </div>

        {/* Service wise section */}
        <div className="p-4 bg-white rounded-3xl border border-slate-200 shadow-sm space-y-3">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            {isUrdu ? 'SERVICES KE HISAAB SE KAMAI' : 'SERVICE BREAKDOWN'}
          </div>

          <div className="space-y-3">
            {serviceWise.map((item) => (
              <div key={item.name} className="space-y-1">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-slate-800">{item.name}</span>
                  <span className="font-mono text-slate-900">{formatCurrency(item.amount)}</span>
                </div>
                <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full transition-all duration-500"
                    style={{ width: `${item.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* This Week Weekly Chart */}
        <div className="p-4 bg-white rounded-3xl border border-slate-200 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              {isUrdu ? 'IS HAFTE KI KAMAI' : 'THIS WEEK'}
            </span>
            <span className="text-[11px] text-purple-700 font-bold">
              {isUrdu ? 'Itwar ko sabse zyada' : 'Peak Revenue on Sunday'}
            </span>
          </div>

          <div className="h-28 flex items-end justify-between gap-2 pt-4 px-1">
            {metrics.weeklyRevenue.map((col, idx) => {
              const maxAmount = 18000;
              const heightPercent = Math.min(100, Math.round((col.amount / maxAmount) * 100));
              const isHighlight = col.isSunday;

              return (
                <div key={idx} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end">
                  <div className="w-full flex justify-center items-end flex-1">
                    <div
                      className={`w-full max-w-[24px] rounded-t-lg transition-all duration-300 ${
                        isHighlight
                          ? 'bg-gradient-to-t from-pink-500 to-purple-600 shadow-sm shadow-purple-500/30'
                          : 'bg-slate-200 hover:bg-slate-300'
                      }`}
                      style={{ height: `${heightPercent}%` }}
                      title={`${col.fullDay}: ${formatCurrency(col.amount)}`}
                    />
                  </div>
                  <span
                    className={`text-[10px] font-bold ${
                      isHighlight ? 'text-purple-700 font-black' : 'text-slate-400'
                    }`}
                  >
                    {col.day}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {downloadSuccess && (
          <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200 text-xs text-emerald-800 text-center font-bold">
            ✓ {isUrdu ? 'Report download ho chuki hai!' : 'Report downloaded successfully!'}
          </div>
        )}
      </div>
    </div>
  );
};
