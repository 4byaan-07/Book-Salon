import React from 'react';
import { motion, MotionValue, useTransform, useSpring } from 'motion/react';

interface ThreeDBackgroundProps {
  scrollYProgress: MotionValue<number>;
  scrollDirection: 'up' | 'down' | 'idle';
}

export const ThreeDBackground: React.FC<ThreeDBackgroundProps> = ({
  scrollYProgress,
  scrollDirection,
}) => {
  const smoothProgress = useSpring(scrollYProgress, {
    stiffness: 120,
    damping: 22,
    mass: 0.5,
  });

  // 3D Grid transforms driven by scroll up & scroll down
  const gridRotateX = useTransform(smoothProgress, [0, 1], [68, 54]);
  const gridTranslateY = useTransform(smoothProgress, [0, 1], [0, -140]);
  const gridScale = useTransform(smoothProgress, [0, 1], [1.15, 1.35]);

  // Floating 3D Cube 1 (Top-Left)
  const cube1Y = useTransform(smoothProgress, [0, 1], [0, -120]);
  const cube1RotateX = useTransform(smoothProgress, [0, 1], [18, 198]);
  const cube1RotateY = useTransform(smoothProgress, [0, 1], [24, 204]);

  // Floating 3D Cube 2 (Bottom-Right)
  const cube2Y = useTransform(smoothProgress, [0, 1], [0, 110]);
  const cube2RotateX = useTransform(smoothProgress, [0, 1], [-20, -200]);
  const cube2RotateY = useTransform(smoothProgress, [0, 1], [35, -145]);

  // Floating 3D Ring (Center-Right)
  const ringY = useTransform(smoothProgress, [0, 1], [-30, 90]);
  const ringRotateZ = useTransform(smoothProgress, [0, 1], [0, 180]);

  const directionTilt =
    scrollDirection === 'down' ? -4 : scrollDirection === 'up' ? 4 : 0;

  return (
    <div className="pointer-events-none fixed inset-0 overflow-hidden z-0 perspective-900">
      {/* Ambient #64FFDA & #172A45 Depth Glow Orbs */}
      <motion.div
        animate={{
          scale: scrollDirection === 'down' ? 1.08 : scrollDirection === 'up' ? 0.94 : 1,
        }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
        className="absolute -top-32 -left-24 w-[28rem] h-[28rem] rounded-full bg-[#64FFDA]/12 dark:bg-[#64FFDA]/10 blur-3xl"
      />
      <div className="absolute top-1/3 -right-32 w-[32rem] h-[32rem] rounded-full bg-[#172A45]/25 dark:bg-[#172A45]/70 blur-3xl" />
      <div className="absolute -bottom-36 left-1/4 w-[26rem] h-[26rem] rounded-full bg-[#64FFDA]/10 dark:bg-[#64FFDA]/8 blur-3xl" />

      {/* 3D Perspective Architectural Grid Floor */}
      <motion.div
        style={{
          rotateX: gridRotateX,
          y: gridTranslateY,
          scale: gridScale,
        }}
        animate={{ rotateZ: directionTilt * 0.5 }}
        transition={{ type: 'spring', stiffness: 140, damping: 20 }}
        className="
          absolute inset-x-[-25%] bottom-[-35%] h-[85%]
          bg-3d-grid opacity-45 dark:opacity-35
          [mask-image:linear-gradient(to_top,rgba(0,0,0,0.9)_10%,transparent_85%)]
        "
      />

      {/* Floating 3D Glassmorphic Cube 1 (Top Left) */}
      <motion.div
        style={{
          y: cube1Y,
          rotateX: cube1RotateX,
          rotateY: cube1RotateY,
        }}
        className="hidden sm:block absolute top-24 left-[8%] w-20 h-20 preserve-3d"
      >
        <div className="absolute inset-0 rounded-2xl bg-[#172A45]/40 border border-[#64FFDA]/35 backdrop-blur-md shadow-[0_0_25px_rgba(100,255,218,0.15)] translate-z-10" />
        <div className="absolute inset-0 rounded-2xl bg-[#172A45]/25 border border-[#64FFDA]/20 -translate-z-10" />
      </motion.div>

      {/* Floating 3D Glassmorphic Cube 2 (Bottom Right) */}
      <motion.div
        style={{
          y: cube2Y,
          rotateX: cube2RotateX,
          rotateY: cube2RotateY,
        }}
        className="hidden sm:block absolute bottom-24 right-[8%] w-24 h-24 preserve-3d"
      >
        <div className="absolute inset-0 rounded-3xl bg-[#172A45]/45 border border-[#64FFDA]/30 backdrop-blur-md shadow-[0_0_30px_rgba(100,255,218,0.12)] translate-z-12" />
        <div className="absolute inset-2 rounded-2xl border border-[#8892B0]/30 -translate-z-12" />
      </motion.div>

      {/* Floating 3D Orbital Ring (Mid Right) */}
      <motion.div
        style={{
          y: ringY,
          rotateZ: ringRotateZ,
        }}
        className="hidden md:flex items-center justify-center absolute top-1/2 right-[14%] w-32 h-32 rounded-full border-2 border-dashed border-[#64FFDA]/25 preserve-3d"
      >
        <div className="w-20 h-20 rounded-full border border-[#8892B0]/30 bg-[#172A45]/30 backdrop-blur-sm" />
      </motion.div>
    </div>
  );
};
