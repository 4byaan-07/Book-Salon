import React, { useState } from 'react';
import { useSalon } from '../../context/SalonContext';
import { CheckCheck, Copy, ExternalLink, X, Send } from 'lucide-react';

export const WhatsAppModal: React.FC = () => {
  const { whatsappSim, closeWhatsAppModal } = useSalon();
  const [copied, setCopied] = useState(false);

  if (!whatsappSim.isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(whatsappSim.messageText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleOpenRealWhatsApp = () => {
    const cleanPhone = whatsappSim.recipientPhone.replace(/\D/g, '');
    const encoded = encodeURIComponent(whatsappSim.messageText);
    window.open(`https://wa.me/${cleanPhone}?text=${encoded}`, '_blank');
  };

  const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#0b141a] text-slate-100 rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl border border-slate-700 animate-in fade-in zoom-in-95 duration-150">
        {/* WhatsApp Top Bar */}
        <div className="bg-[#202c33] px-4 py-3 flex items-center justify-between border-b border-slate-700">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-emerald-600 text-white font-bold text-sm flex items-center justify-center">
              ✂️
            </div>
            <div>
              <div className="font-bold text-xs text-slate-100 flex items-center gap-1.5">
                <span>Aapka Salon</span>
                <span className="text-[10px] bg-emerald-950 text-emerald-400 px-1.5 py-0.2 rounded font-semibold">
                  Official
                </span>
              </div>
              <div className="text-[10px] text-slate-400">
                To: {whatsappSim.recipientName} ({whatsappSim.recipientPhone})
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={closeWhatsAppModal}
            className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-700"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* WhatsApp Chat Body with iconic wallpaper feel */}
        <div className="p-4 bg-[#0b141a] min-h-[220px] max-h-[340px] overflow-y-auto space-y-3">
          <div className="text-center">
            <span className="bg-[#182229] text-[10px] font-medium text-slate-400 px-2.5 py-1 rounded-md shadow-xs">
              TODAY · AUTOMATED DISPATCH
            </span>
          </div>

          {/* Green chat bubble */}
          <div className="bg-[#005c4b] text-white p-3 rounded-2xl rounded-tr-none text-xs leading-relaxed max-w-[92%] ml-auto shadow-md space-y-1">
            <div className="whitespace-pre-line font-normal">{whatsappSim.messageText}</div>
            <div className="flex items-center justify-end gap-1 text-[9px] text-emerald-200/80 pt-1">
              <span>{currentTime}</span>
              <CheckCheck className="w-3.5 h-3.5 text-[#53bdeb]" />
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="bg-[#202c33] p-3 border-t border-slate-700 flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={handleCopy}
            className="flex-1 py-2 px-3 bg-slate-700/60 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 transition-colors"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>{copied ? 'Copied!' : 'Copy Text'}</span>
          </button>

          <button
            type="button"
            onClick={handleOpenRealWhatsApp}
            className="flex-1 py-2 px-3 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 shadow transition-colors"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Open in WhatsApp</span>
          </button>
        </div>
      </div>
    </div>
  );
};
