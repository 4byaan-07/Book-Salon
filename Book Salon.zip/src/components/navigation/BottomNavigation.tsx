import React from 'react';
import { useSalon } from '../../context/SalonContext';
import {
  Calendar,
  Clock,
  Users,
  CreditCard,
  DollarSign,
  History,
  Settings,
  PlusCircle,
  Bell,
  Star,
  Sparkles,
} from 'lucide-react';
import { motion } from 'motion/react';

export const BottomNavigation: React.FC = () => {
  const {
    currentRole,
    activeScreenId,
    setActiveScreenId,
    setShowSchemaModal,
    language,
  } = useSalon();

  const isUrdu = language === 'roman_urdu';

  // If on login screen (11), do not show bottom tabs
  if (activeScreenId === 11) return null;

  const navClass =
    'absolute bottom-0 left-0 right-0 bg-[#E6F1FF]/85 dark:bg-[#172A45]/85 backdrop-blur-xl border-t border-[#172A45]/15 dark:border-[#64FFDA]/20 py-2 px-3 flex items-center justify-around z-30 shadow-lg shadow-[#0A192F]/20 transition-colors';

  // Render navigation based on current role
  if (currentRole === 'customer') {
    const tabs = [
      { id: 1, label: isUrdu ? 'Booking' : 'Booking', icon: Calendar, screen: 1 },
      { id: 2, label: isUrdu ? 'Live Line' : 'Queue', icon: Clock, screen: 2 },
      { id: 13, label: isUrdu ? 'Style Try' : 'Try-On', icon: Sparkles, screen: 13 },
      { id: 12, label: isUrdu ? 'Reviews' : 'Reviews', icon: Star, screen: 12 },
      { id: 3, label: isUrdu ? 'Yaad Dehani' : 'Reminder', icon: Bell, screen: 3 },
    ];

    return (
      <div className={navClass}>
        {tabs.map((tab, idx) => {
          const isActive = activeScreenId === tab.screen;
          const Icon = tab.icon;
          return (
            <motion.button
              key={idx}
              type="button"
              whileHover={{ y: -2, scale: 1.05 }}
              whileTap={{ scale: 0.92 }}
              onClick={() => setActiveScreenId(tab.screen)}
              className={`flex flex-col items-center gap-0.5 transition-colors cursor-pointer ${
                isActive
                  ? 'text-[#0A192F] dark:text-[#64FFDA] font-bold'
                  : 'text-[#8892B0] hover:text-[#0A192F] dark:hover:text-[#E6F1FF]'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="text-[10px] font-semibold">{tab.label}</span>
            </motion.button>
          );
        })}
      </div>
    );
  }

  if (currentRole === 'reception') {
    const tabs = [
      { id: 4, label: isUrdu ? 'Aaj Ki Bookings' : 'Bookings', icon: Calendar, screen: 4 },
      { id: 5, label: isUrdu ? 'Walk-in Line' : 'Walk-in', icon: PlusCircle, screen: 5 },
      { id: 6, label: isUrdu ? 'Bill Banayein' : 'Billing', icon: CreditCard, screen: 6 },
      { id: 'more', label: isUrdu ? 'DB Schema' : 'Schema', icon: Settings, action: () => setShowSchemaModal(true) },
    ];

    return (
      <div className={navClass}>
        {tabs.map((tab, idx) => {
          const isActive = tab.screen ? activeScreenId === tab.screen : false;
          const Icon = tab.icon;
          return (
            <motion.button
              key={idx}
              type="button"
              whileHover={{ y: -2, scale: 1.05 }}
              whileTap={{ scale: 0.92 }}
              onClick={() => {
                if (tab.screen) setActiveScreenId(tab.screen);
                if (tab.action) tab.action();
              }}
              className={`flex flex-col items-center gap-0.5 transition-colors cursor-pointer ${
                isActive
                  ? 'text-blue-700 dark:text-blue-400 font-bold'
                  : 'text-slate-400 dark:text-slate-500 hover:text-blue-600 dark:hover:text-blue-300'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-[10px] font-semibold">{tab.label}</span>
            </motion.button>
          );
        })}
      </div>
    );
  }

  if (currentRole === 'staff') {
    const tabs = [
      { id: 7, label: isUrdu ? 'Customers' : 'Customers', icon: Users, screen: 7 },
      { id: 8, label: isUrdu ? 'Pichla Record' : 'History', icon: History, screen: 8 },
      { id: 10, label: isUrdu ? 'Commission' : 'Earnings', icon: DollarSign, screen: 10 },
      { id: 'profile', label: isUrdu ? 'DB Schema' : 'Schema', icon: Settings, action: () => setShowSchemaModal(true) },
    ];

    return (
      <div className={navClass}>
        {tabs.map((tab, idx) => {
          const isActive = tab.screen ? activeScreenId === tab.screen : false;
          const Icon = tab.icon;
          return (
            <motion.button
              key={idx}
              type="button"
              whileHover={{ y: -2, scale: 1.05 }}
              whileTap={{ scale: 0.92 }}
              onClick={() => {
                if (tab.screen) setActiveScreenId(tab.screen);
                if (tab.action) tab.action();
              }}
              className={`flex flex-col items-center gap-0.5 transition-colors cursor-pointer ${
                isActive
                  ? 'text-blue-700 dark:text-blue-400 font-bold'
                  : 'text-slate-400 dark:text-slate-500 hover:text-blue-600 dark:hover:text-blue-300'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-[10px] font-semibold">{tab.label}</span>
            </motion.button>
          );
        })}
      </div>
    );
  }

  // Owner (Malik) role
  const tabs = [
    { id: 9, label: isUrdu ? 'Roz Ki Kamai' : 'Revenue', icon: DollarSign, screen: 9 },
    { id: 10, label: isUrdu ? 'Staff Commission' : 'Staff', icon: Users, screen: 10 },
    { id: 8, label: isUrdu ? 'Customer Record' : 'History', icon: History, screen: 8 },
    { id: 'schema', label: isUrdu ? 'DB Schema' : 'Schema', icon: Settings, action: () => setShowSchemaModal(true) },
  ];

  return (
    <div className={navClass}>
      {tabs.map((tab, idx) => {
        const isActive = tab.screen ? activeScreenId === tab.screen : false;
        const Icon = tab.icon;
        return (
          <motion.button
            key={idx}
            type="button"
            whileHover={{ y: -2, scale: 1.05 }}
            whileTap={{ scale: 0.92 }}
            onClick={() => {
              if (tab.screen) setActiveScreenId(tab.screen);
              if (tab.action) tab.action();
            }}
            className={`flex flex-col items-center gap-0.5 transition-colors cursor-pointer ${
              isActive
                ? 'text-blue-700 dark:text-blue-400 font-bold'
                : 'text-slate-400 dark:text-slate-500 hover:text-blue-600 dark:hover:text-blue-300'
            }`}
          >
            <Icon className="w-5 h-5" />
            <span className="text-[10px] font-semibold">{tab.label}</span>
          </motion.button>
        );
      })}
    </div>
  );
};
