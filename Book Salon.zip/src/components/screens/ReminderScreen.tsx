import React, { useState } from 'react';
import { useSalon } from '../../context/SalonContext';
import { Check, Calendar, Clock, Scissors, Sparkles, MessageCircle } from 'lucide-react';
import { formatCurrency } from '../../lib/calculations';

export const ReminderScreen: React.FC = () => {
  const { createSlotBooking, setActiveScreenId, triggerWhatsAppSim, language } = useSalon();
  const isUrdu = language === 'roman_urdu';

  const [selectedQuickSlot, setSelectedQuickSlot] = useState<string>('Tomorrow 6:30 PM');
  const [keepSameStylist, setKeepSameStylist] = useState<boolean>(true);
  const [keepSameCut, setKeepSameCut] = useState<boolean>(true);
  const [isBooked, setIsBooked] = useState<boolean>(false);

  const quickSlots = [
    {
      id: 'q1',
      label: isUrdu ? 'Kal Shaam 6:30' : 'Tomorrow 6:30 PM',
      key: 'Tomorrow 6:30 PM',
      time: '6:30 PM',
      date: 'Mon, Nov 3',
    },
    {
      id: 'q2',
      label: isUrdu ? 'Hafta Subah 11' : 'Sat 11 AM',
      key: 'Sat 11 AM',
      time: '11:00 AM',
      date: 'Sat, Nov 8',
    },
    {
      id: 'q3',
      label: isUrdu ? 'Itwar Shaam 5' : 'Sun 5 PM',
      key: 'Sun 5 PM',
      time: '5:00 PM',
      date: 'Sun, Nov 9',
    },
  ];

  const handleOneTapBook = () => {
    const slot = quickSlots.find((s) => s.key === selectedQuickSlot || s.label === selectedQuickSlot) || quickSlots[0];
    createSlotBooking({
      customerName: 'Hamza Khan',
      customerPhone: '+92 300 9872210',
      stylistId: keepSameStylist ? 'raju' : 'raju',
      serviceIds: ['s1', 's2'], // Fade cut + Beard
      date: slot.date,
      slotTime: slot.time,
    });
    setIsBooked(true);
  };

  const handleTestWhatsAppNotification = () => {
    const waText = isUrdu
      ? `✂️ *Aapka Salon - Haircut Reminder*\n\nAssalam-o-Alaikum Hamza Khan! Pichle haircut ko *30 din* ho chuke hain. ✂️\nKya aap is hafte slot book karna chahte hain? Raju stylist dastiyab hai.\n\n1-tap mein book karein: https://aapkasalon.app/book?c=c1`
      : `✂️ *Aapka Salon - Haircut Reminder*\n\nHello Hamza Khan! It has been *30 days* since your last haircut. ✂️\nWould you like to book a slot this week? Raju is available.\n\nBook in 1-tap: https://aapkasalon.app/book?c=c1`;

    triggerWhatsAppSim(
      'reminder',
      'Hamza Khan',
      '+92 300 9872210',
      waText
    );
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 text-slate-900 pb-28">
      {/* Top Header */}
      <div className="pt-2 px-5 pb-2">
        <div className="flex items-center justify-between text-[11px] font-bold tracking-wider text-purple-700 uppercase">
          <span>{isUrdu ? 'AAPKA SALON · GRAHAK / CUSTOMER' : 'AAPKA SALON · CUSTOMER'}</span>
          <span className="px-2 py-0.5 rounded bg-purple-100 text-purple-800 text-[10px]">DEMO</span>
        </div>
        <div className="flex items-center justify-between mt-1">
          <div>
            <h1 className="text-2xl font-extrabold text-slate-900">
              {isUrdu ? 'Smart Yaad Dehani' : 'Smart Reminder'}
            </h1>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              {isUrdu
                ? 'Baal katwane ka waqt ho gaya? App khud bakhud yaad karwata hai'
                : 'Due for a haircut? The app automatically reminds you'}
            </p>
          </div>
          <button
            type="button"
            onClick={handleTestWhatsAppNotification}
            className="flex items-center gap-1 px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-lg text-[10px] font-bold transition-colors"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>{isUrdu ? 'WA Message' : 'WA Alert'}</span>
          </button>
        </div>
      </div>

      <div className="flex-1 px-5 space-y-4 overflow-y-auto">
        {/* iOS-like Notification Banner */}
        <div className="p-3.5 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-[11px] text-slate-400 font-bold uppercase tracking-wider">
            <span className="text-purple-700 font-extrabold">AAPKA SALON</span>
            <span className="text-slate-400 font-normal">{isUrdu ? 'Abhi abhi' : 'Just now'}</span>
          </div>
          <div className="text-xs font-semibold text-slate-800 leading-snug">
            {isUrdu
              ? 'Hamza, pichle haircut ko 30 din ho gaye hain ✂️'
              : "Hamza, it's been 30 days since your last haircut ✂️"}
            <br />
            <span className="text-slate-600 font-normal">
              {isUrdu
                ? 'Kya is hafte slot book karna chahte hain? Raju free hai.'
                : 'Would you like to book a slot this week? Raju is free.'}
            </span>
          </div>
        </div>

        {/* Previous Visit Details Card */}
        <div className="p-4 bg-white rounded-3xl border border-purple-100 shadow-sm flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-pink-500 to-purple-600 text-white flex flex-col items-center justify-center shrink-0 shadow-md">
            <span className="text-xl font-black leading-none">30</span>
            <span className="text-[10px] font-bold uppercase tracking-wider mt-0.5">
              {isUrdu ? 'DIN' : 'DAYS'}
            </span>
          </div>

          <div className="min-w-0 flex-1">
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              {isUrdu ? 'PICHLA VISIT · 2 OCT' : 'LAST VISIT · OCT 2'}
            </div>
            <div className="text-base font-extrabold text-slate-900 truncate">
              {isUrdu ? 'Fade cut + Khat (Beard)' : 'Fade cut + Beard'}
            </div>
            <div className="text-xs text-purple-700 font-bold mt-0.5">
              Raju · {formatCurrency(300)}
            </div>
          </div>
        </div>

        {/* QUICK SLOTS section */}
        <div>
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
            {isUrdu ? 'JALDI KE INSTANT SLOTS' : 'QUICK INSTANT SLOTS'}
          </div>
          <div className="grid grid-cols-3 gap-2">
            {quickSlots.map((qs) => {
              const isSelected = selectedQuickSlot === qs.key || selectedQuickSlot === qs.label;
              return (
                <button
                  key={qs.id}
                  type="button"
                  onClick={() => setSelectedQuickSlot(qs.key)}
                  className={`py-2.5 px-2 rounded-xl text-center font-bold text-xs transition-all ${
                    isSelected
                      ? 'bg-purple-600 text-white shadow-md ring-2 ring-purple-300'
                      : 'bg-white border border-slate-200 text-slate-700 hover:border-slate-300'
                  }`}
                >
                  {qs.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Preferences Matchers */}
        <div className="bg-white rounded-2xl border border-slate-200 p-3 space-y-2.5">
          {/* Stylist */}
          <button
            type="button"
            onClick={() => setKeepSameStylist(!keepSameStylist)}
            className="w-full flex items-center justify-between text-left p-1 text-xs"
          >
            <div className="flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-purple-600 text-white font-bold text-[10px] flex items-center justify-center">
                R
              </span>
              <span className="font-semibold text-slate-800">
                {isUrdu ? 'Wahi Stylist: Raju' : 'Same Stylist: Raju'}
              </span>
            </div>
            <div
              className={`w-5 h-5 rounded-md flex items-center justify-center transition-colors ${
                keepSameStylist ? 'bg-emerald-500 text-white' : 'border border-slate-300 text-transparent'
              }`}
            >
              <Check className="w-3.5 h-3.5 stroke-[3]" />
            </div>
          </button>

          <div className="border-t border-slate-100" />

          {/* Haircut Style */}
          <button
            type="button"
            onClick={() => setKeepSameCut(!keepSameCut)}
            className="w-full flex items-center justify-between text-left p-1 text-xs"
          >
            <div className="flex items-center gap-2">
              <Scissors className="w-4 h-4 text-purple-600" />
              <span className="font-semibold text-slate-800">
                {isUrdu ? 'Wahi Style: Fade, sides pe #2' : 'Same Cut: Fade, #2 on sides'}
              </span>
            </div>
            <div
              className={`w-5 h-5 rounded-md flex items-center justify-center transition-colors ${
                keepSameCut ? 'bg-emerald-500 text-white' : 'border border-slate-300 text-transparent'
              }`}
            >
              <Check className="w-3.5 h-3.5 stroke-[3]" />
            </div>
          </button>
        </div>

        {/* Big Action: 1-Tap Booking */}
        <button
          type="button"
          onClick={handleOneTapBook}
          className="w-full py-3.5 bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-700 hover:opacity-95 text-white font-extrabold text-sm rounded-2xl shadow-lg shadow-purple-600/30 flex items-center justify-center gap-2 transition-transform active:scale-[0.99]"
        >
          <span>{isUrdu ? '1-Tap Mein Book Karein' : 'Book with 1-Tap'}</span>
          <span>→</span>
        </button>

        {/* Explanatory callout for blueprint */}
        <div className="p-3 bg-purple-50 rounded-xl border border-purple-100 text-purple-900 text-[11px] leading-relaxed">
          💡 <strong>{isUrdu ? 'Ye kaise kaam karta hai:' : 'How it works:'}</strong>{' '}
          {isUrdu
            ? 'Customer aksar apne grooming cycle bhool jaate hain. System frequency detect karke pichle stylist aur haircut style ke sath sirf ek click mein booking link bhejta hai!'
            : 'Salon customers often lose track of their grooming cycle. The system detects their visit frequency and triggers a seamless 1-tap re-booking with their preferred stylist and past haircut specifications!'}
        </div>
      </div>

      {/* Booked Confirmation Popup */}
      {isBooked && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-xs w-full text-center shadow-2xl">
            <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-3">
              <Check className="w-7 h-7 stroke-[3]" />
            </div>
            <div className="text-base font-extrabold text-slate-900">
              {isUrdu ? '1-Tap Booking Ho Gayi!' : '1-Tap Booking Confirmed!'}
            </div>
            <p className="text-xs text-slate-600 mt-1 mb-4">
              Hamza Khan · {selectedQuickSlot} · Stylist Raju
            </p>
            <button
              type="button"
              onClick={() => {
                setIsBooked(false);
                setActiveScreenId(2);
              }}
              className="w-full py-2.5 bg-purple-600 text-white font-bold text-xs rounded-xl shadow"
            >
              {isUrdu ? 'Live Line Dekhein (Screen 2) →' : 'View Live Queue (Screen 2) →'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
