import React, { useState } from 'react';
import { useSalon } from '../../context/SalonContext';
import { UserRole } from '../../lib/types';
import {
  Scissors,
  ArrowRight,
  Lock,
  User,
  Mail,
  Smartphone,
  Send,
  CheckCircle2,
  Eye,
  EyeOff,
  AlertCircle,
} from 'lucide-react';
import { motion } from 'motion/react';

export const LoginScreen: React.FC = () => {
  const { setCurrentRole, setActiveScreenId, language } = useSalon();
  const isUrdu = language === 'roman_urdu';

  const [selectedRole, setSelectedRole] = useState<UserRole>('customer');

  // Customer / Staff / Reception OTP state
  const [otpChannel, setOtpChannel] = useState<'mobile' | 'gmail'>('gmail');
  const [mobileNumber, setMobileNumber] = useState<string>('3009872210');
  const [gmailAddress, setGmailAddress] = useState<string>('customer@gmail.com');
  const [otp, setOtp] = useState<string[]>(['4', '8', '2', '1']);
  const [sentOtpCode, setSentOtpCode] = useState<string>('4821');
  const [otpSentBanner, setOtpSentBanner] = useState<boolean>(false);

  // Admin / Owner Password state (default: admin / admin1)
  const [adminUsername, setAdminUsername] = useState<string>('admin');
  const [adminPassword, setAdminPassword] = useState<string>('admin1');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [authError, setAuthError] = useState<string | null>(null);

  const roles: { id: UserRole; label: string; desc: string; targetScreen: number }[] = [
    {
      id: 'customer',
      label: isUrdu ? 'Grahak / Customer' : 'Customer',
      desc: isUrdu ? 'Slot Booking, Live Line, Yaad Dehani' : 'Slot Booking, Live Queue, Reminders',
      targetScreen: 1,
    },
    {
      id: 'reception',
      label: isUrdu ? 'Reception' : 'Reception',
      desc: isUrdu ? 'Bookings Desk, Walk-in, JazzCash & Easypaisa' : 'Bookings Desk, Walk-in, Mobile Wallets',
      targetScreen: 4,
    },
    {
      id: 'staff',
      label: isUrdu ? 'Staff' : 'Staff',
      desc: isUrdu ? 'Mere Grahak, Notes & Record' : 'My Customers, Notes & History',
      targetScreen: 7,
    },
    {
      id: 'malik',
      label: isUrdu ? 'Malik / Admin' : 'Admin / Owner',
      desc: isUrdu ? 'Roz Ki Kamai & Auto Commission' : 'Daily Revenue & Auto Commissions',
      targetScreen: 9,
    },
  ];

  const handleOtpChange = (index: number, val: string) => {
    const newOtp = [...otp];
    newOtp[index] = val.slice(-1);
    setOtp(newOtp);
    setAuthError(null);
  };

  const handleSendOtp = () => {
    setAuthError(null);
    if (otpChannel === 'gmail' && !gmailAddress.trim().includes('@')) {
      setAuthError(
        isUrdu ? 'Sahih Gmail address darj karein' : 'Please enter a valid Gmail address'
      );
      return;
    }
    const generated = Math.floor(1000 + Math.random() * 9000).toString();
    setSentOtpCode(generated);
    setOtp(generated.split(''));
    setOtpSentBanner(true);
  };

  const handleLogin = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setAuthError(null);

    if (selectedRole === 'malik') {
      if (adminUsername.trim() !== 'admin' || adminPassword !== 'admin1') {
        setAuthError(
          isUrdu
            ? 'Ghalat Username ya Password! Default: admin / admin1'
            : 'Invalid Admin credentials! Default: admin / admin1'
        );
        return;
      }
    } else {
      const enteredOtp = otp.join('');
      if (enteredOtp.length < 4 || enteredOtp !== sentOtpCode) {
        setAuthError(
          isUrdu
            ? `Ghalat OTP! Darj karein: ${sentOtpCode}`
            : `Invalid OTP! Please enter ${sentOtpCode}`
        );
        return;
      }
    }

    setCurrentRole(selectedRole);
    const targetScreen = roles.find((r) => r.id === selectedRole)?.targetScreen || 1;
    setActiveScreenId(targetScreen);
  };

  const quickSelect = (role: UserRole) => {
    setSelectedRole(role);
    setAuthError(null);
    if (role === 'customer') setMobileNumber('3009872210');
    if (role === 'reception') setMobileNumber('3009870001');
    if (role === 'staff') setMobileNumber('3009874321');
    if (role === 'malik') {
      setAdminUsername('admin');
      setAdminPassword('admin1');
    }
  };

  return (
    <div className="flex flex-col h-full bg-transparent text-[#0A192F] dark:text-[#E6F1FF] pb-16 justify-center overflow-y-auto scrollbar-none">
      <div className="px-5 py-4 space-y-4 max-w-sm mx-auto w-full">
        {/* App Logo & Branding */}
        <motion.div
          initial={{ opacity: 0, y: -12 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col items-center text-center"
        >
          <div className="w-14 h-14 rounded-3xl bg-[#172A45] border border-[#64FFDA]/40 shadow-xl shadow-[#0A192F]/40 flex items-center justify-center mb-2.5">
            <Scissors className="w-7 h-7 text-[#64FFDA] -rotate-45" />
          </div>
          <h1 className="text-2xl font-black text-[#0A192F] dark:text-[#E6F1FF] tracking-tight">
            Aapka Salon
          </h1>
          <p className="text-xs text-[#172A45]/75 dark:text-[#8892B0] font-semibold mt-0.5">
            {selectedRole === 'malik'
              ? isUrdu
                ? 'Admin Panel — Username aur Password se Login karein'
                : 'Admin Panel — Sign in with Username & Password'
              : isUrdu
                ? 'Gmail ya Mobile OTP se Login karein'
                : 'Sign in with Gmail or Mobile OTP'}
          </p>
        </motion.div>

        {/* Role Selector */}
        <div>
          <div className="text-[10px] font-bold text-[#172A45]/70 dark:text-[#8892B0] uppercase tracking-wider mb-1.5">
            {isUrdu ? 'APNA ROLE CHUNEIN' : 'SELECT YOUR ROLE'}
          </div>
          <div className="grid grid-cols-4 gap-1 bg-[#172A45]/10 dark:bg-[#172A45]/80 backdrop-blur-md p-1 rounded-2xl border border-[#172A45]/15 dark:border-[#64FFDA]/20">
            {roles.map((r) => {
              const isSelected = selectedRole === r.id;
              return (
                <button
                  key={r.id}
                  type="button"
                  onClick={() => quickSelect(r.id)}
                  className={`py-2 rounded-xl text-[11px] font-bold capitalize transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#0A192F] dark:bg-[#64FFDA] text-[#64FFDA] dark:text-[#0A192F] shadow-md'
                      : 'text-[#172A45] dark:text-[#8892B0] hover:bg-white/50 dark:hover:bg-[#0A192F]/50'
                  }`}
                >
                  {r.id === 'malik' ? 'Admin' : r.label.split('/')[0]}
                </button>
              );
            })}
          </div>
        </div>

        <form onSubmit={handleLogin} className="space-y-3.5">
          {selectedRole === 'malik' ? (
            /* ADMIN / OWNER PASSWORD LOGIN */
            <motion.div
              initial={{ opacity: 0, rotateX: 8 }}
              animate={{ opacity: 1, rotateX: 0 }}
              className="space-y-3"
            >
              <div className="bg-white/85 dark:bg-[#172A45]/80 backdrop-blur-xl p-3 rounded-2xl border border-[#172A45]/15 dark:border-[#64FFDA]/25 shadow-sm space-y-1">
                <label className="text-[10px] font-bold text-[#172A45]/70 dark:text-[#8892B0] uppercase tracking-wider flex items-center gap-1">
                  <User className="w-3 h-3 text-[#0A192F] dark:text-[#64FFDA]" />
                  <span>{isUrdu ? 'ADMIN USERNAME' : 'ADMIN USERNAME'}</span>
                </label>
                <input
                  type="text"
                  value={adminUsername}
                  onChange={(e) => {
                    setAdminUsername(e.target.value);
                    setAuthError(null);
                  }}
                  placeholder="admin"
                  className="w-full font-mono font-bold text-sm text-[#0A192F] dark:text-[#E6F1FF] bg-transparent focus:outline-none"
                />
              </div>

              <div className="bg-white/85 dark:bg-[#172A45]/80 backdrop-blur-xl p-3 rounded-2xl border border-[#172A45]/15 dark:border-[#64FFDA]/25 shadow-sm space-y-1">
                <label className="text-[10px] font-bold text-[#172A45]/70 dark:text-[#8892B0] uppercase tracking-wider flex items-center gap-1">
                  <Lock className="w-3 h-3 text-[#0A192F] dark:text-[#64FFDA]" />
                  <span>{isUrdu ? 'ADMIN PASSWORD' : 'ADMIN PASSWORD'}</span>
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={adminPassword}
                    onChange={(e) => {
                      setAdminPassword(e.target.value);
                      setAuthError(null);
                    }}
                    placeholder="admin1"
                    className="w-full font-mono font-bold text-sm text-[#0A192F] dark:text-[#E6F1FF] bg-transparent focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="text-[#8892B0] hover:text-[#0A192F] dark:hover:text-[#64FFDA] cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="text-[10px] text-center text-[#172A45]/75 dark:text-[#8892B0] font-mono">
                Default Admin: <strong className="text-[#0A192F] dark:text-[#64FFDA]">admin</strong> /{' '}
                <strong className="text-[#0A192F] dark:text-[#64FFDA]">admin1</strong>
              </div>
            </motion.div>
          ) : (
            /* CUSTOMER / STAFF / RECEPTION OTP LOGIN (GMAIL OR MOBILE) */
            <motion.div
              initial={{ opacity: 0, rotateX: 8 }}
              animate={{ opacity: 1, rotateX: 0 }}
              className="space-y-3"
            >
              {/* Channel Switcher: Gmail vs Mobile */}
              <div className="grid grid-cols-2 gap-1.5 bg-[#172A45]/10 dark:bg-[#172A45]/70 p-1 rounded-xl border border-[#172A45]/15 dark:border-[#64FFDA]/20">
                <button
                  type="button"
                  onClick={() => setOtpChannel('gmail')}
                  className={`py-1.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    otpChannel === 'gmail'
                      ? 'bg-[#0A192F] dark:bg-[#64FFDA] text-[#64FFDA] dark:text-[#0A192F] shadow-sm'
                      : 'text-[#172A45] dark:text-[#8892B0]'
                  }`}
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>Gmail OTP</span>
                </button>
                <button
                  type="button"
                  onClick={() => setOtpChannel('mobile')}
                  className={`py-1.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    otpChannel === 'mobile'
                      ? 'bg-[#0A192F] dark:bg-[#64FFDA] text-[#64FFDA] dark:text-[#0A192F] shadow-sm'
                      : 'text-[#172A45] dark:text-[#8892B0]'
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>Mobile OTP</span>
                </button>
              </div>

              {otpChannel === 'gmail' ? (
                <div className="bg-white/85 dark:bg-[#172A45]/80 backdrop-blur-xl p-3 rounded-2xl border border-[#172A45]/15 dark:border-[#64FFDA]/25 shadow-sm space-y-1.5">
                  <label className="text-[10px] font-bold text-[#172A45]/70 dark:text-[#8892B0] uppercase tracking-wider block">
                    {isUrdu ? 'CUSTOMER GMAIL ADDRESS' : 'CUSTOMER GMAIL ADDRESS'}
                  </label>
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-[#0A192F] dark:text-[#64FFDA] shrink-0" />
                    <input
                      type="email"
                      value={gmailAddress}
                      onChange={(e) => {
                        setGmailAddress(e.target.value);
                        setAuthError(null);
                      }}
                      placeholder="customer@gmail.com"
                      className="w-full font-mono font-bold text-xs text-[#0A192F] dark:text-[#E6F1FF] bg-transparent focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={handleSendOtp}
                      className="px-2.5 py-1 rounded-lg bg-[#0A192F] dark:bg-[#64FFDA] text-[#64FFDA] dark:text-[#0A192F] text-[10px] font-bold flex items-center gap-1 shrink-0 cursor-pointer"
                    >
                      <Send className="w-3 h-3" />
                      <span>{isUrdu ? 'Bhejein' : 'Send OTP'}</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="bg-white/85 dark:bg-[#172A45]/80 backdrop-blur-xl p-3 rounded-2xl border border-[#172A45]/15 dark:border-[#64FFDA]/25 shadow-sm space-y-1.5">
                  <label className="text-[10px] font-bold text-[#172A45]/70 dark:text-[#8892B0] uppercase tracking-wider block">
                    {isUrdu ? 'MOBILE NUMBER' : 'MOBILE NUMBER'}
                  </label>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-[#8892B0] font-mono">+92</span>
                    <input
                      type="text"
                      value={mobileNumber}
                      onChange={(e) => setMobileNumber(e.target.value)}
                      placeholder="300 9872210"
                      className="w-full font-mono font-bold text-sm text-[#0A192F] dark:text-[#E6F1FF] bg-transparent focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={handleSendOtp}
                      className="px-2.5 py-1 rounded-lg bg-[#0A192F] dark:bg-[#64FFDA] text-[#64FFDA] dark:text-[#0A192F] text-[10px] font-bold flex items-center gap-1 shrink-0 cursor-pointer"
                    >
                      <Send className="w-3 h-3" />
                      <span>{isUrdu ? 'Bhejein' : 'Send OTP'}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Gmail / SMS OTP Dispatched Notification */}
              {otpSentBanner && (
                <div className="p-2.5 rounded-xl bg-[#64FFDA]/15 border border-[#64FFDA]/40 text-[#0A192F] dark:text-[#64FFDA] text-[11px] font-semibold flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>
                      {otpChannel === 'gmail'
                        ? `OTP (${sentOtpCode}) sent to ${gmailAddress}`
                        : `OTP (${sentOtpCode}) sent to +92 ${mobileNumber}`}
                    </span>
                  </div>
                  {otpChannel === 'gmail' && (
                    <a
                      href={`mailto:${gmailAddress}?subject=Aapka%20Salon%20OTP%20Code&body=Your%20Aapka%20Salon%20verification%20OTP%20is%3A%20${sentOtpCode}`}
                      className="underline font-bold shrink-0"
                    >
                      Gmail
                    </a>
                  )}
                </div>
              )}

              {/* OTP 4 boxes */}
              <div className="bg-white/85 dark:bg-[#172A45]/80 backdrop-blur-xl p-3 rounded-2xl border border-[#172A45]/15 dark:border-[#64FFDA]/25 shadow-sm space-y-1.5">
                <label className="text-[10px] font-bold text-[#172A45]/70 dark:text-[#8892B0] uppercase tracking-wider block">
                  {isUrdu ? 'ONE-TIME PASSWORD (OTP CODE)' : 'VERIFY 4-DIGIT OTP'}
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {otp.map((digit, idx) => (
                    <input
                      key={idx}
                      type="text"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => handleOtpChange(idx, e.target.value)}
                      className="w-full py-2.5 text-center font-mono font-black text-lg bg-[#E6F1FF]/70 dark:bg-[#0A192F]/80 border border-[#172A45]/20 dark:border-[#64FFDA]/30 rounded-xl text-[#0A192F] dark:text-[#64FFDA] focus:outline-none focus:border-[#64FFDA]"
                    />
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {authError && (
            <div className="p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/40 text-rose-600 dark:text-rose-300 text-xs font-semibold flex items-center gap-1.5">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{authError}</span>
            </div>
          )}

          {/* Login Button */}
          <motion.button
            type="submit"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.97 }}
            className="w-full py-3.5 bg-[#0A192F] dark:bg-[#64FFDA] text-[#64FFDA] dark:text-[#0A192F] font-extrabold text-sm rounded-2xl shadow-lg shadow-[#0A192F]/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <span>
              {selectedRole === 'malik'
                ? isUrdu
                  ? 'Admin Panel Kholein'
                  : 'Sign In to Admin Panel'
                : isUrdu
                  ? 'OTP Verify & Login Karein'
                  : 'Verify & Sign In'}
            </span>
            <ArrowRight className="w-4 h-4 stroke-[3]" />
          </motion.button>
        </form>

        {/* Quick Demo Switcher helper */}
        <div className="pt-2 border-t border-[#172A45]/15 dark:border-[#64FFDA]/15 text-[11px] space-y-1.5 text-[#172A45]/75 dark:text-[#8892B0]">
          <div className="font-bold text-center">
            {isUrdu ? 'Fauri Role Switch:' : 'Quick Switch Role:'}
          </div>
          <div className="grid grid-cols-2 gap-1.5 text-[10px]">
            {roles.map((r) => (
              <button
                key={r.id}
                type="button"
                onClick={() => {
                  quickSelect(r.id);
                  setCurrentRole(r.id);
                  setActiveScreenId(r.targetScreen);
                }}
                className="p-1.5 bg-white/80 dark:bg-[#172A45]/75 border border-[#172A45]/15 dark:border-[#64FFDA]/20 rounded-lg hover:border-[#64FFDA] text-left font-semibold cursor-pointer"
              >
                <div className="text-[#0A192F] dark:text-[#64FFDA] font-bold">{r.label}</div>
                <div className="text-[#8892B0] text-[9px] truncate">{r.desc}</div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
