import React, { useState } from 'react';
import { useSalon } from '../../context/SalonContext';
import { formatCurrency } from '../../lib/calculations';
import {
  Car,
  Bike,
  MapPin,
  Navigation,
  X,
  CheckCircle2,
  Star,
  ShieldCheck,
} from 'lucide-react';
import { motion } from 'motion/react';

interface InDriveRideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type VehicleType = 'bike' | 'mini' | 'comfort';

export const InDriveRideModal: React.FC<InDriveRideModalProps> = ({ isOpen, onClose }) => {
  const { language } = useSalon();
  const isUrdu = language === 'roman_urdu';

  const [pickup, setPickup] = useState<string>('Model Town, C-Block, Lahore');
  const [vehicle, setVehicle] = useState<VehicleType>('mini');
  const [offerFare, setOfferFare] = useState<number>(280);
  const [rideStatus, setRideStatus] = useState<'idle' | 'searching' | 'matched'>('idle');

  if (!isOpen) return null;

  const vehicles: {
    id: VehicleType;
    name: string;
    eta: string;
    baseFare: number;
    icon: React.ReactNode;
  }[] = [
    {
      id: 'bike',
      name: 'inDrive Bike',
      eta: '5 min',
      baseFare: 120,
      icon: <Bike className="w-4 h-4" />,
    },
    {
      id: 'mini',
      name: 'inDrive Mini',
      eta: '7 min',
      baseFare: 280,
      icon: <Car className="w-4 h-4" />,
    },
    {
      id: 'comfort',
      name: 'AC Comfort',
      eta: '6 min',
      baseFare: 390,
      icon: <Car className="w-4 h-4" />,
    },
  ];

  const handleSelectVehicle = (v: VehicleType, baseFare: number) => {
    setVehicle(v);
    setOfferFare(baseFare);
  };

  const handleRequestRide = (e: React.FormEvent) => {
    e.preventDefault();
    setRideStatus('searching');
    setTimeout(() => {
      setRideStatus('matched');
    }, 900);
  };

  const resetAndClose = () => {
    setRideStatus('idle');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0A192F]/80 backdrop-blur-md flex items-center justify-center p-4 perspective-1200">
      <motion.div
        initial={{ opacity: 0, scale: 0.94, rotateX: 8 }}
        animate={{ opacity: 1, scale: 1, rotateX: 0 }}
        exit={{ opacity: 0, scale: 0.94, rotateX: -8 }}
        transition={{ type: 'spring', stiffness: 260, damping: 22 }}
        className="bg-[#172A45]/95 backdrop-blur-xl border border-[#64FFDA]/35 text-[#E6F1FF] rounded-3xl p-5 max-w-sm w-full shadow-[0_25px_60px_rgba(10,25,47,0.85)] relative space-y-4 preserve-3d"
      >
        <button
          type="button"
          onClick={resetAndClose}
          className="absolute top-4 right-4 p-1.5 rounded-xl bg-[#0A192F]/80 hover:bg-[#0A192F] text-[#8892B0] hover:text-[#64FFDA] border border-[#8892B0]/25 transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-[#64FFDA]/15 border border-[#64FFDA]/40 text-[#64FFDA] flex items-center justify-center shrink-0">
            <Car className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[10px] font-bold tracking-widest text-[#64FFDA] uppercase">
              INDRIVE · RIDE TO SALON
            </div>
            <h3 className="text-base font-extrabold text-[#E6F1FF]">
              {isUrdu ? 'Salon ke liye Ride Book Karein' : 'Book a Ride to Aapka Salon'}
            </h3>
          </div>
        </div>

        {rideStatus === 'matched' ? (
          /* Driver Matched View */
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-3.5"
          >
            <div className="p-3.5 rounded-2xl bg-[#0A192F]/85 border border-[#64FFDA]/40 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-0.5 rounded-full bg-[#64FFDA]/20 text-[#64FFDA] text-[10px] font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>{isUrdu ? 'Driver Mil Gaya!' : 'Driver Accepted!'}</span>
                </span>
                <span className="text-xs font-mono font-bold text-[#64FFDA]">
                  ETA: 4 min
                </span>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-extrabold text-[#E6F1FF]">
                    Kamran Ali
                  </div>
                  <div className="text-[11px] text-[#8892B0]">
                    {vehicle === 'bike'
                      ? 'Honda CG 125 · LEA-4821'
                      : vehicle === 'mini'
                        ? 'Suzuki Alto · LED-9012'
                        : 'Toyota Yaris · LHR-7731'}
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center justify-end gap-1 text-xs font-bold text-amber-400">
                    <Star className="w-3.5 h-3.5 fill-amber-400" />
                    <span>4.9</span>
                  </div>
                  <div className="text-xs font-mono font-bold text-[#64FFDA]">
                    {formatCurrency(offerFare)}
                  </div>
                </div>
              </div>
            </div>

            <div className="p-2.5 rounded-xl bg-[#0A192F]/60 border border-[#8892B0]/20 text-[11px] text-[#8892B0] flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#64FFDA] shrink-0" />
              <span>
                {isUrdu
                  ? 'Driver aapke pickup location par aa raha hai.'
                  : 'Your inDrive captain is on the way to your pickup point.'}
              </span>
            </div>

            <button
              type="button"
              onClick={resetAndClose}
              className="w-full py-3 rounded-xl bg-[#64FFDA] text-[#0A192F] font-extrabold text-xs shadow-lg cursor-pointer"
            >
              {isUrdu ? 'Theek Hai, Done' : 'Done'}
            </button>
          </motion.div>
        ) : (
          /* Ride Booking Form */
          <form onSubmit={handleRequestRide} className="space-y-3.5">
            {/* Pickup & Dropoff */}
            <div className="space-y-2">
              <div className="p-2.5 rounded-xl bg-[#0A192F]/80 border border-[#8892B0]/25 space-y-1">
                <label className="text-[10px] font-bold text-[#8892B0] uppercase flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-[#64FFDA]" />
                  <span>{isUrdu ? 'PICKUP LOCATION' : 'PICKUP LOCATION'}</span>
                </label>
                <input
                  type="text"
                  value={pickup}
                  onChange={(e) => setPickup(e.target.value)}
                  className="w-full bg-transparent text-xs font-semibold text-[#E6F1FF] focus:outline-none"
                  required
                />
              </div>

              <div className="p-2.5 rounded-xl bg-[#0A192F]/50 border border-[#8892B0]/20 flex items-center justify-between">
                <div className="flex items-center gap-2 min-w-0">
                  <Navigation className="w-3.5 h-3.5 text-[#64FFDA] shrink-0" />
                  <div className="truncate">
                    <div className="text-[9px] font-bold text-[#8892B0] uppercase">
                      DESTINATION
                    </div>
                    <div className="text-xs font-bold text-[#E6F1FF] truncate">
                      Aapka Salon · Main Blvd, Gulberg
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Vehicle Selector */}
            <div className="grid grid-cols-3 gap-2">
              {vehicles.map((v) => {
                const active = vehicle === v.id;
                return (
                  <button
                    key={v.id}
                    type="button"
                    onClick={() => handleSelectVehicle(v.id, v.baseFare)}
                    className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                      active
                        ? 'bg-[#0A192F] border-[#64FFDA] text-[#64FFDA] shadow-md'
                        : 'bg-[#0A192F]/50 border-[#8892B0]/25 text-[#E6F1FF] hover:border-[#8892B0]/50'
                    }`}
                  >
                    <div className="flex justify-center mb-1">{v.icon}</div>
                    <div className="text-[11px] font-bold truncate">{v.name}</div>
                    <div className="text-[10px] font-mono opacity-80">
                      {formatCurrency(v.baseFare)}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Offer Your Fare (inDrive style) */}
            <div className="p-3 rounded-xl bg-[#0A192F]/80 border border-[#8892B0]/25 flex items-center justify-between">
              <div>
                <div className="text-[10px] font-bold text-[#8892B0] uppercase">
                  {isUrdu ? 'AAPKA KIRAYA (OFFER FARE)' : 'OFFER YOUR FARE'}
                </div>
                <div className="text-xs text-[#E6F1FF] font-semibold">
                  {isUrdu ? 'Cash / JazzCash' : 'Cash / JazzCash'}
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setOfferFare((f) => Math.max(80, f - 20))}
                  className="w-7 h-7 rounded-lg bg-[#172A45] border border-[#8892B0]/30 text-[#E6F1FF] font-bold cursor-pointer"
                >
                  -
                </button>
                <span className="font-mono font-extrabold text-sm text-[#64FFDA] px-2">
                  {formatCurrency(offerFare)}
                </span>
                <button
                  type="button"
                  onClick={() => setOfferFare((f) => f + 20)}
                  className="w-7 h-7 rounded-lg bg-[#172A45] border border-[#8892B0]/30 text-[#E6F1FF] font-bold cursor-pointer"
                >
                  +
                </button>
              </div>
            </div>

            <motion.button
              type="submit"
              disabled={rideStatus === 'searching'}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.97 }}
              className="w-full py-3 rounded-xl bg-[#64FFDA] text-[#0A192F] font-extrabold text-xs shadow-lg flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
            >
              <Car className="w-4 h-4" />
              <span>
                {rideStatus === 'searching'
                  ? isUrdu
                    ? 'Driver Dhoond Rahe Hain...'
                    : 'Finding Nearby Drivers...'
                  : isUrdu
                    ? 'inDrive Ride Request Karein'
                    : 'Request inDrive Ride'}
              </span>
            </motion.button>
          </form>
        )}
      </motion.div>
    </div>
  );
};
