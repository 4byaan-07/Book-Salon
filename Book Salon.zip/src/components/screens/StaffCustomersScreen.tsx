import React from 'react';
import { useSalon } from '../../context/SalonContext';
import { formatCurrency } from '../../lib/calculations';
import { Check, ChevronRight } from 'lucide-react';

export const StaffCustomersScreen: React.FC = () => {
  const {
    stylists,
    activeStylistId,
    setActiveStylistId,
    bookings,
    setSelectedCustomerId,
    setActiveScreenId,
    language,
  } = useSalon();

  const isUrdu = language === 'roman_urdu';

  const currentStylist = stylists.find((s) => s.id === activeStylistId) || stylists[0];

  // Stylist's bookings
  const myBookings = bookings.filter((b) => b.stylistId === currentStylist.id);
  const activeBooking = myBookings.find((b) => b.status === 'chal_raha') || myBookings[1];

  // Calculate today's stats for this stylist
  const customerCount = Math.max(12, myBookings.length);
  const totalKaam = 4300; // matching blueprint screenshot Rs. 4,300

  const handleOpenCustomerHistory = (custName: string) => {
    setSelectedCustomerId('c1'); // Hamza Khan default
    setActiveScreenId(8); // Screen 8 (Customer History)
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 text-slate-900 pb-28">
      {/* Top Header */}
      <div className="pt-2 px-5 pb-2">
        <div className="flex items-center justify-between text-[11px] font-bold tracking-wider text-purple-700 uppercase">
          <span>{isUrdu ? 'AAPKA SALON · STAFF' : 'AAPKA SALON · STAFF'}</span>
          <span className="px-2 py-0.5 rounded bg-purple-100 text-purple-800 text-[10px]">DEMO</span>
        </div>
        <div className="flex items-center justify-between mt-1">
          <div>
            <h1 className="text-2xl font-extrabold text-slate-900">
              {isUrdu ? 'Aaj Ke Customers' : "Today's Customers"}
            </h1>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              {currentStylist.name} · {currentStylist.chairName}
            </p>
          </div>

          {/* Switch Stylist selector */}
          <select
            value={activeStylistId}
            onChange={(e) => setActiveStylistId(e.target.value)}
            className="text-xs font-bold bg-white border border-slate-200 rounded-xl px-2.5 py-1 text-slate-700 shadow-xs focus:outline-none"
          >
            {stylists.map((st) => (
              <option key={st.id} value={st.id}>
                {st.name} ({st.chairName})
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="flex-1 px-5 space-y-3.5 overflow-y-auto">
        {/* Today Summary Banner */}
        <div className="p-3 bg-white rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between text-xs font-extrabold">
          <div className="text-slate-800">
            {isUrdu ? `Aaj: ${customerCount} grahak` : `Today: ${customerCount} customers`}
          </div>
          <div className="text-purple-700 font-black">
            {isUrdu ? `${formatCurrency(totalKaam)} kaam hua` : `${formatCurrency(totalKaam)} earned`}
          </div>
        </div>

        {/* Highlighted ACTIVE NOW Card */}
        {activeBooking && (
          <div className="p-4 bg-white rounded-3xl border-2 border-purple-400 shadow-md space-y-3">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-purple-600 text-white font-extrabold text-sm flex items-center justify-center">
                  HK
                </div>
                <div>
                  <div className="font-extrabold text-sm text-slate-900">
                    {activeBooking.customerName}
                  </div>
                  <div className="text-xs text-slate-500 font-medium">
                    {activeBooking.slotTime} · {activeBooking.services.map((s) => s.name).join(' + ')}
                  </div>
                </div>
              </div>

              <span className="px-2.5 py-0.5 bg-purple-600 text-white font-black text-[11px] rounded-full uppercase tracking-wider shadow-sm">
                {isUrdu ? 'ABHI CHAL RAHA HAI' : 'ACTIVE NOW'}
              </span>
            </div>

            {/* Previous Cut Note Box */}
            <button
              type="button"
              onClick={() => handleOpenCustomerHistory(activeBooking.customerName)}
              className="w-full text-left p-2.5 bg-amber-50/80 rounded-xl border border-amber-200 text-xs text-amber-950 font-medium flex items-center justify-between hover:bg-amber-100 transition-colors"
            >
              <div>
                <span className="font-bold text-amber-900">
                  {isUrdu ? 'Pichla Haircut: ' : 'Previous Cut: '}
                </span>
                <span>
                  {isUrdu
                    ? 'Fade, sides pe #2, upar se halki trimming'
                    : 'Fade, #2 on sides, trim top lightly'}
                </span>
              </div>
              <ChevronRight className="w-4 h-4 text-amber-700 shrink-0" />
            </button>
          </div>
        )}

        {/* Customer List below */}
        <div className="space-y-2">
          {/* Item 1: Tariq M. 5:30 (Done) */}
          <div
            onClick={() => handleOpenCustomerHistory('Tariq M.')}
            className="p-3 bg-white rounded-2xl border border-slate-200 flex items-center justify-between cursor-pointer hover:border-slate-300 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-rose-100 text-rose-700 font-bold text-xs flex items-center justify-center">
                TM
              </div>
              <div>
                <div className="font-bold text-xs text-slate-900">Tariq M.</div>
                <div className="text-[11px] text-slate-500">
                  5:30 · {isUrdu ? 'Haircut (Khat)' : 'Haircut'}
                </div>
              </div>
            </div>
            <div className="w-5 h-5 rounded-full bg-emerald-50 text-emerald-600 border border-emerald-300 flex items-center justify-center">
              <Check className="w-3.5 h-3.5 stroke-[3]" />
            </div>
          </div>

          {/* Item 2: Dawood K. 6:00 (Done) */}
          <div
            onClick={() => handleOpenCustomerHistory('Dawood K.')}
            className="p-3 bg-white rounded-2xl border border-slate-200 flex items-center justify-between cursor-pointer hover:border-slate-300 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 font-bold text-xs flex items-center justify-center">
                DK
              </div>
              <div>
                <div className="font-bold text-xs text-slate-900">Dawood K.</div>
                <div className="text-[11px] text-slate-500">
                  6:00 · {isUrdu ? 'Daadhi/Beard' : 'Beard'}
                </div>
              </div>
            </div>
            <div className="w-5 h-5 rounded-full bg-emerald-50 text-emerald-600 border border-emerald-300 flex items-center justify-center">
              <Check className="w-3.5 h-3.5 stroke-[3]" />
            </div>
          </div>

          {/* Item 3: Farhan A. 7:00 (Next) */}
          <div
            onClick={() => handleOpenCustomerHistory('Farhan A.')}
            className="p-3 bg-white rounded-2xl border border-slate-200 flex items-center justify-between cursor-pointer hover:border-slate-300 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-amber-100 text-amber-700 font-bold text-xs flex items-center justify-center">
                FA
              </div>
              <div>
                <div className="font-bold text-xs text-slate-900">Farhan A.</div>
                <div className="text-[11px] text-slate-500">
                  7:00 · {isUrdu ? 'Haircut' : 'Haircut'}
                </div>
              </div>
            </div>
            <span className="px-2 py-0.5 bg-amber-50 text-amber-700 border border-amber-200 rounded-full text-[10px] font-bold">
              {isUrdu ? 'Agla Number' : 'Next Up'}
            </span>
          </div>

          {/* Item 4: Usman J. 7:30 */}
          <div
            onClick={() => handleOpenCustomerHistory('Usman J.')}
            className="p-3 bg-white rounded-2xl border border-slate-200 flex items-center justify-between cursor-pointer hover:border-slate-300 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-teal-100 text-teal-700 font-bold text-xs flex items-center justify-center">
                UJ
              </div>
              <div>
                <div className="font-bold text-xs text-slate-900">Usman J.</div>
                <div className="text-[11px] text-slate-500">
                  7:30 · {isUrdu ? 'Hair Polish' : 'Hair spa'}
                </div>
              </div>
            </div>
            <span className="text-slate-400 text-xs">
              {isUrdu ? 'Line Mein' : 'In Queue'}
            </span>
          </div>
        </div>

        {/* Helper guide */}
        <div className="text-[11px] text-slate-500 text-center pt-2">
          {isUrdu
            ? 'Kisi bhi customer par tap karke unka mukammal pichla record dekhein'
            : 'Tap any customer to inspect their full Customer History and preferences'}
        </div>
      </div>
    </div>
  );
};
