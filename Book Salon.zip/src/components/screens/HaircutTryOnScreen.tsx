import React, { useEffect, useRef, useState } from 'react';
import { useSalon } from '../../context/SalonContext';
import { HAIRSTYLE_OPTIONS } from '../../lib/seedData';
import { formatCurrency } from '../../lib/calculations';
import {
  Camera,
  Upload,
  Shuffle,
  Sparkles,
  Check,
  ArrowRight,
  Eye,
  ScanFace,
  SlidersHorizontal,
} from 'lucide-react';
import { motion } from 'motion/react';

interface FaceBox {
  x: number; // percentage 0-100
  y: number; // percentage 0-100
  width: number; // percentage 0-100
  height: number; // percentage 0-100
  confidence: number;
}

const REAL_FACE_MODELS = [
  {
    id: 'model-1',
    label: 'Hamza · Oval Face',
    skinLight: '#E8B896',
    skinMid: '#D19A74',
    skinShadow: '#A86E49',
    lipColor: '#B56956',
    eyeColor: '#2B1D14',
    shirtColor: '#172A45',
    faceBox: { x: 28, y: 20, width: 44, height: 54, confidence: 99 },
  },
  {
    id: 'model-2',
    label: 'Bilal · Square Jaw',
    skinLight: '#D9A37C',
    skinMid: '#BF845B',
    skinShadow: '#8F5A36',
    lipColor: '#9E5644',
    eyeColor: '#1F1610',
    shirtColor: '#0A192F',
    faceBox: { x: 27, y: 19, width: 46, height: 55, confidence: 98 },
  },
  {
    id: 'model-3',
    label: 'Farhan · Diamond Face',
    skinLight: '#F0C5A8',
    skinMid: '#D9A584',
    skinShadow: '#B07958',
    lipColor: '#BD7260',
    eyeColor: '#362419',
    shirtColor: '#1E3A5F',
    faceBox: { x: 29, y: 21, width: 42, height: 53, confidence: 99 },
  },
];

export const HaircutTryOnScreen: React.FC = () => {
  const { language, setActiveScreenId, setSelectedTryOnStyle } = useSalon();
  const isUrdu = language === 'roman_urdu';

  const [selectedStyleId, setSelectedStyleId] = useState<string>(HAIRSTYLE_OPTIONS[0].id);
  const [uploadedPhoto, setUploadedPhoto] = useState<string | null>(null);
  const [demoIndex, setDemoIndex] = useState<number>(0);
  const [showOriginal, setShowOriginal] = useState<boolean>(false);
  const [cameraActive, setCameraActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  // Auto-detected face bounding box & precision fine-tuning
  const [faceBox, setFaceBox] = useState<FaceBox>(REAL_FACE_MODELS[0].faceBox);
  const [isScanningFace, setIsScanningFace] = useState<boolean>(false);
  const [showFineTune, setShowFineTune] = useState<boolean>(false);
  const [hairScale, setHairScale] = useState<number>(1);
  const [hairOffsetY, setHairOffsetY] = useState<number>(0);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  const activeStyle =
    HAIRSTYLE_OPTIONS.find((h) => h.id === selectedStyleId) || HAIRSTYLE_OPTIONS[0];
  const currentModel = REAL_FACE_MODELS[demoIndex];

  // Auto-detect face on uploaded/captured photo using native FaceDetector or Canvas Skin-Tone Centroid
  const detectFaceFromDataUrl = async (dataUrl: string) => {
    setIsScanningFace(true);
    try {
      const img = new Image();
      img.src = dataUrl;
      await new Promise<void>((resolve) => {
        img.onload = () => resolve();
        img.onerror = () => resolve();
      });

      // 1. Try native browser FaceDetector API if available
      if ('FaceDetector' in window) {
        try {
          const detector = new (window as unknown as {
            FaceDetector: new (opts: { fastMode: boolean; maxDetectedFaces: number }) => {
              detect: (
                image: HTMLImageElement
              ) => Promise<Array<{ boundingBox: DOMRectReadOnly }>>;
            };
          }).FaceDetector({ fastMode: true, maxDetectedFaces: 1 });
          const faces = await detector.detect(img);
          if (faces && faces.length > 0 && img.width > 0 && img.height > 0) {
            const box = faces[0].boundingBox;
            setFaceBox({
              x: Math.max(5, Math.min(70, (box.x / img.width) * 100)),
              y: Math.max(5, Math.min(60, (box.y / img.height) * 100)),
              width: Math.max(25, Math.min(75, (box.width / img.width) * 100)),
              height: Math.max(30, Math.min(80, (box.height / img.height) * 100)),
              confidence: 99,
            });
            setIsScanningFace(false);
            return;
          }
        } catch {
          // Fallback to canvas skin-tone centroid
        }
      }

      // 2. Universal Canvas Skin-Tone Centroid Heuristic
      const canvas = document.createElement('canvas');
      const w = 120;
      const h = 120;
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(img, 0, 0, w, h);
        const data = ctx.getImageData(0, 0, w, h).data;
        let sumX = 0;
        let sumY = 0;
        let count = 0;
        let minX = w;
        let maxX = 0;
        let minY = h;
        let maxY = 0;

        for (let y = 10; y < h - 10; y++) {
          for (let x = 15; x < w - 15; x++) {
            const idx = (y * w + x) * 4;
            const r = data[idx];
            const g = data[idx + 1];
            const b = data[idx + 2];
            // Skin-tone RGB heuristic
            if (
              r > 95 &&
              g > 40 &&
              b > 20 &&
              Math.max(r, g, b) - Math.min(r, g, b) > 15 &&
              Math.abs(r - g) > 15 &&
              r > g &&
              r > b
            ) {
              sumX += x;
              sumY += y;
              count++;
              if (x < minX) minX = x;
              if (x > maxX) maxX = x;
              if (y < minY) minY = y;
              if (y > maxY) maxY = y;
            }
          }
        }

        if (count > 80) {
          const cx = (sumX / count / w) * 100;
          const cy = (sumY / count / h) * 100;
          const detectedW = Math.max(34, Math.min(62, ((maxX - minX) / w) * 100 * 0.85));
          const detectedH = Math.max(42, Math.min(70, ((maxY - minY) / h) * 100 * 0.85));
          setFaceBox({
            x: Math.max(10, Math.min(65, cx - detectedW / 2)),
            y: Math.max(8, Math.min(50, cy - detectedH / 2)),
            width: detectedW,
            height: detectedH,
            confidence: 96,
          });
          setIsScanningFace(false);
          return;
        }
      }

      // Default centered portrait box
      setFaceBox({ x: 28, y: 18, width: 44, height: 55, confidence: 94 });
    } finally {
      setTimeout(() => setIsScanningFace(false), 350);
    }
  };

  useEffect(() => {
    if (!uploadedPhoto) {
      setFaceBox(REAL_FACE_MODELS[demoIndex].faceBox);
    }
  }, [demoIndex, uploadedPhoto]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setUploadedPhoto(result);
      setCameraActive(false);
      setCameraError(null);
      detectFaceFromDataUrl(result);
    };
    reader.readAsDataURL(file);
  };

  const handleRandomDemo = () => {
    setUploadedPhoto(null);
    setCameraActive(false);
    setCameraError(null);
    setDemoIndex((prev) => (prev + 1) % REAL_FACE_MODELS.length);
  };

  const handleStartCamera = async () => {
    setCameraError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
      setCameraActive(true);
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      }, 100);
    } catch {
      setCameraError(
        isUrdu
          ? 'Camera dastiyab nahi hai — Real Face Model ya Photo Upload istemal karein.'
          : 'Camera unavailable in preview — use Real Face Model or Upload Photo.'
      );
    }
  };

  const handleCaptureCamera = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 320;
    canvas.height = videoRef.current.videoHeight || 320;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/png');
      setUploadedPhoto(dataUrl);
      detectFaceFromDataUrl(dataUrl);
    }
    const stream = videoRef.current.srcObject as MediaStream | null;
    stream?.getTracks().forEach((t) => t.stop());
    setCameraActive(false);
  };

  const handleBookThisStyle = () => {
    setSelectedTryOnStyle(activeStyle.name);
    setActiveScreenId(1);
  };

  // Renders realistic multi-layered SVG hairstyle aligned to the auto-detected faceBox
  const renderHairOverlay = () => {
    if (showOriginal) return null;

    const overlayStyle: React.CSSProperties = {
      position: 'absolute',
      left: `${faceBox.x - faceBox.width * 0.14}%`,
      top: `${faceBox.y - faceBox.height * 0.24 + hairOffsetY}%`,
      width: `${faceBox.width * 1.28}%`,
      height: `${faceBox.height * 0.72}%`,
      transform: `scale(${hairScale})`,
      transformOrigin: 'center bottom',
      pointerEvents: 'none',
    };

    return (
      <div style={overlayStyle}>
        <svg viewBox="0 0 200 140" className="w-full h-full drop-shadow-[0_6px_12px_rgba(10,25,47,0.45)]">
          <defs>
            <linearGradient id="hairGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor={activeStyle.accentColor} />
              <stop offset="70%" stopColor="#141418" />
              <stop offset="100%" stopColor="#09090b" stopOpacity="0.92" />
            </linearGradient>
          </defs>
          {activeStyle.overlayType === 'fade' && (
            <>
              <path
                d="M28 112 C24 44, 176 44, 172 112 C164 78, 138 64, 100 64 C62 64, 36 78, 28 112 Z"
                fill="url(#hairGrad)"
              />
              <path
                d="M42 74 Q100 28 158 74 Q132 50 100 50 Q68 50 42 74 Z"
                fill="#27272a"
                opacity="0.65"
              />
            </>
          )}
          {activeStyle.overlayType === 'crop' && (
            <path
              d="M26 116 C22 40, 178 40, 174 116 L154 94 L132 104 L102 90 L72 104 L48 94 Z"
              fill="url(#hairGrad)"
            />
          )}
          {activeStyle.overlayType === 'pompadour' && (
            <path
              d="M28 114 C18 20, 182 14, 172 114 C162 72, 136 52, 96 54 C60 56, 38 76, 28 114 Z"
              fill="url(#hairGrad)"
            />
          )}
          {activeStyle.overlayType === 'buzz' && (
            <path
              d="M34 110 C34 52, 166 52, 166 110 C158 84, 134 74, 100 74 C66 74, 42 84, 34 110 Z"
              fill="url(#hairGrad)"
              opacity="0.9"
            />
          )}
          {activeStyle.overlayType === 'sidepart' && (
            <>
              <path
                d="M26 116 C22 38, 176 38, 174 112 C152 70, 92 56, 52 82 L38 100 Z"
                fill="url(#hairGrad)"
              />
              <line x1="62" y1="56" x2="48" y2="92" stroke="#E6F1FF" strokeWidth="2.5" opacity="0.55" />
            </>
          )}
          {activeStyle.overlayType === 'taper' && (
            <path
              d="M22 126 C20 36, 180 36, 178 126 L164 104 C150 62, 50 62, 36 104 Z"
              fill="url(#hairGrad)"
            />
          )}
        </svg>
      </div>
    );
  };

  return (
    <div className="flex flex-col h-full bg-transparent text-[#0A192F] dark:text-[#E6F1FF] pb-28 transition-colors">
      {/* Header */}
      <div className="pt-3 px-5 pb-3 border-b border-[#172A45]/15 dark:border-[#64FFDA]/20 bg-[#E6F1FF]/70 dark:bg-[#0A192F]/70 backdrop-blur-md">
        <div className="flex items-center justify-between text-[10px] font-bold tracking-widest text-[#172A45]/70 dark:text-[#64FFDA] uppercase">
          <span>AAPKA SALON · {isUrdu ? 'AI FACE TRY-ON' : 'AI FACE TRY-ON'}</span>
          <span className="px-2 py-0.5 rounded-md bg-[#172A45] text-[#64FFDA] border border-[#64FFDA]/35 flex items-center gap-1">
            <ScanFace className="w-3 h-3" />
            <span>AUTO-DETECT</span>
          </span>
        </div>
        <h1 className="text-xl font-bold tracking-tight text-[#0A192F] dark:text-[#E6F1FF] mt-1">
          {isUrdu ? 'Haircut Try Karein' : 'Virtual Haircut Try-On'}
        </h1>
        <p className="text-xs text-[#172A45]/75 dark:text-[#8892B0] mt-0.5">
          {isUrdu
            ? 'Auto face-detect ke saath real face model ya apni photo par style dekhein'
            : 'Auto face-detection with realistic face models or your own photo'}
        </p>
      </div>

      <div className="flex-1 px-5 py-4 space-y-4 overflow-y-auto scrollbar-none">
        {/* Photo Preview Stage with Auto-Detected Face HUD */}
        <motion.div
          whileHover={{ rotateX: 2, rotateY: -2 }}
          transition={{ type: 'spring', stiffness: 260, damping: 22 }}
          className="relative w-full h-60 rounded-3xl overflow-hidden border border-[#172A45]/20 dark:border-[#64FFDA]/30 bg-[#172A45] shadow-xl shadow-[#0A192F]/40 flex items-center justify-center"
        >
          {cameraActive ? (
            <div className="relative w-full h-full">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
              <button
                type="button"
                onClick={handleCaptureCamera}
                className="absolute bottom-3 left-1/2 -translate-x-1/2 px-4 py-1.5 rounded-full bg-[#64FFDA] text-[#0A192F] font-bold text-xs shadow-lg cursor-pointer"
              >
                {isUrdu ? 'Photo Khinchein' : 'Capture Photo'}
              </button>
            </div>
          ) : uploadedPhoto ? (
            <div className="relative w-full h-full">
              <img
                src={uploadedPhoto}
                alt="Customer"
                className="w-full h-full object-cover"
              />
              {renderHairOverlay()}
            </div>
          ) : (
            /* Realistic Studio-Lit Human Face Model */
            <div className="relative w-full h-full flex items-center justify-center bg-gradient-to-b from-[#172A45] via-[#0A192F] to-[#071120]">
              <svg viewBox="0 0 240 240" className="w-56 h-56">
                <defs>
                  <radialGradient id="faceSkinGrad" cx="48%" cy="42%" r="55%">
                    <stop offset="0%" stopColor={currentModel.skinLight} />
                    <stop offset="65%" stopColor={currentModel.skinMid} />
                    <stop offset="100%" stopColor={currentModel.skinShadow} />
                  </radialGradient>
                  <linearGradient id="neckGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor={currentModel.skinShadow} />
                    <stop offset="100%" stopColor={currentModel.skinMid} />
                  </linearGradient>
                </defs>

                {/* Shoulders & Collar */}
                <path
                  d="M36 240 C42 182, 198 182, 204 240 Z"
                  fill={currentModel.shirtColor}
                />
                <path
                  d="M92 182 L120 206 L148 182"
                  fill="none"
                  stroke="#64FFDA"
                  strokeOpacity="0.25"
                  strokeWidth="2"
                />

                {/* Neck & Shadow */}
                <rect x="98" y="148" width="44" height="42" rx="16" fill="url(#neckGrad)" />
                <ellipse cx="120" cy="154" rx="22" ry="8" fill={currentModel.skinShadow} opacity="0.55" />

                {/* Ears */}
                <ellipse cx="72" cy="112" rx="7" ry="14" fill={currentModel.skinShadow} />
                <ellipse cx="168" cy="112" rx="7" ry="14" fill={currentModel.skinShadow} />

                {/* Realistic Sculpted Head / Jawline */}
                <path
                  d="M74 96 C74 52, 166 52, 166 96 C166 128, 148 156, 120 158 C92 156, 74 128, 74 96 Z"
                  fill="url(#faceSkinGrad)"
                />

                {/* Cheekbone & Jaw Shading */}
                <path
                  d="M80 116 Q90 138 112 148"
                  stroke={currentModel.skinShadow}
                  strokeWidth="3"
                  strokeLinecap="round"
                  fill="none"
                  opacity="0.35"
                />
                <path
                  d="M160 116 Q150 138 128 148"
                  stroke={currentModel.skinShadow}
                  strokeWidth="3"
                  strokeLinecap="round"
                  fill="none"
                  opacity="0.35"
                />

                {/* Realistic Eyes (Sclera + Iris + Pupil + Catchlight) */}
                <ellipse cx="98" cy="104" rx="8.5" ry="5" fill="#F8FAFC" />
                <circle cx="98" cy="104" r="4" fill={currentModel.eyeColor} />
                <circle cx="98" cy="104" r="2" fill="#09090b" />
                <circle cx="99.5" cy="102.5" r="1" fill="#FFFFFF" />

                <ellipse cx="142" cy="104" rx="8.5" ry="5" fill="#F8FAFC" />
                <circle cx="142" cy="104" r="4" fill={currentModel.eyeColor} />
                <circle cx="142" cy="104" r="2" fill="#09090b" />
                <circle cx="143.5" cy="102.5" r="1" fill="#FFFFFF" />

                {/* Sculpted Eyebrows */}
                <path
                  d="M86 94 Q98 89 109 94"
                  stroke="#1c1917"
                  strokeWidth="3.2"
                  fill="none"
                  strokeLinecap="round"
                />
                <path
                  d="M131 94 Q142 89 154 94"
                  stroke="#1c1917"
                  strokeWidth="3.2"
                  fill="none"
                  strokeLinecap="round"
                />

                {/* Nose Bridge & Nostrils */}
                <path
                  d="M120 102 L117 121 L123 122"
                  stroke={currentModel.skinShadow}
                  strokeWidth="2.2"
                  fill="none"
                  strokeLinecap="round"
                />
                <path
                  d="M114 123 Q120 126 126 123"
                  stroke={currentModel.skinShadow}
                  strokeWidth="1.8"
                  fill="none"
                  strokeLinecap="round"
                />

                {/* Realistic Lips */}
                <path
                  d="M107 136 Q120 132 133 136 Q120 143 107 136 Z"
                  fill={currentModel.lipColor}
                />
                <path
                  d="M108 136 Q120 138 132 136"
                  stroke="#5c2b22"
                  strokeWidth="1.2"
                  fill="none"
                />
              </svg>

              {renderHairOverlay()}

              <div className="absolute top-3 left-3 px-2.5 py-1 rounded-lg bg-[#0A192F]/80 border border-[#64FFDA]/30 text-[#E6F1FF] text-[10px] font-semibold backdrop-blur-md">
                {currentModel.label}
              </div>
            </div>
          )}

          {/* Auto-Detected Face Bounding Box HUD */}
          {!cameraActive && !showOriginal && (
            <div
              style={{
                left: `${faceBox.x}%`,
                top: `${faceBox.y}%`,
                width: `${faceBox.width}%`,
                height: `${faceBox.height}%`,
              }}
              className="absolute pointer-events-none transition-all duration-300"
            >
              <div className="absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2 border-[#64FFDA] rounded-tl-sm" />
              <div className="absolute top-0 right-0 w-3 h-3 border-t-2 border-r-2 border-[#64FFDA] rounded-tr-sm" />
              <div className="absolute bottom-0 left-0 w-3 h-3 border-b-2 border-l-2 border-[#64FFDA] rounded-bl-sm" />
              <div className="absolute bottom-0 right-0 w-3 h-3 border-b-2 border-r-2 border-[#64FFDA] rounded-br-sm" />
              <div className="
                -top-5 left-0 px-1.5 py-0.5 rounded bg-[#0A192F]/85 border border-[#64FFDA]/40
                text-[#64FFDA] text-[9px] font-mono font-bold whitespace-nowrap
                absolute
              ">
                {isScanningFace ? 'SCANNING...' : `FACE ${faceBox.confidence}%`}
              </div>
            </div>
          )}

          {/* Before / After Toggle Pill */}
          {!cameraActive && (
            <button
              type="button"
              onClick={() => setShowOriginal(!showOriginal)}
              className="absolute top-3 right-3 px-2.5 py-1 rounded-lg bg-[#0A192F]/85 backdrop-blur-md text-[#64FFDA] text-[10px] font-bold border border-[#64FFDA]/35 flex items-center gap-1 shadow-xs cursor-pointer"
            >
              <Eye className="w-3 h-3" />
              <span>{showOriginal ? (isUrdu ? 'Style Dikhaein' : 'Show Style') : (isUrdu ? 'Asli Photo' : 'Original')}</span>
            </button>
          )}
        </motion.div>

        {/* Photo Source Controls */}
        <div className="grid grid-cols-4 gap-1.5">
          <motion.button
            type="button"
            whileHover={{ y: -2 }}
            whileTap={{ scale: 0.96 }}
            onClick={handleStartCamera}
            className="py-2 px-2 rounded-xl bg-white/85 dark:bg-[#172A45]/80 backdrop-blur-md border border-[#172A45]/15 dark:border-[#64FFDA]/25 hover:border-[#64FFDA] text-[11px] font-semibold flex items-center justify-center gap-1 transition-colors cursor-pointer"
          >
            <Camera className="w-3.5 h-3.5 text-[#0A192F] dark:text-[#64FFDA]" />
            <span>{isUrdu ? 'Camera' : 'Camera'}</span>
          </motion.button>

          <motion.button
            type="button"
            whileHover={{ y: -2 }}
            whileTap={{ scale: 0.96 }}
            onClick={() => fileInputRef.current?.click()}
            className="py-2 px-2 rounded-xl bg-white/85 dark:bg-[#172A45]/80 backdrop-blur-md border border-[#172A45]/15 dark:border-[#64FFDA]/25 hover:border-[#64FFDA] text-[11px] font-semibold flex items-center justify-center gap-1 transition-colors cursor-pointer"
          >
            <Upload className="w-3.5 h-3.5 text-[#0A192F] dark:text-[#64FFDA]" />
            <span>{isUrdu ? 'Upload' : 'Upload'}</span>
          </motion.button>

          <motion.button
            type="button"
            whileHover={{ y: -2 }}
            whileTap={{ scale: 0.96 }}
            onClick={handleRandomDemo}
            className="py-2 px-2 rounded-xl bg-[#0A192F] dark:bg-[#64FFDA] text-[#64FFDA] dark:text-[#0A192F] text-[11px] font-bold flex items-center justify-center gap-1 shadow-md transition-colors cursor-pointer"
          >
            <Shuffle className="w-3.5 h-3.5" />
            <span>{isUrdu ? 'Face' : 'Model'}</span>
          </motion.button>

          <motion.button
            type="button"
            whileHover={{ y: -2 }}
            whileTap={{ scale: 0.96 }}
            onClick={() => setShowFineTune(!showFineTune)}
            className={`py-2 px-2 rounded-xl border text-[11px] font-semibold flex items-center justify-center gap-1 transition-colors cursor-pointer ${
              showFineTune
                ? 'bg-[#172A45] text-[#64FFDA] border-[#64FFDA]'
                : 'bg-white/85 dark:bg-[#172A45]/80 text-[#0A192F] dark:text-[#E6F1FF] border-[#172A45]/15 dark:border-[#64FFDA]/25'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Fit</span>
          </motion.button>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileUpload}
            className="hidden"
          />
        </div>

        {/* Precision Fine-Tune Sliders */}
        {showFineTune && (
          <div className="p-3 rounded-2xl bg-white/85 dark:bg-[#172A45]/80 backdrop-blur-xl border border-[#64FFDA]/30 space-y-2 text-[11px]">
            <div className="flex items-center justify-between">
              <span className="font-bold text-[#0A192F] dark:text-[#64FFDA]">Hair Scale</span>
              <input
                type="range"
                min="0.8"
                max="1.25"
                step="0.02"
                value={hairScale}
                onChange={(e) => setHairScale(Number(e.target.value))}
                className="w-36 accent-[#64FFDA]"
              />
            </div>
            <div className="flex items-center justify-between">
              <span className="font-bold text-[#0A192F] dark:text-[#64FFDA]">Vertical Fit</span>
              <input
                type="range"
                min="-12"
                max="12"
                step="1"
                value={hairOffsetY}
                onChange={(e) => setHairOffsetY(Number(e.target.value))}
                className="w-36 accent-[#64FFDA]"
              />
            </div>
          </div>
        )}

        {cameraError && (
          <div className="p-2.5 rounded-xl bg-amber-500/15 border border-amber-500/35 text-amber-700 dark:text-amber-300 text-[11px] font-medium">
            {cameraError}
          </div>
        )}

        {/* Hairstyle Selector Grid */}
        <div>
          <div className="text-[10px] font-bold text-[#172A45]/70 dark:text-[#8892B0] uppercase tracking-widest mb-2">
            {isUrdu ? 'HAIRSTYLE CHUNEIN' : 'CHOOSE HAIRSTYLE'}
          </div>
          <div className="grid grid-cols-2 gap-2">
            {HAIRSTYLE_OPTIONS.map((style) => {
              const isSelected = style.id === selectedStyleId;
              return (
                <motion.button
                  key={style.id}
                  type="button"
                  whileHover={{ rotateX: 4, rotateY: -4, scale: 1.02 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => {
                    setSelectedStyleId(style.id);
                    setShowOriginal(false);
                  }}
                  className={`p-3 rounded-2xl border text-left transition-all cursor-pointer backdrop-blur-xl ${
                    isSelected
                      ? 'bg-[#0A192F] dark:bg-[#64FFDA] text-[#64FFDA] dark:text-[#0A192F] border-[#64FFDA] shadow-lg'
                      : 'bg-white/85 dark:bg-[#172A45]/75 text-[#0A192F] dark:text-[#E6F1FF] border-[#172A45]/15 dark:border-[#64FFDA]/20 hover:border-[#64FFDA]'
                  }`}
                >
                  <div className="flex items-center justify-between gap-1">
                    <span className="text-xs font-bold truncate">
                      {isUrdu ? style.romanUrduName : style.name}
                    </span>
                    {isSelected && <Check className="w-3.5 h-3.5 shrink-0" />}
                  </div>
                  <div className="text-[10px] opacity-75 mt-1 flex items-center justify-between">
                    <span>{formatCurrency(style.price)}</span>
                    <span>{style.durationMin} min</span>
                  </div>
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* Selected Style Details & Book CTA */}
        <motion.div
          whileHover={{ rotateX: 2, rotateY: -2 }}
          transition={{ type: 'spring', stiffness: 280, damping: 24 }}
          className="p-3.5 rounded-2xl bg-white/85 dark:bg-[#172A45]/80 backdrop-blur-xl border border-[#172A45]/15 dark:border-[#64FFDA]/25 shadow-lg space-y-3"
        >
          <div className="flex items-start justify-between gap-2">
            <div>
              <div className="text-xs font-bold text-[#0A192F] dark:text-[#E6F1FF] flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#0A192F] dark:text-[#64FFDA]" />
                <span>{isUrdu ? activeStyle.romanUrduName : activeStyle.name}</span>
              </div>
              <p className="text-[11px] text-[#172A45]/75 dark:text-[#8892B0] mt-0.5">
                {isUrdu ? activeStyle.romanUrduDesc : activeStyle.description}
              </p>
            </div>
            <span className="text-xs font-bold font-mono text-[#0A192F] dark:text-[#64FFDA] shrink-0">
              {formatCurrency(activeStyle.price)}
            </span>
          </div>

          <motion.button
            type="button"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.97 }}
            onClick={handleBookThisStyle}
            className="w-full py-3 bg-[#0A192F] dark:bg-[#64FFDA] text-[#64FFDA] dark:text-[#0A192F] font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-md transition-colors cursor-pointer"
          >
            <span>
              {isUrdu ? 'Ye Haircut Book Karein' : 'Book This Haircut'}
            </span>
            <ArrowRight className="w-3.5 h-3.5" />
          </motion.button>
        </motion.div>
      </div>
    </div>
  );
};
