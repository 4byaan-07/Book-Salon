import { Booking, DailyMetrics, PaymentMode, ServiceItem, StaffCommissionResult, Stylist } from './types';

/**
 * Calculates estimated wait time for someone in queue.
 */
export function calculateQueueWaitTime(
  queueAheadCount: number,
  activeChairsCount: number = 2,
  avgMinutesPerCustomer: number = 15
): number {
  if (queueAheadCount <= 0) return 0;
  const activeChairs = Math.max(1, activeChairsCount);
  const estimated = Math.ceil((queueAheadCount * avgMinutesPerCustomer) / activeChairs);
  return Math.max(5, estimated);
}

/**
 * Calculates staff commission with specific rate (default 40%).
 */
export function calculateCommission(amount: number, rate: number = 0.4): number {
  return Math.round(amount * rate);
}

/**
 * Computes commissions for each stylist from bookings.
 */
export function computeStylistCommissions(
  stylists: Stylist[],
  bookings: Booking[],
  timeFrame: 'aaj' | 'hafta' | 'mahina' = 'aaj'
): StaffCommissionResult[] {
  const multiplier = timeFrame === 'aaj' ? 1 : timeFrame === 'hafta' ? 6 : 24;

  return stylists.map((stylist) => {
    const stylistBookings = bookings.filter(
      (b) => b.stylistId === stylist.id && (b.status === 'ho_gaya' || b.status === 'chal_raha')
    );

    const baseCustCount = stylistBookings.length;
    const baseTotalAmount = stylistBookings.reduce((sum, b) => sum + b.totalAmount, 0);

    const customerCount = baseCustCount * multiplier;
    const totalWorkAmount = baseTotalAmount * multiplier;
    const commissionRate = stylist.commissionRate || 0.4;
    const commissionAmount = calculateCommission(totalWorkAmount, commissionRate);

    return {
      stylistId: stylist.id,
      stylistName: stylist.name,
      chairName: stylist.chairName,
      avatarLetter: stylist.avatarLetter,
      avatarColor: stylist.avatarColor,
      customerCount,
      totalWorkAmount,
      commissionRate,
      commissionAmount,
    };
  });
}

/**
 * Computes daily revenue metrics from bookings (Cash vs JazzCash vs Easypaisa, service breakdown).
 */
export function computeDailyMetrics(bookings: Booking[]): DailyMetrics {
  const completedOrActive = bookings.filter((b) => b.status === 'ho_gaya' || b.status === 'chal_raha');

  let cashAmount = 0;
  let jazzcashAmount = 0;
  let easypaisaAmount = 0;
  let bookingCount = 0;
  let walkinCount = 0;
  const serviceMap: Record<string, number> = {
    Haircut: 0,
    'Hair Colour': 0,
    Facial: 0,
    Beard: 0,
  };

  completedOrActive.forEach((b) => {
    if (b.type === 'booking') bookingCount++;
    else walkinCount++;

    const mode = b.paymentMode || (b.tokenNumber % 3 === 0 ? 'easypaisa' : b.tokenNumber % 2 === 0 ? 'jazzcash' : 'cash');
    if (mode === 'jazzcash') {
      jazzcashAmount += b.totalAmount;
    } else if (mode === 'easypaisa') {
      easypaisaAmount += b.totalAmount;
    } else {
      cashAmount += b.totalAmount;
    }

    b.services.forEach((s) => {
      const match = Object.keys(serviceMap).find((k) =>
        s.name.toLowerCase().includes(k.toLowerCase())
      );
      if (match) {
        serviceMap[match] += s.price;
      } else {
        serviceMap['Haircut'] += s.price;
      }
    });
  });

  const totalRevenue = cashAmount + jazzcashAmount + easypaisaAmount;
  const totalCustomers = bookingCount + walkinCount;

  const serviceWiseRevenue = Object.entries(serviceMap).map(([name, amount]) => ({
    name,
    amount,
    percentage: totalRevenue > 0 ? Math.round((amount / totalRevenue) * 100) : 0,
  })).sort((a, b) => b.amount - a.amount);

  const weeklyRevenue = [
    { day: 'M', fullDay: 'Mon', amount: 9800 },
    { day: 'T', fullDay: 'Tue', amount: 8400 },
    { day: 'W', fullDay: 'Wed', amount: 11200 },
    { day: 'T', fullDay: 'Thu', amount: 10500 },
    { day: 'F', fullDay: 'Fri', amount: 13200 },
    { day: 'S', fullDay: 'Sat', amount: 16800 },
    { day: 'S', fullDay: 'Sun', amount: Math.max(14600, totalRevenue), isSunday: true, isToday: true },
  ];

  return {
    totalRevenue,
    cashAmount,
    jazzcashAmount,
    easypaisaAmount,
    totalCustomers,
    bookingCount,
    walkinCount,
    serviceWiseRevenue,
    weeklyRevenue,
  };
}

/**
 * Finds the earliest available stylist for walk-ins.
 */
export function findEarliestAvailableStylist(stylists: Stylist[], bookings: Booking[]): { stylist: Stylist; waitMinutes: number } {
  const activeBookings = bookings.filter((b) => b.status === 'chal_raha');
  const freeStylist = stylists.find((s) => !activeBookings.some((b) => b.stylistId === s.id));

  if (freeStylist) {
    return { stylist: freeStylist, waitMinutes: 0 };
  }

  const queueCounts: Record<string, number> = {};
  stylists.forEach((s) => { queueCounts[s.id] = 0; });
  bookings.filter((b) => b.status === 'aane_wala').forEach((b) => {
    if (queueCounts[b.stylistId] !== undefined) queueCounts[b.stylistId]++;
  });

  let bestStylist = stylists[0];
  let minWait = 999;
  stylists.forEach((s) => {
    const count = queueCounts[s.id] || 0;
    const wait = (count + 1) * 10;
    if (wait < minWait) {
      minWait = wait;
      bestStylist = s;
    }
  });

  return { stylist: bestStylist, waitMinutes: minWait };
}

/**
 * Format currency with Rs. notation (No Hindi signs / ₹ removed)
 */
export function formatCurrency(amount: number): string {
  return `Rs. ${amount.toLocaleString('en-US')}`;
}

export const formatINR = formatCurrency; // backward compatibility

/**
 * Generates WhatsApp alert/receipt templates in English or Roman Urdu
 */
export function generateWhatsAppMessage(
  type: 'booking' | 'queue_alert' | 'bill' | 'reminder' | 'staff_commission',
  data: any,
  lang: 'english' | 'roman_urdu' = 'english'
): string {
  const isUrdu = lang === 'roman_urdu';

  switch (type) {
    case 'booking':
      if (isUrdu) {
        return `💈 *Aapka Salon - Slot Pakka Ho Gaya!*\n\nSalam ${data.customerName}! Aapki appointment book ho chuki hai.\n\n📅 Tareekh: ${data.date}\n⏰ Waqt: ${data.slotTime}\n✂️ Services: ${data.services}\n👤 Stylist: ${data.stylistName}\n🔢 Token: #${data.tokenNumber}\n\nLive queue tracker: https://aapkasalon.app/q/${data.tokenNumber}\n*Ghar se dekhein, sahi waqt par tashreef layein!*`;
      }
      return `💈 *Aapka Salon - Slot Confirmed!*\n\nHello ${data.customerName}! Your appointment has been booked successfully.\n\n📅 Date: ${data.date}\n⏰ Time: ${data.slotTime}\n✂️ Services: ${data.services}\n👤 Stylist: ${data.stylistName}\n🔢 Token: #${data.tokenNumber}\n\nLive queue link: https://aapkasalon.app/q/${data.tokenNumber}\n*Track from home, arrive right on time!*`;

    case 'queue_alert':
      if (isUrdu) {
        return `⚡ *Aapka Salon - Queue Alert!*\n\nSalam ${data.customerName}! Aapke aage *sirf 1 banda reh gaya hai*.\nMeherbani kar ke 5-10 minute mein salon pohanch jayein taake aapka number zaya na ho.\n\nToken #${data.tokenNumber} · Stylist: ${data.stylistName}`;
      }
      return `⚡ *Aapka Salon - Queue Alert!*\n\nHello ${data.customerName}! Only *1 person is ahead of you*.\nPlease arrive at the salon in 5-10 minutes so you don't miss your turn.\n\nToken #${data.tokenNumber} · Stylist: ${data.stylistName}`;

    case 'bill':
      const modeLabel = data.paymentMode === 'jazzcash' ? 'JazzCash' : data.paymentMode === 'easypaisa' ? 'Easypaisa' : 'Cash';
      if (isUrdu) {
        return `🧾 *Aapka Salon - Payment Receipt*\n\nCustomer: ${data.customerName}\nStylist: ${data.stylistName} (${data.chairName})\n\nServices:\n${data.serviceLines}\n\n*Kul Adaigi: ${formatCurrency(data.total)}* via ${modeLabel}\n\nAapki aamad ka bohot shukriya! Dobara zaroor tashreef layein. 🙏`;
      }
      return `🧾 *Aapka Salon - Receipt*\n\nCustomer: ${data.customerName}\nStylist: ${data.stylistName} (${data.chairName})\n\nServices:\n${data.serviceLines}\n\n*Total Paid: ${formatCurrency(data.total)}* via ${modeLabel}\n\nThank you for visiting! See you next time. 🙏`;

    case 'reminder':
      if (isUrdu) {
        return `✂️ *Aapka Salon - Haircut Reminder*\n\nSalam ${data.customerName}! Haircut karwaye hue *${data.days} din* guzar chuke hain.\nKya is hafte slot book karwayein? Aapke pasandeeda stylist ${data.stylistName} free hain.\n\n1-Tap mein book karein: https://aapkasalon.app/book?c=${data.customerId}`;
      }
      return `✂️ *Aapka Salon - Haircut Reminder*\n\nHello ${data.customerName}! It has been ${data.days} days since your last haircut.\nWould you like to book a slot this week? Your favorite stylist ${data.stylistName} is available.\n\nBook in 1-tap: https://aapkasalon.app/book?c=${data.customerId}`;

    case 'staff_commission':
      if (isUrdu) {
        return `📊 *Aapka Salon - Rozana Hisaab*\n\nStaff: ${data.stylistName}\nTotal Customers: ${data.customerCount}\nTotal Kaam: ${formatCurrency(data.totalWorkAmount)}\nCommission (${Math.round(data.commissionRate * 100)}%): *${formatCurrency(data.commissionAmount)}*\n\nShabaash! Aaj ka kaam behtareen raha.`;
      }
      return `📊 *Aapka Salon - Daily Statement*\n\nStaff: ${data.stylistName}\nTotal Customers: ${data.customerCount}\nTotal Work: ${formatCurrency(data.totalWorkAmount)}\nCommission (${Math.round(data.commissionRate * 100)}%): *${formatCurrency(data.commissionAmount)}*\n\nGreat job on today's service!`;
  }
}
