import React, { useState } from 'react';
import { useSalon } from '../../context/SalonContext';
import { Check, Sparkles, Scissors, UserCheck, Car } from 'lucide-react';
import { formatCurrency } from '../../lib/calculations';
import { motion } from 'motion/react';
import { InDriveRideModal } from '../modals/InDriveRideModal';

export const SlotBookingScreen: React.FC = () => {
  const { services, stylists, createSlotBooking, setActiveScreenId, language } = useSalon();
  const isUrdu = language === 'roman_urdu';

  const [selectedServices, setSelectedServices] = useState<string[]>(['s1', 's2']); // Haircut + Beard default
  const [selectedStylist, setSelectedStylist] = useState<string>('raju');
  const [selectedDay, setSelectedDay] = useState<number>(2); // 2 Sun
  const [selectedTime, setSelectedTime] = useState<string>('6:30 PM');
  const [customerName, setCustomerName] = useState<string>('Hamza Khan');
  const [customerPhone, setCustomerPhone] = useState<string>('+92 300 9876210');
  const [isSuccessModal, setIsSuccessModal] = useState<boolean>(false);
  const [bookedToken, setBookedToken] = useState<number | null>(null);
  const [showInDriveModal, setShowInDriveModal] = useState<boolean>(false);

  const days = [
    { num: 2, label: isUrdu ? 'Aaj' : 'Today', full: 'Sun, Nov 2' },
    { num: 3, label: 'Mon', full: 'Mon, Nov 3' },
    { num: 4, label: 'Tue', full: 'Tue, Nov 4' },
    { num: 5, label: 'Wed', full: 'Wed, Nov 5' },
    { num: 6, label: 'Thu', full: 'Thu, Nov 6' },
  ];

  const timeSlots = [
    { time: '5:00 PM', booked: true },
    { time: '5:30 PM', booked: true },
    { time: '6:00 PM', booked: false },
    { time: '6:30 PM', booked: false },
    { time: '7:00 PM', booked: false },
    { time: '7:30 PM', booked: false },
    { time: '8:00 PM', booked: false },
    { time: '8:30 PM', booked: false },
    { time: '9:00 PM', booked: false },
  ];

  const toggleService = (id: string) => {
    if (selectedServices.includes(id)) {
      if (selectedServices.length > 1) {
        setSelectedServices(selectedServices.filter((s) => s !== id));
      }
    } else {
      setSelectedServices([...selectedServices, id]);
    }
  };

  const chosenServices = services.filter((s) => selectedServices.includes(s.id));
  const totalPrice = chosenServices.reduce((sum, s) => sum + s.price, 0);

  const activeStylistObj = stylists.find((s) => s.id === selectedStylist);
  const stylistDisplayName = selectedStylist === 'any'
    ? (isUrdu ? 'Koi bhi stylist' : 'Any Stylist')
    : activeStylistObj?.name || 'Raju';

  const handleBooking = () => {
    const chosenDayObj = days.find((d) => d.num === selectedDay);
    const { tokenNumber } = createSlotBooking({
      customerName,
      customerPhone,
      stylistId: selectedStylist,
      serviceIds: selectedServices,
      date: chosenDayObj?.full || 'Sun, Nov 2',
      slotTime: selectedTime,
    });
    setBookedToken(tokenNumber);
    setIsSuccessModal(true);
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 text-slate-900 pb-28">
      {/* Top Header */}
      <div className="pt-2 px-5 pb-3">
        <div className="flex items-center justify-between text-[11px] font-bold tracking-wider text-purple-700 uppercase">
          <span>AAPKA SALON · CUSTOMER</span>
          <span className="px-2 py-0.5 rounded bg-purple-100 text-purple-800 text-[10px]">DEMO</span>
        </div>
        <h1 className="text-2xl font-extrabold text-slate-900 mt-1">
          {isUrdu ? 'Slot Book Karein' : 'Book a Slot'}
        </h1>
        <p className="text-xs text-slate-500 font-medium mt-0.5">
          {isUrdu
            ? 'Service, stylist, waqt — line ka jhanjhat khatam'
            : 'Service, stylist, time — skip waiting in long lines'}
        </p>
      </div>

      <div className="flex-1 px-5 space-y-4 overflow-y-auto">
        {/* Service cards 2x2 grid */}
        <div className="grid grid-cols-2 gap-2.5">
          {services.slice(0, 4).map((service) => {
            const isSelected = selectedServices.includes(service.id);
            return (
              <button
                key={service.id}
                type="button"
                onClick={() => toggleService(service.id)}
                className={`relative p-3 rounded-2xl border text-left transition-all duration-150 cursor-pointer ${
                  isSelected
                    ? 'border-[#64FFDA]/70 bg-[#172A45]/75 shadow-sm'
                    : 'border-[#8892B0]/25 bg-[#172A45]/75 hover:border-[#8892B0]/50'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="w-8 h-8 rounded-xl bg-[#0A192F]/80 text-[#64FFDA] flex items-center justify-center mb-1.5 border border-[#64FFDA]/25">
                    {service.id === 's1' ? (
                      <Scissors className="w-4 h-4" />
                    ) : (
                      <Sparkles className="w-4 h-4" />
                    )}
                  </div>
                  {isSelected && (
                    <div className="w-5 h-5 rounded-full bg-[#64FFDA] text-[#0A192F] flex items-center justify-center shadow-sm">
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                    </div>
                  )}
                </div>
                <div className="font-bold text-sm text-[#E6F1FF]">
                  {isUrdu ? service.romanUrduName || service.name : service.name}
                </div>
                <div className="text-[#64FFDA] font-extrabold text-sm">{formatCurrency(service.price)}</div>
              </button>
            );
          })}
        </div>

        {/* Stylist Selector */}
        <div>
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
            {isUrdu ? 'STYLIST CHUNEIN' : 'SELECT STYLIST'}
          </div>
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            <button
              type="button"
              onClick={() => setSelectedStylist('any')}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedStylist === 'any'
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              {isUrdu ? 'Koi bhi stylist' : 'Any Stylist'}
            </button>
            {stylists.map((st) => {
              const isSelected = selectedStylist === st.id;
              return (
                <button
                  key={st.id}
                  type="button"
                  onClick={() => setSelectedStylist(st.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
                    isSelected
                      ? 'bg-purple-600 text-white shadow-sm ring-2 ring-purple-300'
                      : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <span
                    className={`w-4 h-4 rounded-full text-[10px] font-bold flex items-center justify-center ${
                      isSelected ? 'bg-white/20 text-white' : `${st.avatarColor} text-white`
                    }`}
                  >
                    {st.avatarLetter}
                  </span>
                  <span>{st.name}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* DAY Picker */}
        <div>
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
            {isUrdu ? 'DIN CHUNEIN' : 'SELECT DAY'}
          </div>
          <div className="grid grid-cols-5 gap-2">
            {days.map((d) => {
              const isSelected = selectedDay === d.num;
              return (
                <button
                  key={d.num}
                  type="button"
                  onClick={() => setSelectedDay(d.num)}
                  className={`flex flex-col items-center justify-center py-2.5 rounded-xl transition-all ${
                    isSelected
                      ? 'bg-purple-950 text-white shadow-md'
                      : 'bg-white border border-slate-200 text-slate-600 hover:border-slate-300'
                  }`}
                >
                  <span className="text-[10px] font-medium opacity-80">{d.label}</span>
                  <span className="text-base font-extrabold mt-0.5">{d.num}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* TIME Slots Grid */}
        <div>
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
            {isUrdu ? 'WAQT KA SLOT' : 'TIME SLOTS'}
          </div>
          <div className="grid grid-cols-3 gap-2">
            {timeSlots.map((ts) => {
              const isSelected = selectedTime === ts.time && !ts.booked;
              return (
                <button
                  key={ts.time}
                  type="button"
                  disabled={ts.booked}
                  onClick={() => setSelectedTime(ts.time)}
                  className={`py-2 px-1 text-center text-xs font-semibold rounded-xl border transition-all ${
                    ts.booked
                      ? 'bg-slate-100 border-slate-200 text-slate-400 line-through cursor-not-allowed opacity-60'
                      : isSelected
                      ? 'bg-purple-600 border-purple-600 text-white shadow-sm ring-2 ring-purple-300'
                      : 'bg-white border-slate-200 text-slate-800 hover:border-purple-200'
                  }`}
                >
                  {ts.time}
                </button>
              );
            })}
          </div>
        </div>

        {/* Customer input fields */}
        <div className="p-3 bg-white rounded-2xl border border-slate-200 space-y-2 text-xs">
          <div className="text-[11px] font-bold text-slate-500 uppercase flex items-center gap-1">
            <UserCheck className="w-3.5 h-3.5 text-purple-600" />
            <span>{isUrdu ? 'Aapka Naam aur Mobile Number' : 'Your Name & Mobile Number'}</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <input
              type="text"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              placeholder={isUrdu ? 'Mukammal Naam' : 'Full Name'}
              className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs font-medium focus:outline-none focus:border-purple-600"
            />
            <input
              type="text"
              value={customerPhone}
              onChange={(e) => setCustomerPhone(e.target.value)}
              placeholder="+92 300 0000000"
              className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs font-medium focus:outline-none focus:border-purple-600"
            />
          </div>
        </div>
      </div>

      {/* Sticky Bottom Bar */}
      <div className="sticky bottom-0 left-0 right-0 px-4 pt-2 pb-3 bg-gradient-to-t from-[#0A192F] via-[#0A192F]/95 to-transparent z-20">
        <div className="bg-[#0F172A]/95 backdrop-blur-xl p-3 rounded-2xl border border-blue-500/50 shadow-[0_10px_30px_rgba(10,25,47,0.85)] space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-[#E6F1FF]">
            <span className="truncate max-w-[210px]">
              {chosenServices.map((s) => s.name).join(' + ')} · {stylistDisplayName} · {selectedTime}
            </span>
            <span className="text-base font-extrabold text-[#64FFDA]">{formatCurrency(totalPrice)}</span>
          </div>
          <motion.button
            type="button"
            onClick={handleBooking}
            whileHover={{ rotateX: 6, rotateY: -4, scale: 1.02 }}
            whileTap={{ scale: 0.96, rotateX: -4 }}
            transition={{ type: 'spring', stiffness: 300, damping: 20 }}
            className="w-full py-3.5 bg-[#172A45]/90 hover:bg-[#172A45] text-[#E6F1FF] font-extrabold text-sm rounded-xl border border-[#64FFDA]/60 shadow-[0_8px_20px_rgba(10,25,47,0.6),0_3px_0_#0A192F] flex items-center justify-center gap-1.5 cursor-pointer preserve-3d"
          >
            <span>{isUrdu ? 'Slot Book Karein' : 'Book My Slot'}</span>
            <span className="text-[#64FFDA]">→</span>
          </motion.button>
        </div>
      </div>

      {/* Booking Confirmed Modal */}
      {isSuccessModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-xs w-full text-center shadow-2xl animate-in fade-in zoom-in-95 duration-200">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-3 shadow-inner">
              <Check className="w-8 h-8 stroke-[3]" />
            </div>
            <div className="text-xs font-bold tracking-widest text-purple-600 uppercase">
              {isUrdu ? 'Slot Pakka Ho Gaya!' : 'Slot Confirmed!'}
            </div>
            <div className="text-3xl font-black text-slate-900 my-1">
              Token #{bookedToken}
            </div>
            <p className="text-xs text-slate-600 mb-4">
              {chosenServices.map((s) => s.name).join(' + ')} · {selectedTime} · Stylist {stylistDisplayName}
            </p>

            <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-emerald-800 text-xs text-left mb-4 flex items-center gap-2">
              <span className="text-base">💬</span>
              <div>
                <strong>WhatsApp message</strong> {isUrdu ? 'bhej diya gaya hai. Barwaqt tashreef layein!' : 'has been dispatched. Arrive on time!'}
              </div>
            </div>

            <div className="space-y-2">
              <button
                type="button"
                onClick={() => {
                  setIsSuccessModal(false);
                  setActiveScreenId(2);
                }}
                className="w-full py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl shadow transition-colors"
              >
                {isUrdu ? 'Live Queue Dekhein (Screen 2) →' : 'View Live Queue (Screen 2) →'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsSuccessModal(false);
                  setShowInDriveModal(true);
                }}
                className="w-full py-2.5 bg-[#0A192F] hover:bg-[#172A45] text-[#64FFDA] border border-[#64FFDA]/50 font-bold text-xs rounded-xl shadow transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Car className="w-3.5 h-3.5" />
                <span>{isUrdu ? 'inDrive Ride Book Karein' : 'Book inDrive Ride to Salon'}</span>
              </button>
              <button
                type="button"
                onClick={() => setIsSuccessModal(false)}
                className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl"
              >
                {isUrdu ? 'Band Karein' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* inDrive Ride Booking Modal */}
      <InDriveRideModal
        isOpen={showInDriveModal}
        onClose={() => setShowInDriveModal(false)}
      />
    </div>
  );
};
