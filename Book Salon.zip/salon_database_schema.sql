-- ====================================================================
-- AAPKA SALON - RELATIONAL DATABASE SCHEMA (PostgreSQL DDL)
-- 11-Screen Salon Blueprint with Cash, JazzCash & Easypaisa Billing
-- Currency: Rs. (PKR)
-- ====================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. CUSTOMERS TABLE
CREATE TABLE IF NOT EXISTS customers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    phone VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    is_regular BOOLEAN DEFAULT FALSE,
    visits_count INTEGER DEFAULT 1,
    avg_frequency_days INTEGER DEFAULT 30,
    favorite_stylist_id VARCHAR(50),
    permanent_notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. STYLISTS TABLE
CREATE TABLE IF NOT EXISTS stylists (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    chair_number INTEGER NOT NULL,
    chair_name VARCHAR(50) NOT NULL,
    status VARCHAR(20) DEFAULT 'free' CHECK (status IN ('busy', 'free')),
    commission_rate NUMERIC(4,2) DEFAULT 0.40,
    phone VARCHAR(20) NOT NULL,
    avatar_letter CHAR(1) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. SERVICES TABLE
CREATE TABLE IF NOT EXISTS services (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    roman_urdu_name VARCHAR(100),
    price NUMERIC(10,2) NOT NULL,
    duration_min INTEGER NOT NULL,
    category VARCHAR(50) NOT NULL CHECK (category IN ('hair', 'beard', 'spa', 'facial', 'color')),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. BOOKINGS TABLE (Scheduled & Walk-ins)
CREATE TABLE IF NOT EXISTS bookings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    token_number INTEGER NOT NULL,
    customer_id UUID REFERENCES customers(id) ON DELETE SET NULL,
    customer_name VARCHAR(100) NOT NULL,
    customer_phone VARCHAR(20) NOT NULL,
    stylist_id VARCHAR(50) REFERENCES stylists(id),
    slot_time VARCHAR(20) NOT NULL,
    booking_date DATE NOT NULL,
    type VARCHAR(20) NOT NULL CHECK (type IN ('booking', 'walkin')),
    status VARCHAR(20) NOT NULL DEFAULT 'aane_wala' CHECK (status IN ('aane_wala', 'chal_raha', 'ho_gaya')),
    total_amount NUMERIC(10,2) NOT NULL,
    payment_mode VARCHAR(20) CHECK (payment_mode IN ('cash', 'jazzcash', 'easypaisa')),
    chair INTEGER DEFAULT 1,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. BOOKING_SERVICES JOIN TABLE
CREATE TABLE IF NOT EXISTS booking_services (
    booking_id UUID REFERENCES bookings(id) ON DELETE CASCADE,
    service_id VARCHAR(50) REFERENCES services(id),
    price NUMERIC(10,2) NOT NULL,
    PRIMARY KEY (booking_id, service_id)
);

-- 6. VISITS HISTORY TABLE
CREATE TABLE IF NOT EXISTS visits (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    customer_id UUID REFERENCES customers(id) ON DELETE CASCADE,
    stylist_id VARCHAR(50) REFERENCES stylists(id),
    visit_date DATE NOT NULL,
    formatted_date VARCHAR(30) NOT NULL,
    service_summary VARCHAR(255) NOT NULL,
    amount NUMERIC(10,2) NOT NULL,
    cut_style_note TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. COMMISSIONS TABLE (Daily Staff Earnings)
CREATE TABLE IF NOT EXISTS commissions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    stylist_id VARCHAR(50) REFERENCES stylists(id),
    commission_date DATE NOT NULL,
    customers_served INTEGER NOT NULL DEFAULT 0,
    work_amount NUMERIC(10,2) NOT NULL,
    commission_rate NUMERIC(4,2) NOT NULL DEFAULT 0.40,
    commission_amount NUMERIC(10,2) GENERATED ALWAYS AS (ROUND(work_amount * commission_rate)) STORED,
    is_settled BOOLEAN DEFAULT FALSE,
    statement_sent_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. DAILY_METRICS TABLE (Owner End-of-Day Register)
CREATE TABLE IF NOT EXISTS daily_metrics (
    date DATE PRIMARY KEY,
    total_customers INTEGER NOT NULL,
    total_revenue NUMERIC(10,2) NOT NULL,
    cash_total NUMERIC(10,2) NOT NULL,
    jazzcash_total NUMERIC(10,2) NOT NULL,
    easypaisa_total NUMERIC(10,2) NOT NULL,
    bookings_count INTEGER NOT NULL,
    walkins_count INTEGER NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ====================================================================
-- INDEXES FOR FAST REAL-TIME QUEUE & SEARCH
-- ====================================================================
CREATE INDEX IF NOT EXISTS idx_bookings_date_status ON bookings(booking_date, status);
CREATE INDEX IF NOT EXISTS idx_customers_phone ON customers(phone);
CREATE INDEX IF NOT EXISTS idx_commissions_date ON commissions(commission_date);
CREATE INDEX IF NOT EXISTS idx_visits_customer ON visits(customer_id);

-- ====================================================================
-- SEED DATA
-- ====================================================================

-- Insert Stylists
INSERT INTO stylists (id, name, chair_number, chair_name, status, commission_rate, phone, avatar_letter)
VALUES
('raju', 'Raju', 1, 'Chair 1', 'busy', 0.40, '+92 300 9876541', 'R'),
('sameer', 'Sameer', 2, 'Chair 2', 'busy', 0.40, '+92 300 9876542', 'S'),
('imran', 'Imran', 3, 'Chair 3', 'free', 0.40, '+92 300 9876543', 'I'),
('pooja', 'Pooja', 4, 'Chair 4', 'free', 0.40, '+92 300 9876544', 'P')
ON CONFLICT (id) DO NOTHING;

-- Insert Services
INSERT INTO services (id, name, roman_urdu_name, price, duration_min, category)
VALUES
('s1', 'Haircut', 'Haircut', 200.00, 20, 'hair'),
('s2', 'Beard Trim', 'Khat & Daari Trim', 100.00, 15, 'beard'),
('s3', 'Glow Facial', 'Glow Facial', 600.00, 35, 'facial'),
('s4', 'Hair Colour', 'Hair Colour (Brown/Black)', 800.00, 45, 'color'),
('s5', 'Deep Scalp Spa', 'Deep Scalp Spa', 500.00, 30, 'spa'),
('s6', 'Hair Wash', 'Shampoo & Wash', 80.00, 10, 'hair'),
('s7', 'Beard Setting', 'Beard Setting', 100.00, 15, 'beard')
ON CONFLICT (id) DO NOTHING;
