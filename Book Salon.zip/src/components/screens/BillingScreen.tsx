import React, { useState } from 'react';
import { useSalon } from '../../context/SalonContext';
import { formatCurrency } from '../../lib/calculations';
import { ArrowRight, Trash2, CheckCircle, Smartphone } from 'lucide-react';
import { PaymentMode, ServiceItem } from '../../lib/types';

export const BillingScreen: React.FC = () => {
  const { bookings, services, processBilling, setActiveScreenId, language } = useSalon();
  const isUrdu = language === 'roman_urdu';

  const billingCandidate =
    bookings.find((b) => b.status === 'chal_raha') ||
    bookings.find((b) => b.customerName.includes('Amit')) ||
    bookings[0];

  const [selectedBookingId, setSelectedBookingId] = useState<string>(billingCandidate?.id || bookings[0]?.id);
  const [billItems, setBillItems] = useState<ServiceItem[]>([
    { id: 's1', name: 'Haircut', romanUrduName: 'Haircut', price: 200, durationMin: 20, category: 'hair' },
    { id: 's7', name: 'Beard Trim', romanUrduName: 'Beard Setting', price: 100, durationMin: 15, category: 'beard' },
    { id: 's6', name: 'Hair Wash', romanUrduName: 'Shampoo & Wash', price: 80, durationMin: 10, category: 'hair' },
  ]);
  const [paymentMode, setPaymentMode] = useState<PaymentMode>('jazzcash');
  const [isBilled, setIsBilled] = useState<boolean>(false);

  const currentBooking = bookings.find((b) => b.id === selectedBookingId) || billingCandidate;
  const totalAmount = billItems.reduce((sum, item) => sum + item.price, 0);

  const handleAddService = (srv: ServiceItem) => {
    setBillItems([...billItems, srv]);
  };

  const handleRemoveItem = (index: number) => {
    if (billItems.length > 1) {
      setBillItems(billItems.filter((_, i) => i !== index));
    }
  };

  const handleSubmitBill = () => {
    if (!currentBooking) return;
    processBilling({
      bookingId: currentBooking.id,
      services: billItems,
      paymentMode,
    });
    setIsBilled(true);
  };

  const renderDigitalPayment = () => {
    if (paymentMode === 'cash') return null;

    const isJazz = paymentMode === 'jazzcash';
    const brandColor = isJazz ? 'border-amber-500 bg-amber-50/50' : 'border-emerald-500 bg-emerald-50/50';
    const badgeColor = isJazz ? 'bg-[#b71c1c] text-amber-200' : 'bg-[#00897b] text-white';
    const accountTitle = 'Aapka Salon Official';
    const accountNumber = isJazz ? '0300 9876543' : '0345 9876543';
    const tillId = isJazz ? 'JC-88219' : 'EP-44102';

    return (
      <div className={`flex flex-col items-center justify-center p-3.5 bg-white rounded-2xl border-2 ${brandColor} shadow-xs space-y-2`}>
        <div className="flex items-center justify-between w-full">
          <span className={`text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider ${badgeColor}`}>
            {isJazz ? 'JazzCash Merchant' : 'Easypaisa Business'}
          </span>
          <span className="text-[10px] font-bold text-slate-500">
            Till: <strong className="text-slate-800">{tillId}</strong>
          </span>
        </div>

        {/* Dynamic QR Code representation */}
        <div className={`w-32 h-32 p-2 rounded-xl flex items-center justify-center relative shadow-inner ${isJazz ? 'bg-amber-950' : 'bg-slate-900'}`}>
          <svg viewBox="0 0 100 100" className="w-full h-full text-white fill-current">
            <rect x="5" y="5" width="30" height="30" fill="white" rx="3" />
            <rect x="10" y="10" width="20" height="20" fill={isJazz ? '#451a03' : '#0f172a'} rx="2" />
            <rect x="14" y="14" width="12" height="12" fill="white" rx="1" />
            <rect x="65" y="5" width="30" height="30" fill="white" rx="3" />
            <rect x="70" y="10" width="20" height="20" fill={isJazz ? '#451a03' : '#0f172a'} rx="2" />
            <rect x="74" y="14" width="12" height="12" fill="white" rx="1" />
            <rect x="5" y="65" width="30" height="30" fill="white" rx="3" />
            <rect x="10" y="70" width="20" height="20" fill={isJazz ? '#451a03' : '#0f172a'} rx="2" />
            <rect x="14" y="74" width="12" height="12" fill="white" rx="1" />
            <rect x="42" y="10" width="6" height="6" fill="white" />
            <rect x="50" y="18" width="6" height="6" fill="white" />
            <rect x="42" y="26" width="6" height="6" fill="white" />
            <rect x="10" y="45" width="6" height="6" fill="white" />
            <rect x="22" y="48" width="6" height="6" fill="white" />
            <rect x="42" y="42" width="16" height="16" fill={isJazz ? '#f59e0b' : '#10b981'} rx="3" />
            <rect x="68" y="45" width="6" height="6" fill="white" />
            <rect x="80" y="52" width="6" height="6" fill="white" />
            <rect x="45" y="68" width="6" height="6" fill="white" />
            <rect x="55" y="78" width="6" height="6" fill="white" />
            <rect x="72" y="72" width="6" height="6" fill="white" />
            <rect x="84" y="80" width="6" height="6" fill="white" />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <span className={`text-[9px] font-black px-1.5 py-0.5 rounded shadow ${isJazz ? 'bg-amber-500 text-slate-950' : 'bg-emerald-500 text-white'}`}>
              {isJazz ? 'JazzCash' : 'Easypaisa'}
            </span>
          </div>
        </div>

        <div className="text-center space-y-0.5">
          <div className="text-base font-black text-slate-900">{formatCurrency(totalAmount)}</div>
          <div className="text-[11px] text-slate-600 font-semibold flex items-center justify-center gap-1">
            <Smartphone className="w-3 h-3 text-slate-500" />
            <span>Account: <strong>{accountNumber}</strong></span>
          </div>
          <div className="text-[10px] text-slate-400 font-medium">
            Title: {accountTitle} · {isUrdu ? 'App se scan karein ya number par bhejein' : 'Scan via app or transfer to mobile account'}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 text-slate-900 pb-28">
      {/* Top Header */}
      <div className="pt-2 px-5 pb-2">
        <div className="flex items-center justify-between text-[11px] font-bold tracking-wider text-purple-700 uppercase">
          <span>AAPKA SALON · RECEPTION</span>
          <span className="px-2 py-0.5 rounded bg-purple-100 text-purple-800 text-[10px]">DEMO</span>
        </div>
        <div className="mt-1">
          <h1 className="text-2xl font-extrabold text-slate-900">
            {isUrdu ? 'Billing aur Payment' : 'Billing & Checkout'}
          </h1>
          <p className="text-xs text-slate-500 font-medium mt-0.5">
            {isUrdu
              ? 'Bill banayein, JazzCash / Easypaisa lein, receipt WhatsApp karein'
              : 'Instant bill, JazzCash & Easypaisa QR, automated WhatsApp receipt'}
          </p>
        </div>
      </div>

      <div className="flex-1 px-5 space-y-3.5 overflow-y-auto">
        {/* Customer Select / Card */}
        <div className="p-3.5 bg-white rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-purple-600 text-white font-extrabold text-sm flex items-center justify-center">
              {currentBooking?.customerName ? currentBooking.customerName.slice(0, 2).toUpperCase() : 'HK'}
            </div>
            <div>
              <div className="font-extrabold text-sm text-slate-900">
                {currentBooking?.customerName || 'Hamza K.'}
              </div>
              <div className="text-xs text-slate-500 font-medium">
                {currentBooking?.stylistName || 'Raju'} · Chair {currentBooking?.chair || 1}
              </div>
            </div>
          </div>

          <div className="px-2.5 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-full text-[11px] font-bold">
            {isUrdu ? 'Kaam Mukammal' : 'Service Finished'}
          </div>
        </div>

        {/* Itemized Services Table */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden p-3 space-y-2">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider pb-1 border-b border-slate-100">
            {isUrdu ? 'Services aur Charges' : 'Services & Charges'}
          </div>

          <div className="space-y-1.5">
            {billItems.map((item, idx) => (
              <div key={idx} className="flex items-center justify-between text-xs py-1">
                <span className="font-semibold text-slate-800">
                  {isUrdu ? item.romanUrduName || item.name : item.name}
                </span>
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-slate-900">{formatCurrency(item.price)}</span>
                  {billItems.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveItem(idx)}
                      className="text-slate-300 hover:text-rose-500"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Quick add extra */}
          <div className="pt-2 border-t border-slate-100 flex items-center gap-1.5 overflow-x-auto text-[10px]">
            <span className="text-slate-400 font-bold shrink-0">+ {isUrdu ? 'Mazeed Shamil Karein:' : 'Add Service:'}</span>
            {services.slice(4, 7).map((s) => (
              <button
                key={s.id}
                type="button"
                onClick={() => handleAddService(s)}
                className="px-2 py-0.5 bg-slate-100 hover:bg-purple-100 text-slate-700 rounded font-medium whitespace-nowrap"
              >
                +{isUrdu ? s.romanUrduName || s.name : s.name} ({formatCurrency(s.price)})
              </button>
            ))}
          </div>

          {/* Total Row */}
          <div className="pt-2 border-t border-slate-200 flex items-center justify-between">
            <span className="text-sm font-bold text-slate-700">{isUrdu ? 'Kul Raqam (Total)' : 'Total'}</span>
            <span className="text-xl font-black text-purple-700">{formatCurrency(totalAmount)}</span>
          </div>
        </div>

        {/* PAYMENT TOGGLE: Cash / JazzCash / Easypaisa */}
        <div>
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
            {isUrdu ? 'TARIQA-E-ADAIGI (PAYMENT METHOD)' : 'PAYMENT METHOD'}
          </div>
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => setPaymentMode('cash')}
              className={`py-2 px-1 rounded-xl text-xs font-bold transition-all text-center ${
                paymentMode === 'cash'
                  ? 'bg-slate-900 text-white shadow-sm ring-2 ring-slate-400'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              Cash
            </button>
            <button
              type="button"
              onClick={() => setPaymentMode('jazzcash')}
              className={`py-2 px-1 rounded-xl text-xs font-bold transition-all text-center ${
                paymentMode === 'jazzcash'
                  ? 'bg-[#b71c1c] text-white shadow-sm ring-2 ring-amber-400'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-red-50'
              }`}
            >
              JazzCash
            </button>
            <button
              type="button"
              onClick={() => setPaymentMode('easypaisa')}
              className={`py-2 px-1 rounded-xl text-xs font-bold transition-all text-center ${
                paymentMode === 'easypaisa'
                  ? 'bg-[#00897b] text-white shadow-sm ring-2 ring-emerald-400'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-emerald-50'
              }`}
            >
              Easypaisa
            </button>
          </div>
        </div>

        {/* Digital Payment Card with QR & Account # */}
        {renderDigitalPayment()}

        {/* Action Button: Collect & Send WhatsApp Receipt */}
        <button
          type="button"
          onClick={handleSubmitBill}
          className="w-full py-3.5 bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 hover:opacity-95 text-white font-extrabold text-sm rounded-2xl shadow-lg shadow-purple-600/30 flex items-center justify-center gap-2 transition-transform active:scale-[0.99]"
        >
          <span>
            {isUrdu ? 'Raqam Wasool Karein & Receipt Bhejein' : 'Collect & Send WhatsApp Receipt'}
          </span>
          <ArrowRight className="w-4 h-4 stroke-[3]" />
        </button>

        {isBilled && (
          <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200 text-xs text-emerald-900 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>
                {isUrdu
                  ? 'Bill record ho gaya aur WhatsApp receipt bhej di gayi!'
                  : 'Bill recorded & WhatsApp receipt dispatched!'}
              </span>
            </div>
            <button
              type="button"
              onClick={() => setActiveScreenId(9)}
              className="text-purple-700 font-bold underline text-[11px] shrink-0"
            >
              {isUrdu ? 'Rozana Kamai →' : 'Daily Revenue →'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
