import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateQueueWaitTime,
  calculateCommission,
  computeStylistCommissions,
  computeDailyMetrics,
  formatCurrency,
  generateWhatsAppMessage
} from './calculations';
import { Booking, Stylist } from './types';

test('calculateQueueWaitTime calculates expected wait based on people ahead and active chairs', () => {
  assert.equal(calculateQueueWaitTime(0), 0);
  assert.equal(calculateQueueWaitTime(2, 2, 15), 15);
  assert.equal(calculateQueueWaitTime(4, 2, 15), 30);
  assert.ok(calculateQueueWaitTime(1, 2, 15) >= 5);
});

test('calculateCommission calculates exact commission based on percentage', () => {
  assert.equal(calculateCommission(4300, 0.4), 1720);
  assert.equal(calculateCommission(3100, 0.4), 1240);
  assert.equal(calculateCommission(2800, 0.4), 1120);
  assert.equal(calculateCommission(4400, 0.4), 1760);
});

test('formatCurrency formats numbers with Rs. notation', () => {
  assert.equal(formatCurrency(380), 'Rs. 380');
  assert.equal(formatCurrency(14600), 'Rs. 14,600');
});

test('computeDailyMetrics correctly separates cash, JazzCash and Easypaisa totals', () => {
  const dummyBookings: Booking[] = [
    {
      id: 'b1',
      tokenNumber: 15,
      customerName: 'Rahul S.',
      customerPhone: '03001234567',
      stylistId: 'raju',
      stylistName: 'Raju',
      chair: 1,
      services: [{ id: 's1', name: 'Haircut', price: 200, durationMin: 20, category: 'hair' }],
      totalAmount: 200,
      slotTime: '6:00 PM',
      date: '2026-11-02',
      type: 'booking',
      status: 'ho_gaya',
      paymentMode: 'cash',
    },
    {
      id: 'b2',
      tokenNumber: 16,
      customerName: 'Amit S.',
      customerPhone: '03001234568',
      stylistId: 'raju',
      stylistName: 'Raju',
      chair: 1,
      services: [
        { id: 's1', name: 'Haircut', price: 200, durationMin: 20, category: 'hair' },
        { id: 's2', name: 'Beard', price: 100, durationMin: 15, category: 'beard' }
      ],
      totalAmount: 300,
      slotTime: '6:30 PM',
      date: '2026-11-02',
      type: 'walkin',
      status: 'chal_raha',
      paymentMode: 'jazzcash',
    }
  ];

  const metrics = computeDailyMetrics(dummyBookings);
  assert.equal(metrics.totalRevenue, 500);
  assert.equal(metrics.cashAmount, 200);
  assert.equal(metrics.jazzcashAmount, 300);
  assert.equal(metrics.bookingCount, 1);
  assert.equal(metrics.walkinCount, 1);
});

test('generateWhatsAppMessage creates expected message text in English and Roman Urdu with Rs.', () => {
  const msgEn = generateWhatsAppMessage('booking', {
    customerName: 'Amit',
    date: 'Sun, Nov 2',
    slotTime: '6:30 PM',
    services: 'Haircut + Beard',
    stylistName: 'Raju',
    tokenNumber: 17,
  }, 'english');

  assert.ok(msgEn.includes('Amit'));
  assert.ok(msgEn.includes('Token: #17'));
  assert.ok(msgEn.includes('Track from home, arrive right on time!'));

  const msgUrdu = generateWhatsAppMessage('booking', {
    customerName: 'Amit',
    date: 'Sun, Nov 2',
    slotTime: '6:30 PM',
    services: 'Haircut + Beard',
    stylistName: 'Raju',
    tokenNumber: 17,
  }, 'roman_urdu');

  assert.ok(msgUrdu.includes('Amit'));
  assert.ok(msgUrdu.includes('Ghar se dekhein, sahi waqt par tashreef layein!'));
});
